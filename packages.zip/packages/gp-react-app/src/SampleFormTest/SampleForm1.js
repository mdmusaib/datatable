import React, { Component } from 'react';
import { Button, Inputs, Icon } from '@gp/components';
import { inputChangeHandler } from './../assets/Form/formOnChange';

class SampleForm1 extends Component {
  state = {
    sampleForm: {
      part: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'code',
          placeholder: 'Part',
        },
        value: '',
        valid: false,
        touched: false,
        validation: {
          required: true,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'acdw sdfasd  asfa fassa a',
        },
      },
      partName: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'name',
          type: 'text',
          placeholder: 'Part Name',
        },
        value: '',
        validation: {
          required: true,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      partIssued: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'string',
          type: 'text',
          placeholder: 'Part Issued',
          isInputWithDropDown: true,
        },
        value: '',
        validation: {
          required: true,
          pattern: /^[0-9]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      partIssuedType: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],

          // isInputWithDropDown: true,
          isSelectWithInput: true,
        },
        value: '',
        validation: {
          required: true,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      weight: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'string',
          type: 'text',
          placeholder: 'Weight',
        },
        value: '',
        validation: {
          required: true,
          pattern: /^[0-9]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      maxWeight: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'code',
          type: 'text',
          placeholder: 'Max Weight',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[0-9]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      weightUnit: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          placeholder: 'Weight Unit',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      part2: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'code',
          type: 'text',
          placeholder: 'Part#2',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      partName2: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'code',
          type: 'text',
          placeholder: 'Part Name 2',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      supplier: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          placeholder: 'Supplier',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      catagory: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          placeholder: 'Catagory',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      usageType: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          placeholder: 'Usage Type',
        },
        value: '',
        validation: {
          required: false,
          //pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      shapeType: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          placeholder: 'Shape Type',
        },
        value: '',
        validation: {
          required: true,
          //pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      height: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Height',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      width: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Width',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      depth: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Depth',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      lengthUnit: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          placeholder: 'Length Unit',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      cost: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Cost',
          inputType: 'code',
          type: 'text',
          isInputWithDropDown: true,
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      costUnit: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          // placeholder: 'Weight Unit',
          isSelectWithInput: true,
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      externalVolume: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'External Volume',
          inputType: 'code',
          type: 'text',
          isInputWithDropDown: true,
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      externalVolumeUnit: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          placeholder: 'Weight Unit',
          isSelectWithInput: true,
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      paxDependent: {
        elementType: 'Checkbox',
        elementConfig: {
          placeholder: 'Pax Dependent',
        },
        value: false,
        validation: {
          required: false,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      isSellable: {
        elementType: 'Checkbox',
        elementConfig: {
          placeholder: 'Is Sellable',
        },
        value: false,
        validation: {
          required: false,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      effectiveDate: {
        elementType: 'DatePicker',
        elementConfig: {
          placeholder: 'Eff. Date',
          // openToDate: new Date('01/01/2000'),
        },
        value: '',
        onChangeDatePicker: this.handleDatepickerChanges,
        validation: {
          required: false,
          pattern: /^(((((((0?[13578])|(1[02]))[\.\-/]?((0?[1-9])|([12]\d)|(3[01])))|(((0?[469])|(11))[\.\-/]?((0?[1-9])|([12]\d)|(30)))|((0?2)[\.\-/]?((0?[1-9])|(1\d)|(2[0-8]))))[\.\-/]?((\d{2})?([\d][\d]))))|((0?2)[\.\-/]?(29)[\.\-/]?(((19)|(20))?(([02468][048])|([13579][26])))))$/,
          message: 'test abcd abcd acbd test',
        },
        disabled: false,
        minDate: null,
        valid: false,
        touched: false,
      },
      endDate: {
        elementType: 'DatePicker',
        elementConfig: {
          placeholder: 'End Date',
          openToDate: new Date('01/01/2000'),
        },
        disabled: false,
        minDate: null,
        onChangeDatePicker: this.handleDatepickerChanges,
        validation: {
          required: false,
          pattern: /^(((((0[1-9])|(1\d)|(2[0-8]))\/((0[1-9])|(1[0-2])))|((31\/((0[13578])|(1[02])))|((29|30)\/((0[1,3-9])|(1[0-2])))))\/((20[0-9][0-9])|(19[0-9][0-9])))|((29\/02\/(19|20)(([02468][048])|([13579][26]))))$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },

      sectorLife: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Sector Life',
          inputType: 'code',
          type: 'text',
          width: '10%',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      usage: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Usage',
          inputType: 'string',
          type: 'text',
          readOnly: true,
          width: '10%',
        },
        value: '100%',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      isDummy: {
        elementType: 'Checkbox',
        elementConfig: {
          placeholder: 'Is Dummy',
        },
        value: false,
        validation: {
          required: false,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      includeInBOM: {
        elementType: 'Checkbox',
        elementConfig: {
          placeholder: 'Include In BOM',
        },
        value: false,
        validation: {
          required: false,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      description: {
        elementType: 'Textarea',
        elementConfig: {
          placeholder: 'Description',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      description2: {
        elementType: 'Textarea',
        elementConfig: {
          placeholder: 'Description 2',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      passengerClass: {
        elementType: 'LookupList',
        elementConfig: {
          options: [
            { value: 'C-Business' },
            { value: 'F-First' },
            { value: 'I-Common' },
            { value: 'PL-Pilot' },
            { value: 'Y-Coach' },
          ],
          placeholder: 'Passenger Class',
        },
        value: [],
        validation: {
          required: false,
        },
        valid: false,
        touched: false,
      },
    },
    formIsValid: false,
  };

  handleDatepickerChanges = (event, userInputIdentifier, state = 'sampleForm') => {
    if (event === null) {
      let currentState = this.state;

      let userInputIdentifier = 'endDate';

      const updatedUserForm = {
        ...this.state[state],
      };
      const updatedUserFormElement = {
        ...updatedUserForm[userInputIdentifier],
      };
      // console.log(updatedUserFormElement)
      updatedUserFormElement.disabled = true;
      updatedUserForm[userInputIdentifier] = updatedUserFormElement;
      currentState[state] = updatedUserForm;
      // console.log(updatedUserFormElement)
      this.setState({
        updatedUserFormElement,
      });
      // console.log(updatedUserFormElement)
    } else {
      let currentState = this.state;
      let userInputIdentifier = 'endDate';

      const updatedUserForm = {
        ...this.state[state],
      };
      const updatedUserFormElement = {
        ...updatedUserForm[userInputIdentifier],
      };
      console.log(updatedUserForm);
      updatedUserFormElement.disabled = false;
      updatedUserForm[userInputIdentifier] = updatedUserFormElement;
      currentState[state] = updatedUserForm;
      // console.log(updatedUserFormElement)
      this.setState({
        updatedUserFormElement,
      });
    }
    let currentState = this.state;
    const updatedForm = {
      ...this.state[state],
    };

    const updatedFormElement = {
      ...updatedForm[userInputIdentifier],
    };
    console.log(userInputIdentifier);
    if (userInputIdentifier.elementType === 'effectiveDate') {
      updatedFormElement.value = event;

      let userInputIdentifier1 = 'endDate';
      const updatedForm1 = {
        ...this.state[state],
      };
      const updatedFormElement1 = {
        ...updatedForm1[userInputIdentifier1],
      };
      console.log();
      updatedFormElement1.minDate = event;
      updatedForm[userInputIdentifier.elementType] = updatedFormElement;
      currentState[state] = updatedForm;
      this.setState(
        {
          updatedFormElement,
          updatedFormElement1,
        },
        () => {
          console.log(this.state);
        },
      );
    }

    updatedFormElement.value = event;
    updatedFormElement.valid = this.checkValidity(updatedFormElement.value, updatedFormElement.validation);
    updatedFormElement.touched = true;
    updatedForm[userInputIdentifier] = updatedFormElement;

    let formIsValid = true;
    let formElements = updatedForm;
    for (let userInputIdentifier in formElements) {
      if (
        formElements[userInputIdentifier].value !== undefined &&
        formElements[userInputIdentifier].validation.required
      ) {
        formIsValid = formElements[userInputIdentifier].valid && formIsValid;
      }
    }
    currentState[state] = updatedForm;
    currentState.formIsValid = formIsValid;

    console.log('------', currentState);
    this.setState(currentState);
  };

  inputChangeHandler = (event, userInputIdentifier, formState) => {
    let currentState = inputChangeHandler(this.state, event, userInputIdentifier, formState);
    // const updatedForm = {
    //     ...this.state[formState],
    // };

    // const updatedFormElement = {
    //     ...updatedForm[userInputIdentifier],
    // };
    // if (updatedFormElement.elementType === 'DatePicker') {
    //     this.handleDatepickerChanges(event, userInputIdentifier);
    // } else {
    //     if (updatedFormElement.elementType === 'MultiSelectDropdown') {
    //         // let data=userInputIdentifier.value.indexOf(event.target.value);
    //         let index = '';
    //         if ((index = updatedFormElement.value.indexOf(event.target.value)) === -1) {
    //             updatedFormElement.value.push(event.target.value);
    //         } else {
    //             updatedFormElement.value.splice(index, 1);
    //         }
    //     } else {
    //         updatedFormElement.value = event.target.value;
    //     }

    //     updatedFormElement.valid = this.checkValidity(
    //         updatedFormElement.value,
    //         updatedFormElement.validation,
    //         updatedFormElement.elementConfig,
    //     );
    //     updatedFormElement.touched = true;
    //     updatedForm[userInputIdentifier] = updatedFormElement;

    //     let formIsValid = true;
    //     let formElements = updatedForm;
    //     for (let userInputIdentifier in formElements) {
    //         if (
    //             formElements[userInputIdentifier].value !== undefined &&
    //             formElements[userInputIdentifier].validation.required
    //         ) {
    //             formIsValid = formElements[userInputIdentifier].valid && formIsValid;
    //         }
    //     }
    //     currentState[formState] = updatedForm;
    //     currentState.formIsValid = formIsValid;

    // console.log('------', currentState)
    this.setState(currentState);
    // }
  };

  checkValidity(value, rules, elementConfig) {
    let isValid = false;
    if (value === '') {
      isValid = false;
    } else if (rules.required === true && elementConfig.type === 'text') {
      // console.log('inside if');

      if (typeof value === 'string') {
        // console.log('inside if 1');

        isValid = rules.pattern.test(value);
      } else {
        // console.log('inside if 2');

        isValid = value.trim() !== '';
      }
    } else {
      // console.log('inside else');

      isValid = true;
    }
    return isValid;
  }

  render() {
    let inputs = [];
    const keys = Object.keys(this.state.sampleForm);
    for (const key of keys) {
      const formElement = this.state.sampleForm[key];
      //console.log(formElement);
      inputs.push(
        <div
          style={{
            height:
              formElement.elementType === 'Textarea' || formElement.elementType === 'LookupList' ? 'auto' : '50px',
            width: formElement.elementConfig.isInputWithDropDown
              ? '12%'
              : formElement.elementConfig.isSelectWithInput
                ? '8%'
                : formElement.elementConfig.width
                  ? formElement.elementConfig.width
                  : formElement.elementType === 'Textarea'
                    ? '40%'
                    : '20%',
            display: 'flex',
          }}
        >
          <Inputs
            key={key}
            name={key}
            elementType={formElement.elementType}
            elementConfig={formElement.elementConfig}
            value={formElement.value}
            valid={formElement.valid}
            touched={formElement.touched}
            changed={event => {
              formElement.elementType === 'DatePicker'
                ? this.handleDatepickerChanges(event, key)
                : this.inputChangeHandler(event, key, 'sampleForm');
            }}
            validation={formElement.validation}
          />
        </div>,
      );
    }

    // let inputs2 = [];
    // const keys2 = Object.keys(this.state.sampleForm2);
    // for (const key of keys2) {
    //     const formElement = this.state.sampleForm2[key];
    //     // console.log(formElement);
    //     inputs2.push(
    //         <Inputs
    //             key={key}
    //             name={key}
    //             elementType={formElement.elementType}
    //             elementConfig={formElement.elementConfig}
    //             value={formElement.value}
    //             valid={formElement.valid}
    //             touched={formElement.touched}
    //             changed={(event) => this.inputChangeHandler(event, key, 'sampleForm2')}
    //             validation={formElement.validation}
    //         />,
    //     );
    // }

    return (
      <>
        <form
          style={{ height: '100%', display: 'flex', flexFlow: 'wrap', justifyContent: 'center' }}
          autoComplete="off"
        >
          {inputs}
        </form>
        <div style={{ width: '100%', bottom: '8px', position: 'absolute', right: '14px', textAlign: 'right' }}>
          <Button
            style={{ padding: '3px 10px', fontSize: '10px', marginRight: '8px' }}
            onButtonClicked={this.formSubmit}
            disabled={!this.state.formIsValid}
            icon={<Icon icon="partsCatalog.partsCatalog_form_add" style={{ marginRight: '5px' }} />}
          >
            Add
          </Button>
          <Button
            style={{ padding: '3px 10px', fontSize: '10px' }}
            onButtonClicked={this.formSubmit}
            icon={<Icon icon="partsCatalog.partsCatalog_form_close" style={{ marginRight: '5px' }} />}
          >
            Close
          </Button>
        </div>
      </>
    );
  }
}

export default SampleForm1;
