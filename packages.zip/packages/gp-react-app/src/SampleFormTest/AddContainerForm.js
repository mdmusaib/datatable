import React, { Component } from 'react';
import {
  InputField,
  Textarea,
  SingleSelectDropdown,
  MultiSelectDropdown,
  Checkbox,
  Button,
  Datepicker,
  RadioButton,
  Inputs,
  Icon,
} from '@gp/components';
import { Container, Row, Col } from 'react-bootstrap';
// import Inputs from './../../../gp-components/src/components/Inputs/Inputs'

class SampleForm1 extends Component {
  state = {
    sampleForm: {
      container: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'code',
          placeholder: 'Code',
        },
        value: '',
        valid: false,
        touched: false,
        validation: {
          required: true,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
      },
      containerName: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'name',
          type: 'text',
          placeholder: 'Name',
        },
        value: '',
        validation: {
          required: true,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      weight: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'string',
          type: 'text',
          placeholder: 'Alternate Code',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[0-9]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      maxWeight: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'code',
          type: 'text',
          placeholder: 'Alternate Name',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      weightUnit: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'cont', displayValue: '1 - 1' },
            { value: 'cont', displayValue: '2 - 2' },
          ],
          placeholder: 'Container Type',
        },
        value: '',
        validation: {
          required: true,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      container2: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'code',
          type: 'text',
          placeholder: 'Container#2',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      containerName2: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'code',
          type: 'text',
          placeholder: 'Container Name 2',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      supplier: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'Part1', displayValue: 'part1 - Part1' },
            { value: 'part2', displayValue: 'Part2 - Part2' },
          ],
          placeholder: 'Part#',
        },
        value: '',
        validation: {
          required: true,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      catagory: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: '1', displayValue: '1 - 111' },
            { value: '2', displayValue: '2 - 222' },
          ],
          placeholder: 'Equipment Type',
        },
        value: '',
        validation: {
          required: true,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      usageType: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          placeholder: 'Exchange Type',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      shapeType: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'Bussiness', displayValue: 'Bussiness - Bussiness' },
            { value: 'Economy', displayValue: 'Economy - Economy' },
          ],
          placeholder: 'Passanger Class',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      height: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Height',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      width: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Width',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      depth: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Depth',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      lengthUnit: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'GR', displayValue: 'GR - GRAM' },
            { value: 'KG', displayValue: 'KG - KILOGRAM' },
          ],
          placeholder: 'Container Catagory',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      cost: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'Cost',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      externalVolume: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'External Volume',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      effectiveDate: {
        elementType: 'DatePicker',
        elementConfig: {
          placeholder: 'Eff. Date',
          openToDate: new Date('01/01/2000'),
          width: '90px',
          height: '22px',
        },
        value: '',
        onChangeDatePicker: this.handleDatepickerChanges,
        validation: {
          required: false,
          pattern: /^(((((((0?[13578])|(1[02]))[\.\-/]?((0?[1-9])|([12]\d)|(3[01])))|(((0?[469])|(11))[\.\-/]?((0?[1-9])|([12]\d)|(30)))|((0?2)[\.\-/]?((0?[1-9])|(1\d)|(2[0-8]))))[\.\-/]?((\d{2})?([\d][\d]))))|((0?2)[\.\-/]?(29)[\.\-/]?(((19)|(20))?(([02468][048])|([13579][26])))))$/,
          message: 'test abcd abcd acbd test',
        },
        disabled: false,
        // minDate: null,
        valid: false,
        touched: false,
      },
      endDate: {
        elementType: 'DatePicker',
        elementConfig: {
          placeholder: 'End Date',
          // openToDate: new Date('01/01/2000'),
          width: '90px',
          height: '22px',
        },
        disabled: false,
        minDate: null,
        onChangeDatePicker: this.handleDatepickerChanges,
        validation: {
          required: false,
          pattern: /^(((((0[1-9])|(1\d)|(2[0-8]))\/((0[1-9])|(1[0-2])))|((31\/((0[13578])|(1[02])))|((29|30)\/((0[1,3-9])|(1[0-2])))))\/((20[0-9][0-9])|(19[0-9][0-9])))|((29\/02\/(19|20)(([02468][048])|([13579][26]))))$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      paxDependent: {
        elementType: 'Checkbox',
        elementConfig: {
          placeholder: 'Pax Dependent',
        },
        value: '',
        validation: {
          required: false,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      isSellable: {
        elementType: 'Checkbox',
        elementConfig: {
          placeholder: 'Is Sellable',
        },
        value: '',
        validation: {
          required: false,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      sectorLife: {
        elementType: 'InputField',
        elementConfig: {
          placeholder: 'External Volume',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      isVirtual: {
        elementType: 'Checkbox',
        elementConfig: {
          placeholder: 'Is Virtual',
        },
        value: '',
        validation: {
          required: false,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      includeInACM: {
        elementType: 'Checkbox',
        elementConfig: {
          placeholder: 'Include In ACM',
        },
        value: '',
        validation: {
          required: false,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      description: {
        elementType: 'Textarea',
        elementConfig: {
          placeholder: 'Description',
          inputType: 'code',
          type: 'text',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      passengerClass: {
        elementType: 'MultiSelectDropdown',
        elementConfig: {
          options: [
            { value: 'Single', displayValue: 'Single Val' },
            { value: 'Second', displayValue: 'Second Val' },
            { value: 'Third', displayValue: 'Third Val' },
          ],
          placeholder: 'Length Unit',
        },
        value: [],
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
    },
  };

  handleDatepickerChanges = (event, userInputIdentifier, state = 'sampleForm') => {
    if (event === null) {
      let currentState = this.state;

      let userInputIdentifier = 'endDate';

      const updatedUserForm = {
        ...this.state[state],
      };
      const updatedUserFormElement = {
        ...updatedUserForm[userInputIdentifier],
      };
      // console.log(updatedUserFormElement)
      updatedUserFormElement.disabled = true;
      updatedUserForm[userInputIdentifier] = updatedUserFormElement;
      currentState[state] = updatedUserForm;
      // console.log(updatedUserFormElement)
      this.setState({
        updatedUserFormElement,
      });
      // console.log(updatedUserFormElement)
    } else {
      let currentState = this.state;
      let userInputIdentifier = 'endDate';

      const updatedUserForm = {
        ...this.state[state],
      };
      const updatedUserFormElement = {
        ...updatedUserForm[userInputIdentifier],
      };
      console.log(updatedUserForm);
      updatedUserFormElement.disabled = false;
      updatedUserForm[userInputIdentifier] = updatedUserFormElement;
      currentState[state] = updatedUserForm;
      // console.log(updatedUserFormElement)
      this.setState({
        updatedUserFormElement,
      });
    }
    let currentState = this.state;
    const updatedForm = {
      ...this.state[state],
    };

    const updatedFormElement = {
      ...updatedForm[userInputIdentifier],
    };
    console.log(userInputIdentifier);
    if (userInputIdentifier.elementType === 'effectiveDate') {
      updatedFormElement.value = event;

      let userInputIdentifier1 = 'endDate';
      const updatedForm1 = {
        ...this.state[state],
      };
      const updatedFormElement1 = {
        ...updatedForm1[userInputIdentifier1],
      };
      console.log();
      updatedFormElement1.minDate = event;
      updatedForm[userInputIdentifier.elementType] = updatedFormElement;
      currentState[state] = updatedForm;
      this.setState(
        {
          updatedFormElement,
          updatedFormElement1,
        },
        () => {
          console.log(this.state);
        },
      );
    }

    updatedFormElement.value = event;
    updatedFormElement.valid = this.checkValidity(updatedFormElement.value, updatedFormElement.validation);
    updatedFormElement.touched = true;
    updatedForm[userInputIdentifier] = updatedFormElement;

    let formIsValid = true;
    let formElements = updatedForm;
    for (let userInputIdentifier in formElements) {
      if (
        formElements[userInputIdentifier].value !== undefined &&
        formElements[userInputIdentifier].validation.required
      ) {
        formIsValid = formElements[userInputIdentifier].valid && formIsValid;
      }
    }
    currentState[state] = updatedForm;
    currentState.formIsValid = formIsValid;

    console.log('------', currentState);
    this.setState(currentState);
  };

  inputChangeHandler = (event, userInputIdentifier, formState) => {
    let currentState = this.state;
    const updatedForm = {
      ...this.state[formState],
    };

    const updatedFormElement = {
      ...updatedForm[userInputIdentifier],
    };
    if (updatedFormElement.elementType === 'DatePicker') {
      this.handleDatepickerChanges(event, userInputIdentifier);
    } else {
      if (updatedFormElement.elementType === 'MultiSelectDropdown') {
        // let data=userInputIdentifier.value.indexOf(event.target.value);
        let index = '';
        if ((index = updatedFormElement.value.indexOf(event.target.value)) === -1) {
          updatedFormElement.value.push(event.target.value);
        } else {
          updatedFormElement.value.splice(index, 1);
        }
      } else {
        updatedFormElement.value = event.target.value;
      }

      updatedFormElement.valid = this.checkValidity(
        updatedFormElement.value,
        updatedFormElement.validation,
        updatedFormElement.elementConfig,
      );
      updatedFormElement.touched = true;
      updatedForm[userInputIdentifier] = updatedFormElement;

      let formIsValid = true;
      let formElements = updatedForm;
      for (let userInputIdentifier in formElements) {
        if (
          formElements[userInputIdentifier].value !== undefined &&
          formElements[userInputIdentifier].validation.required
        ) {
          formIsValid = formElements[userInputIdentifier].valid && formIsValid;
        }
      }
      currentState[formState] = updatedForm;
      currentState.formIsValid = formIsValid;

      // console.log('------', currentState)
      this.setState(currentState);
    }
  };

  checkValidity(value, rules, elementConfig) {
    let isValid = false;
    if (value === '') {
      isValid = false;
    } else if (rules.required === true && elementConfig.type === 'text') {
      // console.log('inside if');

      if (typeof value === 'string') {
        // console.log('inside if 1');

        isValid = rules.pattern.test(value);
      } else {
        // console.log('inside if 2');

        isValid = value.trim() !== '';
      }
    } else {
      // console.log('inside else');

      isValid = true;
    }
    return isValid;
  }

  render() {
    let inputs = [];
    const keys = Object.keys(this.state.sampleForm);
    for (const key of keys) {
      const formElement = this.state.sampleForm[key];
      //console.log(formElement);
      inputs.push(
        <Inputs
          key={key}
          name={key}
          elementType={formElement.elementType}
          elementConfig={formElement.elementConfig}
          value={formElement.value}
          valid={formElement.valid}
          touched={formElement.touched}
          changed={event => this.inputChangeHandler(event, key, 'sampleForm')}
          validation={formElement.validation}
        />,
      );
    }

    // let inputs2 = [];
    // const keys2 = Object.keys(this.state.sampleForm2);
    // for (const key of keys2) {
    //     const formElement = this.state.sampleForm2[key];
    //     // console.log(formElement);
    //     inputs2.push(
    //         <Inputs
    //             key={key}
    //             name={key}
    //             elementType={formElement.elementType}
    //             elementConfig={formElement.elementConfig}
    //             value={formElement.value}
    //             valid={formElement.valid}
    //             touched={formElement.touched}
    //             changed={(event) => this.inputChangeHandler(event, key, 'sampleForm2')}
    //             validation={formElement.validation}
    //         />,
    //     );
    // }

    return (
      <>
        <form style={{ padding: '15px' }} autoComplete="off">
          <Container>
            <Row>
              {inputs}
              {/* {inputs2} */}
            </Row>
          </Container>
        </form>
        <Button
          style={{ position: 'absolute', bottom: '3px', right: '90px', padding: '3px 10px', fontSize: '10px' }}
          onButtonClicked={this.formSubmit}
          disabled={!this.state.formIsValid}
          icon={<Icon icon="partsCatalog.partsCatalog_form_add" style={{ marginRight: '5px' }} />}
        >
          Add
        </Button>
        <Button
          style={{ position: 'absolute', bottom: '3px', right: '13px', padding: '3px 10px', fontSize: '10px' }}
          onButtonClicked={this.formSubmit}
          icon={<Icon icon="partsCatalog.partsCatalog_form_close" style={{ marginRight: '5px' }} />}
        >
          Close
        </Button>
      </>
    );
  }
}

export default SampleForm1;
