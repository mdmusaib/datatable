import { lazy } from 'react';
import { combineReducers } from 'redux';
let selectedModule = (state = 'Home', action) => {
  switch (action.type) {
    case 'ADD_MODULE': {
      return action.module.moduleName;
      // console.log(action.module);
      //return state;
    }
    case 'SELECT_MODULE': {
      //console.log(action.module);
      return action.module.moduleName;
      // console.log(action.module);
      //return state;
    }
    default: {
      return state;
    }
  }
};
let moduleList = (
  state = [
    {
      moduleName: 'Home',
      canClose: false,
      width: '80',
      //icon: 'moduleIcons.Home',
      icon: 'home',
      module: lazy(() => import('../../modules/home/Home')),
    },
  ],
  action,
) => {
  switch (action.type) {
    case 'ADD_MODULE': {
      const isExists = state.reduce((acc, item) => {
        if (item.moduleName === action.module.moduleName) {
          acc = true;
        }
        return acc;
      }, false);
      console.log(action);
      // console.log(isExists);
      if (!isExists) {
        selectedModule(state, action);
        return [...state, action.module];
      } else {
        selectedModule(state, action);
        return state;
      }

      // console.log(action.module);
      //return state;
    }
    case 'REMOVE_MODULE': {
      // selectedModule(state, action);
      let indexNumber = state.reduce((acc, item, index) => {
        if (item.moduleName === action.module.moduleName) {
          acc = index;
        }
        return acc;
      }, -1);
      return [...state.slice(0, indexNumber), ...state.slice(indexNumber + 1)];
    }
    default: {
      //selectedModule(state, action);
      return state;
    }
  }
};
export default combineReducers({ selectedModule, moduleList });
