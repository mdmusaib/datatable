import { combineReducers } from 'redux';
import appHome from './AppHomeReducer';

const rootReducer = combineReducers({
  appHome,
});

export default rootReducer;
