export const ADD_MODULE = 'ADD_MODULE';
export const REMOVE_MODULE = 'REMOVE_MODULE';
export const SELECT_MODULE = 'SELECT_MODULE';

export function addModule(module) {
  return { type: ADD_MODULE, module: module };
}
export function removeModule(module) {
  return { type: REMOVE_MODULE, module: module };
}

export function selectModule(module) {
  return { type: SELECT_MODULE, module: module };
}
