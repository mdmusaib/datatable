import React from 'react';
import { connect } from 'react-redux';
import { AppMain } from '@gp/components';
import { removeModule, selectModule } from './redux/actions/AppHomeAction';

function App() {
  function mapStateToProps(state) {
    return {
      modules: state.appHome.moduleList,
      selectedModule: state.appHome.selectedModule,
    };
  }
  const mapDispatchToProps = dispatch => {
    return {
      removeModule: module => dispatch(removeModule(module)),
      selectModule: module => dispatch(selectModule(module)),
    };
  };
  let GPMain = connect(mapStateToProps, mapDispatchToProps)(AppMain);

  return <GPMain />;
}

export default App;
