export default {
  toolbarStyle: props => {
    return {
      backgroundColor: props.theme.colors.paxia.brand_light_blue,
      width: '100%',
      height: '23px',
      display: 'flex',
    };
  },

  seperator: props => ({
    borderLeft: `1px solid #1071a9`,
  }),
};
