export const NotesLibraryRowData = [
  {
    id: 1,
    noteDictionaryCode: '4422',
    noteDictionaryName: 'Jug Lid not required',
    noteDictionaryPlainText:
      'Text messages are used for personal, family, business and social purposes. Governmental and non-governmental organizations use text messaging for communication between colleagues. In the 2010s, the sending of short informal ',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 2,
    noteDictionaryCode: 'C_16CM_Plates',
    noteDictionaryName: 'Bulk load 16 cm plates & black trays',
    noteDictionaryPlainText:
      'messages has become an accepted part of many cultures, as happened earlier with emailing.[1] This makes texting a quick and easy way to communicate with friends,',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 3,
    noteDictionaryCode: 'C_DEAD_HEAD_2',
    noteDictionaryName: 'Dead Head Equipmets',
    noteDictionaryPlainText:
      'family and colleagues, including in contexts where a call would be impolite or inappropriate (e.g., calling very late at night or when one knows the other person is busy with family or work activities)',
    noteTag: '',
    noteTypeName: 'Part Notes',
  },
  {
    id: 4,
    noteDictionaryCode: 'C_DRAWERS',
    noteDictionaryName: 'Dead Head Drawers',
    noteDictionaryPlainText:
      ' Like e-mail and voicemail and unlike calls (in which the caller hopes to speak directly with the recipient), texting does not require the caller and recipient to both be free at the same moment; this permits communication even between busy individuals. Text messages can also be used to interact with automated systems, for example, to order products or ',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 5,
    noteDictionaryCode: 'Ew_ICEWCREAM',
    noteDictionaryName: 'East West Ice Cream Service',
    noteDictionaryPlainText:
      'services from e-commerce websites, or to participate in online contests. Advertisers and service providers use direct text marketing to send messages to mobile users about promotions, payment due dates, and other notifications instead of using postal mail, email, or voicemail.',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 6,
    noteDictionaryCode: 'G_PCF_9A11',
    noteDictionaryName: 'PCF-Ameinity_Kits',
    noteDictionaryPlainText:
      'The service is referred to by different colloquialisms depending on the region. It may simply be referred to as a "text" in North America, the United Kingdom, Australia, New Zealand, and the Philippines, an "SMS" in most of mainland Europe, or an "MMS" or "SMS" in the Middle East, Africa, and Asia. The sender of a text message is commonly referred to as a "texter".',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 7,
    noteDictionaryCode: 'P744P4',
    noteDictionaryName: '744P4-Loading Instructions',
    noteDictionaryPlainText:
      'The University of Hawaii began using radio to send digital information as early as 1971, using ALOHAnet.[citation needed] Friedhelm Hillebrand conceptualised SMS in 1984 while working for Deutsche Telekom. ',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 8,
    noteDictionaryCode: 'P_763',
    noteDictionaryName: '763',
    noteDictionaryPlainText:
      'Almost every time, the messages contained fewer than 160 characters, thus giving the basis for the limit one could type via text messaging.[4] With Bernard Ghillebaert of France Télécom, he developed a proposal for the GSM (Groupe Spécial Mobile) meeting in February 1985 in Oslo.[5] The first technical solution evolved in a GSM subgroup under the leadership of Finn Trosby. It was further developed under the leadership of Kevin Holley and Ian Harris (see Short Message Service).[6] SMS forms an integral part of SS7',
    noteTag: '',
    noteTypeName: 'Part Notes',
  },
  {
    id: 9,
    noteDictionaryCode: 'P_764',
    noteDictionaryName: '764',
    noteDictionaryPlainText:
      'SMS messaging was used for the first time on 3 December 1992,[8] when Neil Papworth, a 22-year-old test engineer for Sema Group in the UK[9] (now Airwide Solutions),[10] used a personal computer to send the text message "Merry Christmas" via the Vodafone network to the phone of Richard Jarvis,[11][12] who was at a party in Newbury, Berkshire, ',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 10,
    noteDictionaryCode: 'CP_765',
    noteDictionaryName: '765',
    noteDictionaryPlainText:
      ' Sprint Telecommunications Venture, a partnership of Sprint Corp. and three large cable-TV companies, owned 49 percent of APC. The Sprint venture was the largest single buyer at a government-run spectrum auction that raised $7.7 billion in 2005 for PCS licenses. APC operated under the brand name of Sprint Spectrum and launched its s',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 11,
    noteDictionaryCode: 'P_766',
    noteDictionaryName: '766',
    noteDictionaryPlainText:
      'Other collaborative online encyclopedias were attempted before Wikipedia, but none were as successful.[31] Wikipedia began as a complementary project for Nupedia, a free online English-language encyclopedia project whose articles were written by experts and reviewed under a formal process',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 12,
    noteDictionaryCode: 'P_767',
    noteDictionaryName: '767',
    noteDictionaryPlainText:
      'It was founded on March 9, 2000, under the ownership of Bomis, a web portal company. Its main figures were Bomis CEO Jimmy Wales and Larry Sanger, editor-in-chief for Nupedia and later Wikipedia.[33][34] Nupedia was initially licensed under it',
    noteTag: '',
    noteTypeName: 'Part Notes',
  },
  {
    id: 13,
    noteDictionaryCode: 'P_768',
    noteDictionaryName: '768',
    noteDictionaryPlainText:
      'own Nupedia Open Content License, but even before Wikipedia was founded, Nupedia switched to the GNU Free Documentation License at the urging of Richard Stallman.[35] Wales is credited with defining the goal of making a publicly editable encyclope',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 14,
    noteDictionaryCode: 'P_769',
    noteDictionaryName: '769',
    noteDictionaryPlainText:
      'while Sanger is credited with the strategy of using a wiki to reach that goal.[38] On January 10, 2001, Sanger proposed on th',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 15,
    noteDictionaryCode: 'ICP-345',
    noteDictionaryName: '345',
    noteDictionaryPlainText:
      'The domains wikipedia.com and wikipedia.org were registered on January 12, 2001[40] and January 13, 2001[41] respectively, and Wikipe',
    noteTag: '',
    noteTypeName: 'Part Notes',
  },
  {
    id: 16,
    noteDictionaryCode: 'UYT-567',
    noteDictionaryName: '567',
    noteDictionaryPlainText:
      'a was launched on January 15, 2001,[32] as a single English-language edition at www.wikipedia.com,[42] and announced by Sange',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 17,
    noteDictionaryCode: 'UTY-568',
    noteDictionaryName: '568',
    noteDictionaryPlainText:
      'Wikipedia gained early contributors from Nupedia, Slashdot postings, and web search engine indexing. Language editions were also ',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 18,
    noteDictionaryCode: 'UTY-456',
    noteDictionaryName: '456',
    noteDictionaryPlainText:
      'created, with a total of 161 by the end of 2004.[45] Nupedia and Wikipedia coexisted until the forme',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 19,
    noteDictionaryCode: 'ICE-234',
    noteDictionaryName: '234',
    noteDictionaryPlainText:
      ' in 2003, and its text was incorporated into Wikipedia. The English Wikipedia passed the mark of two million articles on September ',
    noteTag: '',
    noteTypeName: 'Part Notes',
  },
  {
    id: 20,
    noteDictionaryCode: 'ICT-309',
    noteDictionaryName: '309',
    noteDictionaryPlainText:
      '2007, making it the largest encyclopedia ever assembled, surpassing the 1408 Yongle Encyclopedia, which had held the rec',
    noteTag: '',
    noteTypeName: 'Container Notes',
  },
  {
    id: 21,
    noteDictionaryCode: 'ICT-310',
    noteDictionaryName: '310',
    noteDictionaryPlainText:
      'Citing fears of commercial advertising and lack of control in Wikipedia, users of the Spanish Wikipedia forked from Wikipedia to create the ',
    noteTag: '',
    noteTypeName: 'Part Notes',
  },
];
