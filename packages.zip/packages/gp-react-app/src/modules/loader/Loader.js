import React, { Component, lazy, Fragment } from 'react';
import { connect } from 'react-redux';
import { addModule } from '../../redux/actions/AppHomeAction';
import { Toolbar, Icon, AppModule, CollapsedExplorerPanel, DataGrid, GpModal, StyledElement } from '@gp/components';
import loaderToolbarList from './LoaderToolbarList';
import FleetExplorer from './FleetExplorer';
import { Row, Container } from 'react-bootstrap';
import loaderJsonData from '../../config/loader/LoaderData.json';
import { ProductLibraryRowData } from './productLibrary/ProductLibraryRowData';
import { ProductCatalogRowData } from './productCatalog/ProductCatalogRowData';
import { ModuleCatalogRowData } from './moduleCatalog/ModuleCatalogRowData';
import { NotesLibraryRowData } from '../loader/notesLibrary/NotesLibraryRowData';
import { ManageScheduleRowData } from '../loader/manageSchedules/ManageScheduleRowData';
import { AirCraftFamilyRowData } from './AirCraftFamilyRowData';
import ProductLibraryJsonData from '../../config/loader/productLibrary/ProductLibraryData.json';
import ProductCatalogJsonData from '../../config/loader/productCatalog/ProductCatalogData.json';
import ModuleCatalogJsonData from '../../config/loader/moduleCatalog/ModuleCatalogData.json';
import NotesLibraryJsonData from '../../config/loader/notesLibrary/NotesLibrary.json';
import ManageFlightSchedulesJsonData from '../../config/loader/manageSchedule/ManageSchedule.json';
import loaderStyle from './LoaderStyle';

let Seperator = StyledElement('div')(loaderStyle.seperator);

let ModuleIconHolder = props => {
  let module = {
    moduleName: 'Container Catalog',
    //icon: 'moduleIcons.ContainerCatalog',
    icon: 'containerCatalog',
    iconColor: '#20c997',
    width: '160',
    canClose: true,
    module: lazy(() => import('../containerCatalog/ContainerCatalog')),
  };
  return (
    <div title={props.title} onClick={e => props.addModule(module)}>
      <Icon type="svg" icon={props.icon} svgIconColor="white" width="24" height="24" />
    </div>
  );
};
const mapDispatchToProps = dispatch => {
  return {
    addModule: module => dispatch(addModule(module)),
  };
};
let ConnectedModuleIcon = connect(null, mapDispatchToProps)(ModuleIconHolder);

class Loader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showExplorer: true,
      showModule: '',
      showProductLibraryGrid: false,
      showProductCatalogGrid: false,
      showModuleCatalog: false,
      showNotesLibrary: false,
      showManageFlightSchedules: false,
      fullScreenModal: false,
      showFullScreenNotesLibrary: false,
      showFillScreenProductCatalog: true,
      showFullScreenModuleCatalog: true,
      showFullScreenManageFlightSchedule: true,
      showContainerCatalog: false,
    };
  }

  toggleExplorer = event => {
    event.preventDefault();
    this.setState({
      showExplorer: !this.state.showExplorer,
    });
  };

  closeModal = () => {
    this.setState({
      showProductLibraryGrid: false,
      showProductCatalogGrid: false,
      showModuleCatalog: false,
      showNotesLibrary: false,
      showManageFlightSchedules: false,
    });
  };

  fullScreenClicked = () => {
    this.setState({
      fullScreenModal: !this.state.fullScreenModal,
      modalWidth: '100%',
      modalHeight: '100%',
    });
  };

  showFullScreenNotesLibraryClicked = () => {
    this.setState({
      showFullScreenNotesLibrary: !this.state.showFullScreenNotesLibrary,
      modalWidth: '80%',
      modalHeight: '75%',
    });
  };

  showFullScrrenProductCatalogCilcked = () => {
    this.setState({
      showFillScreenProductCatalog: !this.state.showFillScreenProductCatalog,
      modalWidth: '80%',
      modalHeight: '75%',
    });
  };

  showFullScreenModuleCatalogClicked = () => {
    this.setState({
      showFullScreenModuleCatalog: !this.state.showFullScreenModuleCatalog,
      modalWidth: '80%',
      modalHeight: '75%',
    });
  };

  showFullScreenManageFlightScheduleClicked = () => {
    this.setState({
      showFullScreenManageFlightSchedule: !this.state.showFullScreenManageFlightSchedule,
      showFullScreenNotesLibrary: false,
      modalWidth: '80%',
      modalHeight: '75%',
    });
  };

  toolBarModuleClick = module => {
    switch (module) {
      case 'Product Library':
        this.setState({
          fullScreenModal: false,
          showProductLibraryGrid: true,
          showProductCatalogGrid: false,
          showModuleCatalog: false,
          showNotesLibrary: false,
          showManageFlightSchedules: false,
        });
        break;
      case 'Product Catalog':
        this.setState({
          showFillScreenProductCatalog: true,
          showProductLibraryGrid: false,
          showProductCatalogGrid: true,
          showModuleCatalog: false,
          showNotesLibrary: false,
          showManageFlightSchedules: false,
        });
        break;
      case 'Module Catalog':
        this.setState({
          showFullScreenModuleCatalog: true,
          showProductLibraryGrid: false,
          showProductCatalogGrid: false,
          showModuleCatalog: true,
          showNotesLibrary: false,
          showManageFlightSchedules: false,
        });
        break;
      case 'Notes Library':
        this.setState({
          showFullScreenNotesLibrary: false,
          showProductLibraryGrid: false,
          showProductCatalogGrid: false,
          showModuleCatalog: false,
          showNotesLibrary: true,
          showManageFlightSchedules: false,
        });
        break;
      case 'Manage Schedules':
        this.setState({
          showFullScreenManageFlightSchedule: true,
          showProductLibraryGrid: false,
          showProductCatalogGrid: false,
          showModuleCatalog: false,
          showNotesLibrary: true,
          showManageFlightSchedules: true,
        });
        break;
      case 'Container Catalog':
        this.setState({ showContainerCatalog: true });
        break;
      default:
    }
  };

  render() {
    return (
      <AppModule {...this.props} style={{ backgroundColor: '#d4d4d4' }}>
        <GpModal
          FormatModal={true}
          show={this.state.showProductLibraryGrid}
          title="Product Library"
          closeClicked={this.closeModal}
          fullScreen={true}
          fullScreenClicked={this.fullScreenClicked}
          fullScreenModal={this.state.fullScreenModal}
          modalWidth="80%"
          modalHeight="75%"
        >
          <DataGrid
            inModalHeight={this.state.fullScreenModal ? '81vh' : '56vh'}
            rowData={ProductLibraryRowData}
            view
            enableMultiSelect
            gridData={ProductLibraryJsonData}
          />
        </GpModal>
        <GpModal
          FormatModal={true}
          show={this.state.showProductCatalogGrid}
          title="Product Catalog"
          closeClicked={this.closeModal}
          fullScreen={true}
          fullScreenClicked={this.showFullScrrenProductCatalogCilcked}
          fullScreenModal={this.state.showFillScreenProductCatalog}
          modalWidth="80%"
          modalHeight="75%"
        >
          <DataGrid
            inModalHeight={this.state.showFillScreenProductCatalog ? '81vh' : '56vh'}
            rowData={ProductCatalogRowData}
            view
            enableMultiSelect
            gridData={ProductCatalogJsonData}
          />
        </GpModal>
        <GpModal
          FormatModal={true}
          show={this.state.showModuleCatalog}
          title="Module Catalog"
          closeClicked={this.closeModal}
          fullScreen={true}
          fullScreenClicked={this.showFullScreenModuleCatalogClicked}
          fullScreenModal={this.state.showFullScreenModuleCatalog}
          modalWidth="80%"
          modalHeight="75%"
        >
          <DataGrid
            inModalHeight={this.state.showFullScreenModuleCatalog ? '81vh' : '56vh'}
            rowData={ModuleCatalogRowData}
            view
            enableMultiSelect
            gridData={ModuleCatalogJsonData}
          />
        </GpModal>
        <GpModal
          FormatModal={true}
          show={this.state.showNotesLibrary}
          title="Notes Library"
          closeClicked={this.closeModal}
          fullScreen={true}
          fullScreenClicked={this.showFullScreenNotesLibraryClicked}
          fullScreenModal={this.state.showFullScreenNotesLibrary}
          modalWidth="80%"
          modalHeight="75%"
        >
          <DataGrid
            inModalHeight={this.state.showFullScreenNotesLibrary ? '81vh' : '56vh'}
            rowData={NotesLibraryRowData}
            view
            enableMultiSelect
            gridData={NotesLibraryJsonData}
          />
        </GpModal>
        <GpModal
          FormatModal={true}
          show={this.state.showManageFlightSchedules}
          title="Manage Flight Schedules"
          closeClicked={this.closeModal}
          fullScreen={true}
          fullScreenClicked={this.showFullScreenManageFlightScheduleClicked}
          fullScreenModal={this.state.showFullScreenManageFlightSchedule}
          modalWidth="80%"
          modalHeight="75%"
        >
          <DataGrid
            inModalHeight={this.state.showFullScreenManageFlightSchedule ? '81vh' : '56vh'}
            rowData={ManageScheduleRowData}
            view
            enableMultiSelect
            gridData={ManageFlightSchedulesJsonData}
          />
        </GpModal>

        <Toolbar>
          {loaderToolbarList.map((list, index) => {
            if (list.title === 'Container Catalog') {
              return (
                <div style={{ padding: '6px' }}>
                  <ConnectedModuleIcon title={list.title} icon={list.icon} />
                </div>
              );
            } else {
              return (
                <Fragment>
                  <div title={list.title} style={{ padding: '6px' }} onClick={e => this.toolBarModuleClick(list.title)}>
                    <Icon type="svg" icon={list.icon} svgIconColor="white" width="24" height="24" />
                  </div>
                  {list.seperator ? <Seperator /> : <Fragment />}
                </Fragment>
              );
            }
          })}
        </Toolbar>
        <Container
          fluid={true}
          style={{
            padding: '0',
            margin: '0',
            height: '93.3vh',
            display: 'block',
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          <Row noGutters style={{ height: '100%', width: '100%', display: 'flex', flexDirection: 'column' }}>
            {this.state.showExplorer ? (
              <div
                style={{
                  backgroundColor: '#0976b6e6',
                  marginLeft: '5px',
                  marginTop: '5px',
                  fontSize: '13px',
                  width: '20%',
                  height: '100%',
                  borderTopLeftRadius: '10px',
                }}
              >
                <FleetExplorer toggleExplorer={this.toggleExplorer} />
              </div>
            ) : (
              <CollapsedExplorerPanel
                leftCollapse
                openExplorer={this.toggleExplorer}
                panelName="Fleet Explorer"
                height="100%"
              />
            )}
            <div
              style={{
                width: this.state.showExplorer ? '79%' : '96%',
                //backgroundColor: 'white',
                // padding: '5px',
                marginLeft: '-6px',
                //marginTop: '5px',
                //borderTopRightRadius: '10px',
                paddingTop: '4px',
              }}
            >
              <DataGrid
                view
                gridData={loaderJsonData.GridConfig}
                rowData={AirCraftFamilyRowData}
                inModalHeight="87vh"
              />
            </div>
          </Row>
        </Container>
      </AppModule>
    );
  }
}

export default Loader;
