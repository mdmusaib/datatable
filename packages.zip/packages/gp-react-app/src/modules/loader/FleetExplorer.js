import React, { Component } from 'react';
import { ExplorerPanel, Tree } from '@gp/components';
import { sampleTreeData } from './FleetExplorerTreeData';

class FleetExplorer extends Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      containerToggle: true,
      bayTypeToggle: false,
      fleetToggle: false,
      sampleData: sampleTreeData,
      selectedOptions: {},
      fleetExplorerIcons: [
        {
          title: 'Refresh Tree',
          icon: 'refresh',
          color: 'white',
        },
        {
          title: 'Filter',
          icon: 'filter',
          color: 'white',
        },
        {
          title: 'Clear Filter',
          icon: 'clearFilter',
          color: 'white',
        },
      ],
    };
    return initialState;
  };

  selectOptionHandler = selectedOptions => {
    //console.log('session-----', localStorage.getItem('clickedData'));
    this.setState({
      selectedOptions,
    });
  };

  onButtonClick = title => {
    console.log(title, 'title');
  };

  render() {
    return (
      <ExplorerPanel
        explorerHeading="Fleet Explorer"
        fleetExplorerIcons={this.state.fleetExplorerIcons}
        toggleExplorer={this.props.toggleExplorer}
        onButtonClick={this.onButtonClick}
      >
        <div
          style={{
            overflowY: 'auto',
          }}
        >
          <Tree
            level="root"
            options={this.state.sampleData}
            onChange={(selectedOptions, name) => this.selectOptionHandler(selectedOptions, name)}
            selectedOptions={this.state.selectedOptions}
          />
        </div>
      </ExplorerPanel>
    );
  }
}

export default FleetExplorer;
