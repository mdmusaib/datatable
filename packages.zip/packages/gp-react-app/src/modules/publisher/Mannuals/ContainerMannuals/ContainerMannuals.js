import React, { Component } from 'react';
import { Tree } from '@gp/components';

class ContainerMannuals extends Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      sampleData: [
        {
          name: 'Container-Manual-01',
          id: 'Container-Manual-01',
          type: 'manual',
          hasChildren: false,
          childrenLoaded: false,
          subOptions: [],
        },
        {
          name: 'Container-Manual-02',
          id: 'Container-Manual-02',
          type: 'manual',
          hasChildren: false,
          childrenLoaded: false,
          subOptions: [],
        },
      ],
      selectedOptions: {},
    };
    return initialState;
  };

  selectOptionHandler = selectedOptions => {
    //console.log('session-----', localStorage.getItem('clickedData'));
    this.setState({
      selectedOptions,
    });
  };

  render() {
    return (
      <div
        style={{
          overflowY: 'auto',
        }}
      >
        <Tree
          level="root"
          options={this.state.sampleData}
          onChange={(selectedOptions, name) => this.selectOptionHandler(selectedOptions, name)}
          selectedOptions={this.state.selectedOptions}
        />
      </div>
    );
  }
}

export default ContainerMannuals;
