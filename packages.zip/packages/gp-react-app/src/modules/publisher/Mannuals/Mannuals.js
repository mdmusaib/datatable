import React, { Component } from 'react';
import { CollapsedExplorerPanel, ExplorerPanel, TreeLayout } from '@gp/components';
import { Row } from 'react-bootstrap';
import ProductMannuals from './ProductMannuals/ProductMannuals';
import ContainerMannuals from './ContainerMannuals/ContainerMannuals';
import TaskMannuals from './TaskMannuals/TaskMannuals';
import CatererPortalMannuals from './CatererPortalMannuals/CatererPortalMannuals';

class Mannuals extends Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      containerMannualToggle: false,
      productMannualToggle: true,
      taskMannualToggle: false,
      catererPortalMannualToggle: false,
    };
    return initialState;
  };

  toggleClicked = (e, headerName) => {
    e.preventDefault();
    switch (headerName) {
      case 'catererPortalMannuals':
        this.setState({
          containerMannualToggle: false,
          productMannualToggle: false,
          taskMannualToggle: false,
          catererPortalMannualToggle: true,
        });
        break;
      case 'taskMannuals':
        this.setState({
          containerMannualToggle: false,
          productMannualToggle: false,
          taskMannualToggle: true,
          catererPortalMannualToggle: false,
        });
        break;
      case 'containerMannuals':
        this.setState({
          containerMannualToggle: true,
          productMannualToggle: false,
          taskMannualToggle: false,
          catererPortalMannualToggle: false,
        });
        break;
      case 'productMannuals':
        this.setState({
          containerMannualToggle: false,
          productMannualToggle: true,
          taskMannualToggle: false,
          catererPortalMannualToggle: false,
        });
        break;
      default:
        break;
    }
  };

  render() {
    return (
      <Row noGutters style={{ height: '100%', width: '100%', display: 'flex', flexDirection: 'column' }}>
        {this.props.showExplorer ? (
          <div
            style={{
              backgroundColor: '#0976b6e6',
              marginLeft: '5px',
              marginTop: '5px',
              fontSize: '13px',
              width: '20%',
              height: '100%',
              borderTopLeftRadius: '10px',
            }}
          >
            <ExplorerPanel
              toggleExplorer={this.props.toggleExplorer}
              explorerHeading="Manual Types"
              onButtonClick={this.onButtonClick}
              fleetExplorerIcons={this.props.fleetExplorerIcons}
            >
              <TreeLayout
                header="Product Manuals"
                addGreen
                refresh
                height={this.state.productMannualToggle ? '84%' : '1%'}
                headerToggle={event => this.toggleClicked(event, 'productMannuals')}
                showList={this.state.productMannualToggle}
              >
                <ProductMannuals />
              </TreeLayout>

              <TreeLayout
                header="Container Manuals"
                addGreen
                refresh
                height={this.state.containerMannualToggle ? '84%' : '1%'}
                headerToggle={event => this.toggleClicked(event, 'containerMannuals')}
                showList={this.state.containerMannualToggle}
              >
                <ContainerMannuals />
              </TreeLayout>
              <TreeLayout
                header="Task Manuals"
                addGreen
                refresh
                height={this.state.taskMannualToggle ? '84%' : '1%'}
                headerToggle={event => this.toggleClicked(event, 'taskMannuals')}
                showList={this.state.taskMannualToggle}
              >
                <TaskMannuals />
              </TreeLayout>
              <TreeLayout
                header="Caterer Portal Manuals"
                addGreen
                refresh
                height={this.state.catererPortalMannualToggle ? '84%' : '1%'}
                headerToggle={event => this.toggleClicked(event, 'catererPortalMannuals')}
                showList={this.state.catererPortalMannualToggle}
              >
                <CatererPortalMannuals />
              </TreeLayout>
            </ExplorerPanel>
          </div>
        ) : (
          <CollapsedExplorerPanel
            leftCollapse
            openExplorer={this.props.toggleExplorer}
            panelName="Manual Types"
            height="100%"
          />
        )}
      </Row>
    );
  }
}

export default Mannuals;
