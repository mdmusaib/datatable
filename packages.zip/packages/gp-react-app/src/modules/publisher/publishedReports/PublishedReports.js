import React, { Component } from 'react';
import { Inputs, DataGrid } from '@gp/components';
import { Row, Col } from 'react-bootstrap';
import { inputChangeHandler } from '../../../assets/Form/formOnChange';
import PublishedReportsJsonData from '../../../config/publisher/ViewPublishedReports.json';
import { ViewPublishedReportsRowData } from './ViewPublishedReportsRowData';

class PublishedReports extends Component {
  state = {
    formFields1: {
      station: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            // { value: 'Select Publication', displayValue: 'Select Publication' },
            { value: '106715-106715', displayValue: '106715-106715' },
          ],
          placeholder: 'Select Publication',
        },
        value: '106715-106715',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: '',
        },
        valid: false,
        touched: false,
      },
    },
  };

  inputChangeHandler = (event, userInputIdentifier, formState) => {
    console.log(userInputIdentifier, 'event');
    let currentState = inputChangeHandler(this.state, event, userInputIdentifier, formState);
    this.setState(currentState);
  };

  render() {
    let inputs1 = [];
    const keys = Object.keys(this.state.formFields1);
    for (const key of keys) {
      const formElement = this.state.formFields1[key];
      inputs1.push(
        <div
          style={{
            width: '20%',
          }}
        >
          <Inputs
            key={key}
            name={key}
            elementType={formElement.elementType}
            elementConfig={formElement.elementConfig}
            value={formElement.value}
            valid={formElement.valid}
            touched={formElement.touched}
            changed={event => this.inputChangeHandler(event, key, 'formFields1')}
            validation={formElement.validation}
          />
        </div>,
      );
    }

    return (
      <div>
        <Col style={{ position: 'relative', top: '4px' }}>
          <Row>{inputs1}</Row>
        </Col>
        <div style={{ marginTop: '10px', marginRight: '6px', marginLeft: '5px' }}>
          <DataGrid
            gridData={PublishedReportsJsonData}
            rowData={ViewPublishedReportsRowData}
            view
            inModalHeight="71.5vh"
          />
        </div>
      </div>
    );
  }
}

export default PublishedReports;
