export default {
  seperator: props => ({
    borderLeft: `1px solid #1071a9`,
  }),
};
