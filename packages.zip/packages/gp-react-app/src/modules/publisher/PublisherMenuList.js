export default [
  {
    title: 'Publications',
    icon: 'document',
    width: '24',
  },
  {
    title: 'Mannuals',
    icon: 'file1',
    width: '24',
  },
  {
    title: 'Batch Select',
    icon: 'terms',
    width: '24',
  },
  {
    title: 'Print Queue',
    icon: 'printer',
    width: '24',
    seperator: true,
  },
  {
    title: 'Published Reports',
    icon: 'report',
    width: '24',
  },
  {
    title: 'Static Website Templates',
    icon: 'word',
    width: '24',
  },
  {
    title: 'Static Websites',
    icon: 'analysis',
    width: '24',
    seperator: true,
  },
  {
    title: 'Publisher Reference Data',
    icon: 'order',
    width: '24',
  },
];
