import React, { Component, Fragment } from 'react';
import { Toolbar, Icon, AppModule, StyledElement } from '@gp/components';
import publisherMenuList from './PublisherMenuList';
import Publications from './Publications/Publications';
import Mannuals from './Mannuals/Mannuals';
import PrintQueue from './printQueue/PrintQueue';
import PublishedReports from './publishedReports/PublishedReports';
import publisherStyle from './PublisherStyle';

let Seperator = StyledElement('div')(publisherStyle.seperator);

class Publisher extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedMenu: 'Publications',
      showExplorer: true,
      fleetExplorerIcons: [],
    };
  }

  onMenuCLick = list => {
    switch (list) {
      case 'Publications':
        this.setState({ selectedMenu: 'Publications' });
        break;
      case 'Mannuals':
        this.setState({ selectedMenu: 'Mannuals' });
        break;
      case 'Batch Select':
        break;
      case 'Print Queue':
        this.setState({ selectedMenu: 'Print Queue' });
        break;
      case 'Published Reports':
        this.setState({ selectedMenu: 'Published Reports' });
        break;
      case 'Static Website Templates':
        break;
      case 'Static Websites':
        break;
      case 'Publisher Reference Data':
        break;
      default:
    }
  };

  toggleExplorer = event => {
    event.preventDefault();
    this.setState({
      showExplorer: !this.state.showExplorer,
    });
  };

  renderPublisherScreens = () => {
    console.log(this.state.selectedMenu, 'menu');
    switch (this.state.selectedMenu) {
      case 'Publications':
        return <Publications />;
      case 'Mannuals':
        return (
          <Mannuals
            showExplorer={this.state.showExplorer}
            toggleExplorer={this.toggleExplorer}
            fleetExplorerIcons={this.state.fleetExplorerIcons}
          />
        );
      case 'Batch Select':
        break;
      case 'Print Queue':
        return <PrintQueue />;
      case 'Published Reports':
        return <PublishedReports />;
      case 'Static Website Templates':
        break;
      case 'Static Websites':
        break;
      case 'Publisher Reference Data':
        break;
      default:
    }
  };

  render() {
    return (
      <AppModule {...this.props} style={{ backgroundColor: '#d4d4d4' }}>
        <Toolbar>
          {publisherMenuList.map((list, index) => (
            <Fragment>
              <div title={list.title} style={{ padding: '6px' }} onClick={() => this.onMenuCLick(list.title)}>
                <Icon type="svg" icon={list.icon} svgIconColor="white" width="24" height="24" />
              </div>
              {list.seperator ? <Seperator /> : <Fragment />}
            </Fragment>
          ))}
        </Toolbar>
        <div
          style={{
            padding: '0',
            height: '92.8vh',
            display: 'block',
            position: 'relative',
            overflow: 'hidden',
            margin: '0px',
          }}
        >
          {this.renderPublisherScreens()}
        </div>
      </AppModule>
    );
  }
}

export default Publisher;
