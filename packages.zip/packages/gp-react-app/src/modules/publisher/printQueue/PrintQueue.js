import React, { Component, Fragment } from 'react';
import { Checkbox, DataGrid } from '@gp/components';
import PrintQueueJsonData from '../../../config/publisher/ManagePrintQueue.json';
import { ManagePrintQueueRowData } from './ManagePrintQueueRowData';

class PrintQueue extends Component {
  render() {
    return (
      <Fragment>
        <div style={{ height: '5%', position: 'relative', bottom: '14px' }}>
          <Checkbox
            name="Name"
            elementConfig={{
              placeholder: 'Include Printed Reports',
            }}
            //   value="includePrintedReports"
            validation={{
              required: false,
            }}
            valid={false}
            touched={false}
          />
        </div>
        <div style={{ marginTop: '0px', marginRight: '6px', marginLeft: '5px' }}>
          <DataGrid
            gridData={PrintQueueJsonData}
            rowData={ManagePrintQueueRowData}
            view
            enableMultiSelect
            inModalHeight="74.2vh"
          />
        </div>
      </Fragment>
    );
  }
}

export default PrintQueue;
