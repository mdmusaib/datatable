import React, { Component } from 'react';
import { DataGrid } from '@gp/components';
import PublicationJsonData from '../../../config/publisher/Publication.json';
import { PublicationRowData } from './PublicationRowData';

class Publisher extends Component {
  render() {
    return (
      <div style={{ margin: '5px' }}>
        <DataGrid
          gridData={PublicationJsonData}
          rowData={PublicationRowData}
          view
          enableMultiSelect
          inModalHeight="79vh"
        />
      </div>
    );
  }
}

export default Publisher;
