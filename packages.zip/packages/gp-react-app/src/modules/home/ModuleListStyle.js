import { keyframes } from '@emotion/core';
const slideUp = keyframes`
0% { transform: translateY(10px);  opacity:0 }
100% { transform: translateY(1px); opacity:1 }
`;
const slideDown = keyframes`
0% { transform: translateY(-10px);  opacity:0 }
100% { transform: translateY(1px); opacity:1 }
`;

export default {
  CardTile: props => {
    return {
      display: 'flex',
      bg: props.theme.colors.paxia.white,
      width: '100px',
      height: '125px',
      borderRadius: '5px',
      justifyContent: 'center',
      alignItems: 'center',
      flexWrap: 'wrap',
      //boxShadow: 'tileShadow',
      flexDirection: 'column',
      transition: 'color 0.15s ease-in-out, background-color 0.15s ease-in-out',
      boxShadow:
        '0 0.46875rem 2.1875rem rgba(8, 10, 37, 0.03), 0 0.9375rem 1.40625rem rgba(8, 10, 37, 0.03), 0 0.25rem 0.53125rem rgba(8, 10, 37, 0.05), 0 0.125rem 0.1875rem rgba(8, 10, 37, 0.03)',
      //boxShadow: '0px 3px 5px #ccc',
      '&:hover': {
        // bg: props.theme.colors.paxia.accent_eggplant,
        background: '#006098', //'radial-gradient(#006098, #003b71)',
        //boxShadow: '0 0 11px 1px #2f2f2f',
        boxShadow:
          '0 16px 26px -10px rgba(0, 96, 152, 0.56), 0 4px 25px 0px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(84, 92, 216, 0.2)',
        // boxShadow: '0px 3px 5px #ccc0',
        color: props.theme.colors.paxia.white,
      },
      '&:hover > svg': {
        fill: props.theme.colors.paxia.white,
      },
      '& > span': {
        fontFamily: props.theme.fonts.roboto,
        cursor: 'default',
        fontSize: '.78rem',
        fontWeight: '500',
        display: 'block',
        textAlign: 'center',
        lineHeight: '1.3',
        paddingTop: '5px',
        userSelect: 'none',
        animation: `${slideUp} .2s ease`,
      },
      '& > img, & > svg': {
        animation: `${slideDown} .2s ease`,
      },
    };
  },
  CardWrapper: props => ({
    zIndex: 200,
    justifySelf: 'center',
    alignSelf: 'center',
    display: 'grid',
    gridTemplateColumns: 'repeat(6, 100px)',
    gridTemplateRows: '20px 125px 125px 20px',
    gridColumnGap: '15px',
    gridRowGap: '15px',
    borderRadius: '6px',
    //background: '#ccc',
    //boxShadow: '12px 12px 24px #ededed, -12px -12px 24px #ffffff',
    padding: '50px 30px 50px',
    width: 'fit-content',
    height: 'fit-content',
    '& > img': {
      gridColumn: '1 / span 6',
    },
    '& > span ': {
      fontFamily: props.theme.fonts.roboto,
      // with border
      /* width: '100%',
      height: '30px',
      backgroundColor: 'white',
      borderRadius: '30px',
      paddingTop: '15px',
      paddingLeft: '15px',
      boxShadow: '0px 3px 3px rgb(0,0,0,.1)', */
      //Existing
      color: props.theme.colors.paxia.grey,
      minHeight: '50px',
      fontSize: '12px',
      gridColumn: '1 / span 6',
      animation: `${slideDown} .5s ease`,
    },
    //bg: colors.paxia.accent_eggplant,
  }),
};

export const HomeStyle = props => ({
  display: props.hide ? 'none' : 'grid',
  width: '100%',
  height: '100%',
  // backgroundImage: 'linear-gradient(-145deg, #007580, #662d91)',
  backgroundColor: '#f0f3f5',
});

export const BGTopTriangleStyle = props => ({
  width: 0,
  height: 0,
  borderTop: '100vh solid #006098',
  position: 'absolute',
  right: 0,
  borderLeft: '100vh solid transparent',
});
