import React from 'react';
import { connect } from 'react-redux';
import { addModule } from '../../redux/actions/AppHomeAction';
import modules from './MouleList';
import ModuleListView from './ModuleListView';
import { StyledElement } from '@gp/components';
import { HomeStyle, BGTopTriangleStyle } from './ModuleListStyle';

const HomeWrapper = StyledElement('div')(HomeStyle);
const BGTopTriangle = StyledElement('div')(BGTopTriangleStyle);

const HomePage = props => {
  let ef = function(name) {
    if (name.module) props.addModule(name);
    //console.log(name);
    // switch (name) {
    //   case 'Parts Catalog':
    //     props.addModule(name);
    //     break;
    //   default:
    //     return true;
    // }
  };
  return (
    <HomeWrapper {...props}>
      {/* <span>This is Test Module</span>
      <button onClick={e => ef('Parts Catalog')}>enable</button> */}
      {/* <ModuleTiles modules={modules} loadModule={name => ef(name)} /> */}
      <ModuleListView modules={modules} loadModule={name => ef(name)}></ModuleListView>
      {/* <BGTopTriangle />
      <div
        style={{
          width: 0,
          height: 0,
          borderBottom: '100vh solid #007580',
          position: 'absolute',
          right: 0,
          borderLeft: '150vh solid transparent',
        }}
      ></div> */}
    </HomeWrapper>
  );
};

const mapDispatchToProps = dispatch => {
  return {
    addModule: module => dispatch(addModule(module)),
  };
};

export default connect(null, mapDispatchToProps)(HomePage);
