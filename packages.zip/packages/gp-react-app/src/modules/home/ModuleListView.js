import React, { useState } from 'react';
import cardStyle from './ModuleListStyle';
import { StyledElement, Icon } from '@gp/components';

const StyledWrap = StyledElement('div')(cardStyle.CardWrapper);

const StyledCard = props => {
  let onCardClick = function() {
    props.onCardClick(props.module);
  };
  let onCardFocus = function() {
    props.onCardFocus(props.module.desc);
  };
  let onCardBlur = function() {
    props.onCardBlur();
  };
  let StyledDiv = StyledElement('div')(cardStyle.CardTile);
  return (
    <StyledDiv onMouseEnter={onCardFocus} onMouseLeave={onCardBlur} onClick={onCardClick}>
      {props.children}
    </StyledDiv>
  );
};
let StyledMemoCard = React.memo(StyledCard, (prev, next) => {
  if (prev.module.moduleName === next.module.moduleName) return true;
  else return false;
});

const ModuleList = props => {
  let loaditem = module => props.loadModule(module);
  let displayInfo = name => setModuleDesc(name);
  let hideInfo = name => setModuleDesc('');
  const [moduleDesc, setModuleDesc] = useState('');

  return (
    <StyledWrap>
      <Icon icon="moduleIcons.GPLogo" style={{ filter: 'brightness(0.7)' }} width="78" height="18"></Icon>
      {props.modules.map((item, index) => (
        <StyledMemoCard
          key={index}
          onCardFocus={displayInfo}
          onCardBlur={hideInfo}
          onCardClick={loaditem}
          module={item}
        >
          <Icon type="svg" svgIconColor={item.iconColor} icon={item.icon} width="35" height="35" />
          <span>{item.moduleName}</span>
        </StyledMemoCard>
      ))}
      {moduleDesc !== undefined && moduleDesc !== '' ? <span>{moduleDesc}</span> : null}
    </StyledWrap>
  );
};

export default ModuleList;
