import React, { Component, Fragment } from 'react';
import { Accordion, CollapsedAccordion, StyledElement, DataGrid } from '@gp/components';
import catererPortalStyle from '../CatererPortalStyle';
import SearchFlights from './SearchFlights';
import flightDepartureBoardJson from '../../../config/catererPortal/FlightDepartureBoard.json';
import { FlightDepartureBoardRowData } from './FlightDepartureBoardRowData';

let StyledFlightDepartureBoard = StyledElement('div')(catererPortalStyle.catererPortalLayout);

class FlightDepartureBoard extends Component {
  render() {
    return (
      <StyledFlightDepartureBoard>
        <Fragment>
          {!this.props.showAccordion ? (
            <Accordion accordionHeading="Search Flights" toggleAccordion={this.props.toggleAccordion} color="#006098">
              <SearchFlights searchFlights={this.props.searchFlights} />
            </Accordion>
          ) : (
            <CollapsedAccordion
              panelName="Search Flights"
              height="100%"
              toggleAccordion={this.props.toggleAccordion}
              color="#006098"
            />
          )}
        </Fragment>
        {this.props.showGrid ? (
          <DataGrid
            inModalHeight={this.props.hideSearchStations ? '74vh' : '56vh'}
            gridData={flightDepartureBoardJson}
            rowData={FlightDepartureBoardRowData}
            view
            enableMultiSelect
          />
        ) : (
          <Fragment />
        )}
      </StyledFlightDepartureBoard>
    );
  }
}

export default FlightDepartureBoard;
