import React, { Component } from 'react';
import { Inputs, Button, Icon } from '@gp/components';
import { Container, Row, Col } from 'react-bootstrap';
import { inputChangeHandler } from '../../../assets/Form/formOnChange';

class SearchFlights extends Component {
  state = {
    formFields1: {
      station: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'All Stations', displayValue: 'All Stations' },
            { value: 'AAL', displayValue: 'AAL' },
            { value: 'AAN', displayValue: 'AAN' },
            { value: 'AAR', displayValue: 'AAR' },
            { value: 'ABE', displayValue: 'ABE' },
          ],
          placeholder: 'Station',
        },
        value: 'All Stations',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: '',
        },
        valid: false,
        touched: false,
      },
      flightNumber: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'string',
          type: 'text',
          placeholder: 'Flight Number',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[0-9]*$/,
          message: 'Should be a number',
        },
        valid: false,
        touched: false,
      },
      aircraftType: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'ARF', displayValue: 'ARF' },
            { value: 'ARI', displayValue: 'ARI' },
            { value: 'APC', displayValue: 'APC' },
          ],
          placeholder: 'Aircraft Type',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      flightType: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'ARF', displayValue: 'ARF' },
            { value: 'ARI', displayValue: 'ARI' },
            { value: 'APC', displayValue: 'APC' },
          ],
          placeholder: 'Flight Type',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      exchangeType: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'ARF', displayValue: 'ARF' },
            { value: 'ARI', displayValue: 'ARI' },
            { value: 'APC', displayValue: 'APC' },
          ],
          placeholder: 'Exchange Type',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      port: {
        elementType: 'RadioButton',
        elementConfig: {
          options: [
            { value: 'DEP', displayValue: 'DEP' },
            { value: 'ARR', displayValue: 'ARR' },
            { value: 'BOTH', displayValue: 'BOTH' },
          ],
          placeholder: '',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      airline: {
        elementType: 'SingleSelectDropdown',
        elementConfig: {
          options: [
            { value: 'ARF', displayValue: 'ARF' },
            { value: 'ARI', displayValue: 'ARI' },
            { value: 'APC', displayValue: 'APC' },
          ],
          placeholder: 'Airline',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[a-zA-Z& (),._"\'-]*$/,
          message: 'test abcd abcd acbd test',
        },
        valid: false,
        touched: false,
      },
      startDate: {
        elementType: 'DatePicker',
        elementConfig: {
          placeholder: 'Start Date',
          // openToDate: new Date('01/01/2000'),
          width: '143px',
          height: '25px',
        },
        value: '',
        onChangeDatePicker: this.handleDatepickerChanges,
        validation: {
          required: false,
          pattern: /^(((((((0?[13578])|(1[02]))[\.\-/]?((0?[1-9])|([12]\d)|(3[01])))|(((0?[469])|(11))[\.\-/]?((0?[1-9])|([12]\d)|(30)))|((0?2)[\.\-/]?((0?[1-9])|(1\d)|(2[0-8]))))[\.\-/]?((\d{2})?([\d][\d]))))|((0?2)[\.\-/]?(29)[\.\-/]?(((19)|(20))?(([02468][048])|([13579][26])))))$/,
          message: 'test abcd abcd acbd test',
        },
        disabled: false,
        minDate: null,
        valid: false,
        touched: false,
      },
      startTime: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'string',
          type: 'text',
          placeholder: 'Start Time(hh:mm)',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[0-9]*$/,
          message: 'Should be a number',
        },
        valid: false,
        touched: false,
      },
      endDate: {
        elementType: 'DatePicker',
        elementConfig: {
          placeholder: 'End Date',
          // openToDate: new Date('01/01/2000'),
          width: '143px',
          height: '25px',
        },
        value: '',
        onChangeDatePicker: this.handleDatepickerChanges,
        validation: {
          required: false,
          pattern: /^(((((((0?[13578])|(1[02]))[\.\-/]?((0?[1-9])|([12]\d)|(3[01])))|(((0?[469])|(11))[\.\-/]?((0?[1-9])|([12]\d)|(30)))|((0?2)[\.\-/]?((0?[1-9])|(1\d)|(2[0-8]))))[\.\-/]?((\d{2})?([\d][\d]))))|((0?2)[\.\-/]?(29)[\.\-/]?(((19)|(20))?(([02468][048])|([13579][26])))))$/,
          message: 'test abcd abcd acbd test',
        },
        disabled: false,
        minDate: null,
        valid: false,
        touched: false,
      },
      endTime: {
        elementType: 'InputField',
        elementConfig: {
          inputType: 'string',
          type: 'text',
          placeholder: 'End Time(hh:mm)',
        },
        value: '',
        validation: {
          required: false,
          pattern: /^[0-9]*$/,
          message: 'Should be a number',
        },
        valid: false,
        touched: false,
      },
    },
  };

  inputChangeHandler = (event, userInputIdentifier, formState) => {
    let currentState = inputChangeHandler(this.state, event, userInputIdentifier, formState);
    this.setState(currentState);
  };

  handleDatepickerChanges = (event, userInputIdentifier, state = 'formFields1') => {
    console.log(event, userInputIdentifier, 'event, userInputIdentifier');
    if (event === null) {
      let currentState = this.state;

      let userInputIdentifier = 'endDate';

      const updatedUserForm = {
        ...this.state[state],
      };
      const updatedUserFormElement = {
        ...updatedUserForm[userInputIdentifier],
      };

      updatedUserFormElement.disabled = true;
      updatedUserForm[userInputIdentifier] = updatedUserFormElement;
      currentState[state] = updatedUserForm;
      console.log(updatedUserFormElement, 'updatedUserFormElement');
      this.setState({
        updatedUserFormElement,
      });
      // console.log(updatedUserFormElement)
    } else {
      let currentState = this.state;
      let userInputIdentifier = 'endDate';

      const updatedUserForm = {
        ...this.state[state],
      };
      console.log(updatedUserForm, 'updatedUserFormElement');
      const updatedUserFormElement = {
        ...updatedUserForm[userInputIdentifier],
      };
      updatedUserFormElement.disabled = false;
      updatedUserForm[userInputIdentifier] = updatedUserFormElement;
      currentState[state] = updatedUserForm;
      this.setState({
        updatedUserFormElement,
      });
    }
    let currentState = this.state;
    const updatedForm = {
      ...this.state[state],
    };

    const updatedFormElement = {
      ...updatedForm[userInputIdentifier],
    };
    if (userInputIdentifier.elementType === 'effectiveDate') {
      updatedFormElement.value = event;

      let userInputIdentifier1 = 'endDate';
      const updatedForm1 = {
        ...this.state[state],
      };
      const updatedFormElement1 = {
        ...updatedForm1[userInputIdentifier1],
      };
      updatedFormElement1.minDate = event;
      updatedForm[userInputIdentifier.elementType] = updatedFormElement;
      currentState[state] = updatedForm;
      this.setState(
        {
          updatedFormElement,
          updatedFormElement1,
        },
        () => {
          console.log(this.state);
        },
      );
    }
    updatedFormElement.value = event;
    updatedFormElement.valid = this.checkValidity(updatedFormElement.value, updatedFormElement.validation);
    updatedFormElement.touched = true;
    updatedForm[userInputIdentifier] = updatedFormElement;

    let formIsValid = true;
    let formElements = updatedForm;
    for (let userInputIdentifier in formElements) {
      if (
        formElements[userInputIdentifier].value !== undefined &&
        formElements[userInputIdentifier].validation.required
      ) {
        formIsValid = formElements[userInputIdentifier].valid && formIsValid;
      }
    }
    currentState[state] = updatedForm;
    currentState.formIsValid = formIsValid;
    this.setState(currentState);
  };

  checkValidity(value, rules, elementConfig) {
    console.log(value, rules, elementConfig, 'checkValidity');
    let isValid = false;
    if (value === '') {
      isValid = false;
    } else if (rules.required === true && elementConfig.type === 'text') {
      if (typeof value === 'string') {
        isValid = rules.pattern.test(value);
      } else {
        isValid = value.trim() !== '';
      }
    } else {
      isValid = true;
    }
    return isValid;
  }

  render() {
    let inputs1 = [];
    const keys = Object.keys(this.state.formFields1);
    for (const key of keys) {
      const formElement = this.state.formFields1[key];
      inputs1.push(
        <div
          style={
            formElement.elementType === 'RadioButton'
              ? {
                  display: 'flex',
                  alignItems: 'center',
                  width: '16%',
                  margin: '0px 15px 6px',
                }
              : {
                  width: '16%',
                  display: 'flex',
                }
          }
        >
          <Inputs
            key={key}
            name={key}
            elementType={formElement.elementType}
            elementConfig={formElement.elementConfig}
            value={formElement.value}
            valid={formElement.valid}
            touched={formElement.touched}
            changed={event => {
              formElement.elementType === 'DatePicker'
                ? this.handleDatepickerChanges(event, key)
                : this.inputChangeHandler(event, key, 'formFields1');
            }}
            validation={formElement.validation}
          />
        </div>,
      );
    }

    return (
      <div style={{ width: '100%', height: '100%' }} autoComplete="off">
        <div style={{ paddingTop: '11px' }}>
          <Col style={{ position: 'relative', left: '30px' }}>
            <Row>
              {inputs1}
              <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '14px' }}>
                <Button
                  style={{ position: 'absolute', right: '142px', padding: '3px 10px', fontSize: '12px' }}
                  //icon={<Icon icon="search" type="svg" style={{ marginRight: '5px' }} />}
                  onButtonClick={this.props.searchFlights}
                >
                  <span style={{ padding: '5px' }}>Search</span>
                </Button>
              </div>
            </Row>
          </Col>
        </div>
      </div>
    );
  }
}

export default SearchFlights;
