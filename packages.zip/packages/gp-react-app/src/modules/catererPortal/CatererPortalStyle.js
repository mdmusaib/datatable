export default {
  catererPortalLayout: props => {
    return {
      backgroundColor: props.theme.colors.paxia_grid.grey_34,
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      borderTopLeftRadius: '10px',
      borderTopRightRadius: '10px',
    };
  },

  seperator: props => ({
    borderLeft: `1px solid #1071a9`,
  }),
};
