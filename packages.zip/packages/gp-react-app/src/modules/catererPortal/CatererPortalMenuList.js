export default [
  {
    title: 'Flight Departure Board',
    icon: 'setEndDateSVG',
    width: '24',
    seperator: true,
  },
  {
    title: 'Container Catalog',
    icon: 'containerCatalog',
    width: '24',
  },
  {
    title: 'Parts Catalog',
    icon: 'partsCatalog',
    width: '24',
  },
  {
    title: 'Product Stowage Summary',
    icon: 'partsUsage',
    width: '24',
    seperator: true,
  },
  {
    title: 'Design Label',
    icon: 'document',
    width: '24',
  },
  {
    title: 'Label Printing Preferences',
    icon: 'printer',
    width: '24',
  },
  {
    title: 'Label Template Preferences',
    icon: 'group',
    width: '24',
    seperator: true,
  },
  {
    title: 'Generated Reports',
    icon: 'report',
    width: '24',
  },
  {
    title: 'Flight KDT and Watermark',
    icon: 'calendar',
    width: '24',
  },
];
