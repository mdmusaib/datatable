import React, { Component, Fragment } from 'react';
import { Toolbar, Icon, AppModule, DataGrid, StyledElement } from '@gp/components';
import { Row, Container } from 'react-bootstrap';
import catererMenuList from './CatererPortalMenuList';
import FlightDepartureBoard from './FlightDepartureBoard/FlightDepartureBoard';
import catererPortalStyle from './CatererPortalStyle';
import { CatererContainerCatalogRowData } from '../catererPortal/catererContainerCatalog/CatererContainerCatalogRowData';
import { partCatalogRowData } from '../partsCatalog/PartsCatalogRowData';
import CatererContainerCatalogJsonData from '../../config/containerCatalog/ContainerCatalogData.json';
import PartCatalogJsonData from '../../config/PartCatalogData.json';

let Seperator = StyledElement('div')(catererPortalStyle.seperator);

class CatererPortal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showExplorer: true,
      hideSearchStations: false,
      showGrid: false,
      showFlightDepartureBoard: true,
      gridJsonData: CatererContainerCatalogJsonData,
      gridRowData: CatererContainerCatalogRowData,
      showContainerCatalog: false,
      showPartsCatalog: false,
      gridReRenderToogle: true,
    };
  }

  toggleAccordion = event => {
    event.preventDefault();
    this.setState({
      showAccordion: !this.state.showAccordion,
      hideSearchStations: !this.state.hideSearchStations,
    });
  };

  searchFlights = () => {
    console.log('onButtonClick');
    this.setState({ showGrid: true });
  };

  toolBarModuleClick = title => {
    switch (title) {
      case 'Flight Departure Board':
        this.setState({ showFlightDepartureBoard: true, showContainerCatalog: false, showPartsCatalog: false });
        break;
      case 'Container Catalog':
        this.setState({
          gridJsonData: CatererContainerCatalogJsonData,
          gridRowData: CatererContainerCatalogRowData,
          showContainerCatalog: true,
          showFlightDepartureBoard: false,
          showPartsCatalog: false,
          gridReRenderToogle: !this.state.gridReRenderToogle,
        });
        break;
      case 'Parts Catalog':
        this.setState({
          gridJsonData: PartCatalogJsonData,
          gridRowData: partCatalogRowData,
          showContainerCatalog: false,
          showFlightDepartureBoard: false,
          showPartsCatalog: true,
          gridReRenderToogle: !this.state.gridReRenderToogle,
        });
        break;
      default:
    }
  };

  render() {
    return (
      <AppModule {...this.props} style={{ backgroundColor: '#d4d4d4' }}>
        <Toolbar>
          {catererMenuList.map((list, index) => (
            <Fragment>
              <div title={list.title} style={{ padding: '6px' }} onClick={e => this.toolBarModuleClick(list.title)}>
                <Icon type="svg" icon={list.icon} svgIconColor="white" width="24" height="24" />
              </div>
              {list.seperator ? <Seperator /> : <Fragment />}
            </Fragment>
          ))}
        </Toolbar>
        <div
          style={{
            padding: '0',
            height: '91.5vh',
            display: 'block',
            position: 'relative',
            overflow: 'hidden',
            marginLeft: '5px',
            marginRight: '5px',
            marginTop: '5px',
          }}
        >
          {this.state.showFlightDepartureBoard ? (
            <FlightDepartureBoard
              toggleAccordion={this.toggleAccordion}
              hideSearchStations={this.state.hideSearchStations}
              showAccordion={this.state.showAccordion}
              searchFlights={this.searchFlights}
              showGrid={this.state.showGrid}
            />
          ) : (
            <Fragment />
          )}
          {this.state.showContainerCatalog || this.state.showPartsCatalog ? (
            <DataGrid
              gridData={this.state.gridJsonData}
              gridReRenderToogle={this.state.gridReRenderToogle}
              rowData={this.state.gridRowData}
              view
              enableMultiSelect
              inModalHeight="79vh"
            />
          ) : (
            <Fragment />
          )}
        </div>
      </AppModule>
    );
  }
}

export default CatererPortal;
