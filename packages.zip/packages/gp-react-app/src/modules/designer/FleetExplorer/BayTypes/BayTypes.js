import React, { Component } from 'react';
import { Tree } from '@gp/components';

class BayTypes extends Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      sampleData: [
        {
          name: 'BAY-TEST-01',
          id: 'BAY-TEST-01',
          type: 'DESIGNER_BAY_TYPE',
          hasChildren: true,
          childrenLoaded: true,
          subOptions: [
            {
              name: 'ITEM-ITEM-01',
              id: 'ITEM-ITEM-01',
              type: 'DESIGNER_BT_RULES',
              hasChildren: false,
              childrenLoaded: false,
              subOptions: [],
            },
            {
              name: 'ITEM-ITEM-02',
              id: 'ITEM-ITEM-02',
              type: 'DESIGNER_BT_RULES',
              hasChildren: false,
              childrenLoaded: false,
              subOptions: [],
            },
          ],
        },
        {
          name: 'BAY-TEST-02',
          id: 'BAY-TEST-02',
          type: 'DESIGNER_BAY_TYPE',
          hasChildren: true,
          childrenLoaded: true,
          subOptions: [
            {
              name: 'ITEM-ITEM-01',
              id: 'ITEM-ITEM-01',
              type: 'DESIGNER_BT_RULES',
              hasChildren: false,
              childrenLoaded: false,
              subOptions: [],
            },
            {
              name: 'ITEM-ITEM-02',
              id: 'ITEM-ITEM-02',
              type: 'DESIGNER_BT_RULES',
              hasChildren: false,
              childrenLoaded: false,
              subOptions: [],
            },
            {
              name: 'ITEM-ITEM-03',
              id: 'ITEM-ITEM-03',
              type: 'DESIGNER_BT_RULES',
              hasChildren: false,
              childrenLoaded: false,
              subOptions: [],
            },
          ],
        },
        {
          name: 'BAY-TEST-03',
          id: 'BAY-TEST-03',
          type: 'DESIGNER_BAY_TYPE',
          hasChildren: true,
          childrenLoaded: true,
          subOptions: [
            {
              name: 'ITEM-ITEM-01',
              id: 'ITEM-ITEM-01',
              type: 'DESIGNER_BT_RULES',
              hasChildren: false,
              childrenLoaded: false,
              subOptions: [],
            },
            {
              name: 'ITEM-ITEM-02',
              id: 'ITEM-ITEM-02',
              type: 'DESIGNER_BT_RULES',
              hasChildren: false,
              childrenLoaded: false,
              subOptions: [],
            },
          ],
        },
      ],
      selectedOptions: {},
    };
    return initialState;
  };

  selectOptionHandler = selectedOptions => {
    //console.log('session-----', localStorage.getItem('clickedData'));
    this.setState({
      selectedOptions,
    });
  };

  render() {
    return (
      <div
        style={{
          overflowY: 'auto',
        }}
      >
        <Tree
          level="root"
          options={this.state.sampleData}
          onChange={(selectedOptions, name) => this.selectOptionHandler(selectedOptions, name)}
          selectedOptions={this.state.selectedOptions}
        />
      </div>
    );
  }
}

export default BayTypes;
