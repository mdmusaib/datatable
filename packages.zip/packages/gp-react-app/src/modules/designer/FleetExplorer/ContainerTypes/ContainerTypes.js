import React, { Component } from 'react';
import { Tree } from '@gp/components';

class ContainerTypes extends Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      sampleData: [
        {
          name: 'CONTAINER-TEST-01',
          id: 'CONTAINER-TEST-01',
          type: 'DESIGNER_CONTAINER_TYPE',
          hasChildren: true,
          childrenLoaded: true,
          subOptions: [
            {
              name: 'Parts',
              id: 'Parts',
              type: 'DESIGNER_CT_STATIC_PARTS',
              hasChildren: true,
              childrenLoaded: true,
              subOptions: [
                {
                  name: 'BASE-PART-1',
                  id: 'BASE-PART-1',
                  type: 'DESIGNER_CT_PARTS',
                  hasChildren: false,
                  childrenLoaded: false,
                  subOptions: [],
                },
              ],
            },
            {
              name: 'Slots',
              id: 'Slots',
              type: 'DESIGNER_CT_STATIC_SLOTS',
              hasChildren: true,
              childrenLoaded: true,
              subOptions: [
                {
                  name: 'Slot 1',
                  id: 'Slot 1',
                  type: 'DESIGNER_CT_SLOT_RULES',
                  hasChildren: true,
                  childrenLoaded: true,
                  subOptions: [
                    {
                      name: 'ITEM-ITEM_01',
                      id: 'ITEM-ITEM_01',
                      type: 'DESIGNER_CONTAINER_TYPE',
                      hasChildren: false,
                      childrenLoaded: false,
                      subOptions: [],
                    },
                    {
                      name: 'ITEM-ITEM_02',
                      id: 'ITEM-ITEM_02',
                      type: 'DESIGNER_CONTAINER_TYPE',
                      hasChildren: false,
                      childrenLoaded: false,
                      subOptions: [],
                    },
                    {
                      name: 'ITEM-ITEM_03',
                      id: 'ITEM-ITEM_03',
                      type: 'DESIGNER_CONTAINER_TYPE',
                      hasChildren: false,
                      childrenLoaded: false,
                      subOptions: [],
                    },
                    {
                      name: 'ITEM-ITEM_04',
                      id: 'ITEM-ITEM_04',
                      type: 'DESIGNER_CONTAINER_TYPE',
                      hasChildren: false,
                      childrenLoaded: false,
                      subOptions: [],
                    },
                  ],
                },
                {
                  name: 'Slot 2',
                  id: 'Slot 2',
                  type: 'DESIGNER_CT_SLOT_RULES',
                  hasChildren: true,
                  childrenLoaded: true,
                  subOptions: [
                    {
                      name: 'ITEM-ITEM_01',
                      id: 'ITEM-ITEM_01',
                      type: 'DESIGNER_CONTAINER_TYPE',
                      hasChildren: false,
                      childrenLoaded: false,
                      subOptions: [],
                    },
                  ],
                },
              ],
            },
            {
              name: 'Containers',
              id: 'Containers',
              type: 'DESIGNER_CT_STATIC_CONTAINERS',
              hasChildren: true,
              childrenLoaded: true,
              subOptions: [
                {
                  name: 'Containers-ITEM_01',
                  id: 'Containers-ITEM_01',
                  type: 'DESIGNER_CT_STATIC_CONTAINERS',
                  hasChildren: false,
                  childrenLoaded: false,
                  subOptions: [],
                },
                {
                  name: 'Containers-ITEM_02',
                  id: 'Containers-ITEM_02',
                  type: 'DESIGNER_CT_STATIC_CONTAINERS',
                  hasChildren: false,
                  childrenLoaded: false,
                  subOptions: [],
                },
              ],
            },
          ],
        },
        {
          name: 'CONTAINER-TEST-02',
          id: 'CONTAINER-TEST-02',
          type: 'DESIGNER_CONTAINER_TYPE',
          hasChildren: true,
          childrenLoaded: true,
          subOptions: [
            {
              name: 'Parts',
              id: 'Parts',
              type: 'DESIGNER_CT_STATIC_PARTS',
              hasChildren: true,
              childrenLoaded: true,
              subOptions: [
                {
                  name: 'BASE-PART-1',
                  id: 'BASE-PART-1',
                  type: 'DESIGNER_CT_PARTS',
                  hasChildren: false,
                  childrenLoaded: false,
                  subOptions: [],
                },
              ],
            },
            {
              name: 'Slots',
              id: 'Slots',
              type: 'DESIGNER_CT_STATIC_SLOTS',
              hasChildren: true,
              childrenLoaded: true,
              subOptions: [
                {
                  name: 'Slot 1',
                  id: 'Slot 1',
                  type: 'DESIGNER_CT_SLOT_RULES',
                  hasChildren: true,
                  childrenLoaded: true,
                  subOptions: [
                    {
                      name: 'ITEM-ITEM_01',
                      id: 'ITEM-ITEM_01',
                      type: 'DESIGNER_CONTAINER_TYPE',
                      hasChildren: false,
                      childrenLoaded: false,
                      subOptions: [],
                    },
                    {
                      name: 'ITEM-ITEM_02',
                      id: 'ITEM-ITEM_02',
                      type: 'DESIGNER_CONTAINER_TYPE',
                      hasChildren: false,
                      childrenLoaded: false,
                      subOptions: [],
                    },
                    {
                      name: 'ITEM-ITEM_03',
                      id: 'ITEM-ITEM_03',
                      type: 'DESIGNER_CONTAINER_TYPE',
                      hasChildren: false,
                      childrenLoaded: false,
                      subOptions: [],
                    },
                    {
                      name: 'ITEM-ITEM_04',
                      id: 'ITEM-ITEM_04',
                      type: 'DESIGNER_CONTAINER_TYPE',
                      hasChildren: false,
                      childrenLoaded: false,
                      subOptions: [],
                    },
                  ],
                },
              ],
            },
            {
              name: 'Containers',
              id: 'Containers',
              type: 'DESIGNER_CT_STATIC_CONTAINERS',
              hasChildren: true,
              childrenLoaded: true,
              subOptions: [
                {
                  name: 'Containers-ITEM_01',
                  id: 'Containers-ITEM_01',
                  type: 'DESIGNER_CT_STATIC_CONTAINERS',
                  hasChildren: false,
                  childrenLoaded: false,
                  subOptions: [],
                },
              ],
            },
          ],
        },
        {
          name: 'CONTAINER-TEST-03',
          id: 'CONTAINER-TEST-03',
          type: 'DESIGNER_CONTAINER_TYPE',
          hasChildren: true,
          childrenLoaded: true,
          subOptions: [],
        },
      ],
      selectedOptions: {},
    };
    return initialState;
  };

  selectOptionHandler = selectedOptions => {
    //console.log('session-----', localStorage.getItem('clickedData'));
    this.setState({
      selectedOptions,
    });
  };

  render() {
    return (
      <div
        style={{
          overflowY: 'auto',
        }}
      >
        <Tree
          level="root"
          options={this.state.sampleData}
          onChange={(selectedOptions, name) => this.selectOptionHandler(selectedOptions, name)}
          selectedOptions={this.state.selectedOptions}
        />
      </div>
    );
  }
}

export default ContainerTypes;
