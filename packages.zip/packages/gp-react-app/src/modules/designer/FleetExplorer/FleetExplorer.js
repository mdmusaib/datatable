import React, { Component } from 'react';
import { ExplorerPanel, TreeLayout } from '@gp/components';
// import PropTypes from 'prop-types';

// import Accordion from 'react-bootstrap/Accordion'
// import Card from 'react-bootstrap/Card'
import ContainerTypes from './ContainerTypes/ContainerTypes';
import BayTypes from './BayTypes/BayTypes';
import FleetTypes from './Fleet/FleetTypes';

class FleetExplorer extends Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      containerToggle: true,
      bayTypeToggle: false,
      fleetToggle: false,
      fleetExplorerIcons: [
        {
          title: 'Filter',
          icon: 'filter',
          color: 'white',
        },
        {
          title: 'Clear Filter',
          icon: 'clearFilter',
          color: 'white',
        },
        {
          title: 'Create Loading Rule',
          icon: 'hierarchy',
          color: 'white',
        },
      ],
    };
    return initialState;
  };

  toggleClicked = (e, headerName) => {
    e.preventDefault();
    switch (headerName) {
      case 'fleetTypes':
        this.setState({
          containerToggle: false,
          bayTypeToggle: false,
          fleetToggle: true,
        });
        break;
      case 'bayTypes':
        this.setState({
          containerToggle: false,
          bayTypeToggle: true,
          fleetToggle: false,
        });
        break;
      case 'containerTypes':
        this.setState({
          containerToggle: true,
          bayTypeToggle: false,
          fleetToggle: false,
        });
        break;
      default:
        break;
    }
  };

  render() {
    return (
      <ExplorerPanel
        toggleExplorer={this.props.toggleExplorer}
        fleetExplorerIcons={this.state.fleetExplorerIcons}
        explorerHeading="Fleet Explorer"
      >
        <TreeLayout
          header="Container Types"
          addGreen
          refresh
          searchGreen
          clear
          hideSearchField
          height={this.state.containerToggle ? '88%' : '1%'}
          headerToggle={event => this.toggleClicked(event, 'containerTypes')}
          showList={this.state.containerToggle}
        >
          <ContainerTypes />
        </TreeLayout>

        <TreeLayout
          header="Bay Types"
          addGreen
          refresh
          searchGreen
          clear
          hideSearchField
          height={this.state.bayTypeToggle ? '88%' : '1%'}
          headerToggle={event => this.toggleClicked(event, 'bayTypes')}
          showList={this.state.bayTypeToggle}
        >
          <BayTypes />
        </TreeLayout>
        <TreeLayout
          header="Fleet"
          addGreen
          refresh
          searchGreen
          clear
          hideSearchField
          height={this.state.fleetToggle ? '88%' : '1%'}
          headerToggle={event => this.toggleClicked(event, 'fleetTypes')}
          showList={this.state.fleetToggle}
        >
          <FleetTypes />
        </TreeLayout>
      </ExplorerPanel>
    );
  }
}

export default FleetExplorer;
