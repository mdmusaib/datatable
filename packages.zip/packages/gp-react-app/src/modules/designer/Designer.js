import React, { Component } from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import FleetExplorer from './FleetExplorer/FleetExplorer';
import { CollapsedExplorerPanel, DrawingTool, AppModule } from '@gp/components';
class Designer extends Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      showExplorer: true,
    };
    return initialState;
  };

  toggleExplorer = event => {
    event.preventDefault();
    console.log('clideddee....');
    this.setState({
      showExplorer: !this.state.showExplorer,
    });
  };

  toggleExplorers = () => {
    console.log('clideddee....');
    // this.setState({
    //     showExplorer: !this.state.showExplorer
    // })
  };
  render() {
    return (
      <AppModule style={{ backgroundColor: '#d4d4d4' }} {...this.props}>
        <Container
          fluid={true}
          style={{
            padding: '0',
            margin: '0',
            height: '100vh',
            display: 'block',
            position: 'relative',
            overflow: 'hidden',
          }}
        >
          <Row noGutters style={{ height: '100%', width: '100%' }}>
            <div style={{ width: this.state.showExplorer ? '80%' : '97%' }}>
              <DrawingTool {...this.state}></DrawingTool>
            </div>
            {this.state.showExplorer ? (
              <div style={{ backgroundColor: '#006098', fontSize: '13px', width: '20%', zIndex: '1' }}>
                <FleetExplorer toggleExplorer={this.toggleExplorer} />
              </div>
            ) : (
              <CollapsedExplorerPanel openExplorer={this.toggleExplorer} panelName="Fleet Explorer" />
            )}
          </Row>
        </Container>
      </AppModule>
    );
  }
}

export default Designer;
