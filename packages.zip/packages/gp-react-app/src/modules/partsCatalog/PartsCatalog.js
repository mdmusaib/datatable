import React from 'react';
import { AppModule } from '@gp/components';
import { partCatalogRowData } from './PartsCatalogRowData';
import partsCatalogJsonData from '../../config/PartCatalogData.json';
import { DataGrid, Button, Icon, StyledElement, GpModal, Toast } from '@gp/components';
import PartsCreate from './PartsCreate';
import gridStyle from './PartsCatalogStyle';

const StyledButton = StyledElement(Button)({
  position: 'absolute',
  right: '10px',
  top: '7px',
});

const GridModuleNameContainer = StyledElement('div')(gridStyle.GridTitle);
const GridContainer = StyledElement('div')({
  margin: '8px',
  height: '91vh',
  position: 'relative',
});

class PartsCatalog extends React.Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      showForm: false,
      fullScreenModal: false,
      showMsg: false,
      modalWidth: '80%',
      modalHeight: '75%',
      showGrid: false,
      showToast: false,
      partData: null,
      partCatalogRowData: []
    };
    return initialState;
  };

  componentDidMount() {
    if (partCatalogRowData) {
      this.setState({
        partCatalogRowData: partCatalogRowData
      })
    }
  }

  onButtonClick = event => {
    //event.preventDefault();
    this.setState({
      showForm: true,
    });
  };

  onButtonMsgClick = event => {
    event.preventDefault();
    this.setState({
      showMsg: true,
    });
  };

  closeModal = e => {
    // e.preventDefault()
    console.log('...........')
    this.setState({
      showForm: false,
      showMsg: false,
      showGrid: false,
    });
  };

  fullScreenClicked = () => {
    this.setState({
      fullScreenModal: !this.state.fullScreenModal,
      modalWidth: '80%',
      modalHeight: '75%',
    });
  };

  onPartsUsageClick = () => {
    this.setState({
      showGrid: true,
    });
  };

  formSubmit = (data) => {
    console.log('====in catalog====', data)
    let partCatalogRowData = [...this.state.partCatalogRowData]
    partCatalogRowData.unshift(data);

    this.setState({
      showToast: true,
      partData: data,
      partCatalogRowData: partCatalogRowData
    }, () => setTimeout(() => { this.setState({ showToast: false }) }, 4000))
  }
  closeToast = () => {
    this.setState({
      showToast: false
    })
  }

  render() {
    return (
      <AppModule {...this.props} style={{ backgroundColor: '#d4d4d4' }}>
        <GpModal
          FormatModal={true}
          show={this.state.showForm}
          title="Add Part"
          closeClicked={this.closeModal}
          modalWidth="80%"
          modalHeight="11cm"
        >
          <PartsCreate formSubmit={this.formSubmit} closeClicked={this.closeModal} />
        </GpModal>
        <GpModal
          FormatModal={true}
          show={this.state.showGrid}
          //backdropClicked={this.closeModal}
          title="Smaple Modal with Grid"
          closeClicked={this.closeModal}
          fullScreen={true}
          fullScreenClicked={this.fullScreenClicked}
          fullScreenModal={this.state.fullScreenModal}
          modalWidth="80%"
          modalHeight="75%"
        >
          <DataGrid
            inModalHeight={this.state.fullScreenModal ? '82vh' : '56vh'}
            onAddClick={this.onButtonClick}
            onPartsUsageClick={this.onPartsUsageClick}
            rowData={this.state.partCatalogRowData}
            view
            enableMultiSelect
            gridData={partsCatalogJsonData}
          />
        </GpModal>
        <GridModuleNameContainer>
          <Icon type="svg" icon={partsCatalogJsonData.icon} svgIconColor="white" width="20" height="20" />
          <span>{partsCatalogJsonData.name}</span>
        </GridModuleNameContainer>

        {/* <StyledButton onButtonClick={this.onButtonClick}>Add</StyledButton> */}
        <GridContainer>
          <DataGrid
            onAddClick={this.onButtonClick}
            onPartsUsageClick={this.onPartsUsageClick}
            rowData={this.state.partCatalogRowData}
            view
            enableMultiSelect
            gridData={partsCatalogJsonData}
          />
        </GridContainer>
        <Toast
          show={this.state.showToast}
          closeToast={this.closeToast}
          showCrossIcon={true}
        >
          <p>Part has been added successfully. </p>
        </Toast>
      </AppModule>
    );
  }
}
// const PartsCatalog = props => {
//   return (
//     <AppModule {...props}>
//       <div>
//         <StyledButton>Add</StyledButton>
//         <DataGrid rowData={partCatalogRowData} enableMultiSelect gridData={partsCatalogJsonData} />
//       </div>
//     </AppModule>
//   );
// };
export default PartsCatalog;
