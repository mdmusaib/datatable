import React, { Component } from 'react';
import { Button, Inputs, Icon } from '@gp/components';
import { inputChangeHandler } from './../../assets/Form/formOnChange';

class PartsCreate extends Component {
    state = {
        partForm: {
            gpPartNo: {
                elementType: 'InputField',
                elementConfig: {
                    inputType: 'code',
                    placeholder: 'Part#',
                    type: 'text',
                },
                value: '',
                valid: false,
                touched: false,
                validation: {
                    required: true,
                    pattern: /^[a-zA-Z0-9]*$/,
                    message: 'Only numeric and alphabets Characters',
                },
            },
            gpPartName: {
                elementType: 'InputField',
                elementConfig: {
                    inputType: 'name',
                    type: 'text',
                    placeholder: 'Part Name',
                },
                value: '',
                validation: {
                    required: true,
                },
                valid: false,
                touched: false,
            },
            issueQuantity: {
                elementType: 'InputField',
                elementConfig: {
                    inputType: 'numberNoDot',
                    type: 'text',
                    placeholder: 'Part Issued',
                    isInputWithDropDown: true,
                },
                value: '1',
                validation: {
                    required: false,
                    pattern: /^[0-9]*$/,
                    message: 'Only numbers',
                },
                valid: false,
                touched: false,
            },
            issueUnit: {
                elementType: 'SingleSelectDropdown',
                elementConfig: {
                    options: [
                        { value: 'BG', displayValue: 'BG - Bag' },
                        { value: 'BO', displayValue: 'BO - Bottle' },
                        { value: 'CASE', displayValue: 'CASE - Case' },
                        { value: 'CT', displayValue: 'CT - Carton' },
                    ],

                    // isInputWithDropDown: true,
                    isSelectWithInput: true,
                },
                value: '',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            weight: {
                elementType: 'InputField',
                elementConfig: {
                    inputType: 'numberNoDot',
                    type: 'text',
                    placeholder: 'Weight',
                },
                value: '1',
                validation: {
                    required: true,
                    pattern: /^[0-9]*$/,
                    message: 'Only numbers',
                },
                valid: true,
                touched: true,
            },
            maxWeight: {
                elementType: 'InputField',
                elementConfig: {
                    inputType: 'numberNoDot',
                    type: 'text',
                    placeholder: 'Max Weight',
                },
                value: '',
                validation: {
                    required: false,
                    pattern: /^[0-9]*$/,
                    message: 'Only numbers',
                },
                valid: false,
                touched: false,
            },
            weightUnit: {
                elementType: 'SingleSelectDropdown',
                elementConfig: {
                    options: [
                        { value: 'GR', displayValue: 'GR - Gram' },
                        { value: 'KG', displayValue: 'KG - Kilogram' },
                        { value: 'LB', displayValue: 'LB - Pound' },
                    ],
                    placeholder: 'Weight Unit',
                    message: 'This field is required.',
                },
                value: '',
                validation: {
                    required: true,
                },
                valid: false,
                touched: false,
            },
            part2: {
                elementType: 'InputField',
                elementConfig: {
                    inputType: 'code',
                    type: 'text',
                    placeholder: 'Part#2',
                },
                value: '',
                validation: {
                    required: false,
                    pattern: /^[a-zA-Z0-9]*$/,
                    message: 'Only numeric and alphabets Characters',
                },
                valid: false,
                touched: false,
            },
            partName2: {
                elementType: 'InputField',
                elementConfig: {
                    inputType: 'name',
                    type: 'text',
                    placeholder: 'Part Name 2',
                },
                value: '',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            supplier: {
                elementType: 'SingleSelectDropdown',
                elementConfig: {
                    options: [
                        { value: 'AIRLINE', displayValue: 'AIRLINE - Airline' },
                        { value: 'CATERER', displayValue: 'CATERER - Caterer' },
                    ],
                    placeholder: 'Supplier',
                },
                value: '',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            catagory: {
                elementType: 'SingleSelectDropdown',
                elementConfig: {
                    options: [
                        { value: 'DIS', displayValue: 'DIS - Disposable Items' },
                        { value: 'DRY', displayValue: 'DRY - Dry Store Items' },
                        { value: 'LIQ', displayValue: 'LIQ - Liquor Items' },
                    ],
                    placeholder: 'Catagory',
                },
                value: '',
                validation: {
                    required: true,
                },
                valid: false,
                touched: false,
            },
            usageType: {
                elementType: 'SingleSelectDropdown',
                elementConfig: {
                    options: [
                        { value: 'D', displayValue: 'D - Diposable' },
                        { value: 'R', displayValue: 'R - Replenishable' },
                        { value: 'T', displayValue: 'T - Rotable' },
                    ],
                    placeholder: 'Usage Type',
                },
                value: '',
                validation: {
                    required: true,
                },
                valid: false,
                touched: false,
            },
            shapeType: {
                elementType: 'SingleSelectDropdown',
                elementConfig: {
                    options: [
                        { value: '110921', displayValue: '110921 - Pillow' },
                        { value: '100932', displayValue: '100932 - V-shape' },
                        { value: 'DNS', displayValue: 'DNS - DNS_SHAPETYPE' },
                    ],
                    placeholder: 'Shape Type',
                },
                value: '',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            height: {
                elementType: 'InputField',
                elementConfig: {
                    placeholder: 'Height',
                    inputType: 'number',
                    type: 'text',
                },
                value: '',
                validation: {
                    required: false,
                    pattern: /^[0-9]*$/,
                    message: 'Only numbers',
                },
                valid: false,
                touched: false,
            },
            width: {
                elementType: 'InputField',
                elementConfig: {
                    placeholder: 'Width',
                    inputType: 'number',
                    type: 'text',
                },
                value: '',
                validation: {
                    required: false,
                    pattern: /^[0-9]*$/,
                    message: 'Only numbers',
                },
                valid: false,
                touched: false,
            },
            depth: {
                elementType: 'InputField',
                elementConfig: {
                    placeholder: 'Depth',
                    inputType: 'number',
                    type: 'text',
                },
                value: '',
                validation: {
                    required: false,
                    pattern: /^[0-9]*$/,
                    message: 'Only numbers',
                },
                valid: false,
                touched: false,
            },
            length: {
                elementType: 'SingleSelectDropdown',
                elementConfig: {
                    options: [
                        { value: 'MTR', displayValue: 'MTR - Meter' },
                        { value: 'KMT', displayValue: 'KMT - Kilometer' },
                        { value: 'FT', displayValue: 'FT - Foot' },
                    ],
                    placeholder: 'Length Unit',
                },
                value: '',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            cost: {
                elementType: 'InputField',
                elementConfig: {
                    placeholder: 'Cost',
                    inputType: 'number',
                    type: 'text',
                    isInputWithDropDown: true,
                },
                value: null,
                validation: {
                    required: false,
                    pattern: /^\d*\.?\d*$/,
                    message: 'Only numbers',
                },
                valid: false,
                touched: false,
            },
            currencyName: {
                elementType: 'SingleSelectDropdown',
                elementConfig: {
                    options: [
                        { value: 'AUD', displayValue: 'AUD - Australian Dollar' },
                        { value: 'INR', displayValue: 'INR - Indian Rupee' },
                        { value: 'USD', displayValue: 'USD - United State Dollar' },
                    ],
                    isSelectWithInput: true,
                },
                value: '',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            externalVolume: {
                elementType: 'InputField',
                elementConfig: {
                    placeholder: 'External Volume',
                    inputType: 'number',
                    type: 'text',
                    isInputWithDropDown: true,
                },
                value: '',
                validation: {
                    required: false,
                    pattern: /^[0-9]*$/,
                    message: 'Only numbers',
                },
                valid: false,
                touched: false,
            },
            externalVolumeUnit: {
                elementType: 'SingleSelectDropdown',
                elementConfig: {
                    options: [
                        { value: 'LT', displayValue: 'LT - Liter' },
                        { value: 'GL', displayValue: 'GL - US gallon' },
                    ],
                    isSelectWithInput: true,
                },
                value: '',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            paxDependent: {
                elementType: 'Checkbox',
                elementConfig: {
                    placeholder: 'PAX Dependent',
                },
                value: false,
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            sellable: {
                elementType: 'Checkbox',
                elementConfig: {
                    placeholder: 'Is sellable',
                },
                value: false,
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            effDate: {
                elementType: 'DatePicker',
                elementConfig: {
                    placeholder: 'Eff. Date',
                    // openToDate: new Date('01/01/2000'),
                },
                value: new Date(),
                onChangeDatePicker: this.handleDatepickerChanges,
                validation: {
                    required: false,
                    pattern: /^(((((((0?[13578])|(1[02]))[\.\-/]?((0?[1-9])|([12]\d)|(3[01])))|(((0?[469])|(11))[\.\-/]?((0?[1-9])|([12]\d)|(30)))|((0?2)[\.\-/]?((0?[1-9])|(1\d)|(2[0-8]))))[\.\-/]?((\d{2})?([\d][\d]))))|((0?2)[\.\-/]?(29)[\.\-/]?(((19)|(20))?(([02468][048])|([13579][26])))))$/,
                },
                disabled: false,
                minDate: null,
                valid: false,
                touched: false,
            },
            endDate: {
                elementType: 'DatePicker',
                elementConfig: {
                    placeholder: 'End Date',
                    openToDate: new Date('01/01/2000'),
                },
                value: '',
                disabled: false,
                minDate: null,
                onChangeDatePicker: this.handleDatepickerChanges,
                validation: {
                    required: false,
                    pattern: /^(((((0[1-9])|(1\d)|(2[0-8]))\/((0[1-9])|(1[0-2])))|((31\/((0[13578])|(1[02])))|((29|30)\/((0[1,3-9])|(1[0-2])))))\/((20[0-9][0-9])|(19[0-9][0-9])))|((29\/02\/(19|20)(([02468][048])|([13579][26]))))$/,
                },
                valid: false,
                touched: false,
            },

            sectorLife: {
                elementType: 'InputField',
                elementConfig: {
                    placeholder: 'Sector Life',
                    inputType: 'number',
                    type: 'text',
                    width: '10%',
                },
                value: '',
                validation: {
                    required: false,
                    pattern: /^[0-9]*$/,
                    message: 'Only numbers',
                },
                valid: false,
                touched: false,
            },
            usage: {
                elementType: 'InputField',
                elementConfig: {
                    placeholder: 'Usage',
                    inputType: 'string',
                    type: 'text',
                    readOnly: true,
                    width: '10%',
                },
                value: '0%',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            isDummy: {
                elementType: 'Checkbox',
                elementConfig: {
                    placeholder: 'Is Dummy',
                },
                value: false,
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            includeInBom: {
                elementType: 'Checkbox',
                elementConfig: {
                    placeholder: 'Include In BOM',
                },
                value: false,
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            partDesc: {
                elementType: 'Textarea',
                elementConfig: {
                    placeholder: 'Description',
                    type: 'text',
                },
                value: '',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            partDesc2: {
                elementType: 'Textarea',
                elementConfig: {
                    placeholder: 'Description 2',
                    type: 'text',
                },
                value: '',
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
            passengerClass: {
                elementType: 'LookupList',
                elementConfig: {
                    options: [
                        { value: 'C-Business' },
                        { value: 'F-First' },
                        { value: 'I-Common' },
                        { value: 'PL-Pilot' },
                        { value: 'Y-Coach' },
                    ],
                    placeholder: 'Passenger Class',
                },
                value: [],
                validation: {
                    required: false,
                },
                valid: false,
                touched: false,
            },
        },
        formIsValid: false,
    };

    handleDatepickerChanges = (event, userInputIdentifier, state = 'partForm') => {
        if (event === null) {
            let currentState = this.state;

            let userInputIdentifier = 'endDate';

            const updatedUserForm = {
                ...this.state[state],
            };
            const updatedUserFormElement = {
                ...updatedUserForm[userInputIdentifier],
            };
            // console.log(updatedUserFormElement)
            updatedUserFormElement.disabled = true;
            updatedUserForm[userInputIdentifier] = updatedUserFormElement;
            currentState[state] = updatedUserForm;
            // console.log(updatedUserFormElement)
            this.setState({
                updatedUserFormElement,
            });
            // console.log(updatedUserFormElement)
        } else {
            let currentState = this.state;
            let userInputIdentifier = 'endDate';

            const updatedUserForm = {
                ...this.state[state],
            };
            const updatedUserFormElement = {
                ...updatedUserForm[userInputIdentifier],
            };
            console.log(updatedUserForm);
            updatedUserFormElement.disabled = false;
            updatedUserForm[userInputIdentifier] = updatedUserFormElement;
            currentState[state] = updatedUserForm;
            // console.log(updatedUserFormElement)
            this.setState({
                updatedUserFormElement,
            });
        }
        let currentState = this.state;
        const updatedForm = {
            ...this.state[state],
        };

        const updatedFormElement = {
            ...updatedForm[userInputIdentifier],
        };
        console.log(userInputIdentifier);
        if (userInputIdentifier.elementType === 'effectiveDate') {
            console.log(event);
            updatedFormElement.value = event;

            let userInputIdentifier1 = 'endDate';
            const updatedForm1 = {
                ...this.state[state],
            };
            const updatedFormElement1 = {
                ...updatedForm1[userInputIdentifier1],
            };
            console.log(typeof event);
            updatedFormElement1.minDate = event;
            updatedForm[userInputIdentifier.elementType] = updatedFormElement;
            currentState[state] = updatedForm;
            this.setState(
                {
                    updatedFormElement,
                    updatedFormElement1,
                },
                () => {
                    console.log(this.state);
                },
            );
        }
        updatedFormElement.value = event;
        updatedFormElement.valid = this.checkValidity(updatedFormElement.value, updatedFormElement.validation);
        updatedFormElement.touched = true;
        updatedForm[userInputIdentifier] = updatedFormElement;

        let formIsValid = true;
        let formElements = updatedForm;
        for (let userInputIdentifier in formElements) {
            if (
                formElements[userInputIdentifier].value !== undefined &&
                formElements[userInputIdentifier].validation.required
            ) {
                formIsValid = formElements[userInputIdentifier].valid && formIsValid;
            }
        }
        currentState[state] = updatedForm;
        currentState.formIsValid = formIsValid;

        console.log('------', currentState);
        this.setState(currentState);
    };

    convertDate = date => {
        var months = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
        var day = date.getDate();
        var year = date.getFullYear();
        var month = months[date.getMonth()];
        console.log(day + '/' + month + '/' + year);
        return day + '/' + month + '/' + year;
    };

    inputChangeHandler = (event, userInputIdentifier, formState) => {
        let currentState = inputChangeHandler(this.state, event, userInputIdentifier, formState);
        this.setState(currentState);
    };

    checkValidity(value, rules, elementConfig) {
        let isValid = false;
        if (value === '') {
            isValid = false;
        } else if (rules.required === true && elementConfig.type === 'text') {
            // console.log('inside if');

            if (typeof value === 'string') {
                // console.log('inside if 1');

                isValid = rules.pattern.test(value);
            } else {
                // console.log('inside if 2');

                isValid = value.trim() !== '';
            }
        } else {
            // console.log('inside else');

            isValid = true;
        }
        return isValid;
    }

    formSubmit = () => {
        const formData = {};
        for (let fromElementIdentifier in this.state.partForm) {
            // console.log(this.state.partForm[fromElementIdentifier].elementType === 'DatePicker');
            if (this.state.partForm[fromElementIdentifier].elementType === 'DatePicker') {
                formData[fromElementIdentifier] = this.state.partForm[fromElementIdentifier].value && this.convertDate(this.state.partForm[fromElementIdentifier].value);
            } else {
                formData[fromElementIdentifier] = this.state.partForm[fromElementIdentifier].value;
            }
        }
        console.log('----', formData);
        this.props.formSubmit(formData);
    };

    render() {
        let inputs = [];
        const keys = Object.keys(this.state.partForm);
        for (const key of keys) {
            const formElement = this.state.partForm[key];
            //console.log(formElement);
            inputs.push(
                <div
                    key={key}
                    style={{
                        height:
                            formElement.elementType === 'Textarea' || formElement.elementType === 'LookupList' ? '100px' : '50px',
                        width: formElement.elementConfig.isInputWithDropDown
                            ? '12%'
                            : formElement.elementConfig.isSelectWithInput
                                ? '8%'
                                : formElement.elementConfig.width
                                    ? formElement.elementConfig.width
                                    : formElement.elementType === 'Textarea'
                                        ? '40%'
                                        : '20%',
                        display: 'flex',
                    }}
                >
                    <Inputs

                        name={key}
                        elementType={formElement.elementType}
                        elementConfig={formElement.elementConfig}
                        value={formElement.value}
                        valid={formElement.valid}
                        touched={formElement.touched}
                        changed={event => {
                            formElement.elementType === 'DatePicker'
                                ? this.handleDatepickerChanges(event, key)
                                : this.inputChangeHandler(event, key, 'partForm');
                        }}
                        validation={formElement.validation}
                    />
                </div>,
            );
        }

        return (
            <>
                <form style={{ height: '92%', display: 'flex', flexFlow: 'wrap', justifyContent: 'center' }} autoComplete="off">
                    {inputs}
                </form>
                <div style={{ width: '100%', textAlign: 'right', paddingRight: '10px' }}>
                    <span style={{ color: 'black', fontSize: '11px', fontFamily: 'Work Sans', float: 'left', marginLeft: '16px' }}>
                        <mark style={{ color: 'red', padding: '0', backgroundColor: 'transparent' }}>*</mark>
                        Mandatory fields
                    </span>
                    <Button style={{ marginRight: '8px' }} onButtonClick={this.formSubmit} disabled={!this.state.formIsValid}>
                        Add
                    </Button>
                    <Button variant="secondary" onButtonClick={this.props.closeClicked}>
                        Close
                    </Button>
                </div>
            </>
        );
    }
}

export default PartsCreate;
