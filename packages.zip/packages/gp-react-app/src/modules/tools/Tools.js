import React, { Component, Fragment } from 'react';
import { Toolbar, Icon, AppModule, DataGrid, StyledElement } from '@gp/components';
import toolsjson from '../../config/ToolsData.json';
import toolsMenuList from './ToolsMenuList';
import SchedulerConfigurationJsonData from '../../config/tools/schedulerConfiguration/SchedulerConfiguration.json';
import ProductionReleaseScheduleJsonData from '../../config/tools/productionReleaseSchedule/ProductReleaseSchedule.json';
import SSIMFilesJsonFile from '../../config/tools/ssimFiles/SSIMFiles.json';
import DataExportJsonFile from '../../config/tools/dataExport/DataExport.json';
import ManageMenuCodeJsonFile from '../../config/tools/manageMenuCode/ManageMenuCode.json';
import toolsStyle from './ToolsStyle';

import { toolsRowData } from './ToolsRowData';
import { SchedulerConfigurationRowData } from './schedulerConfiguration/SchedulerConfigurationRowData';
import { ProductionReleaseRowData } from './productionRelease/ProductionReleaseRowData';
import { SSIMFilesRowData } from './ssimFiles/SSIMFilesRowData';
import { DataExportRowData } from './dataExport/DataExportRowData';
import { ManageMenuCodeRowData } from './manageMenuCode/ManageMenuCodeRowData';

let Seperator = StyledElement('div')(toolsStyle.seperator);

class Tools extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      showSchedulerConfiguration: false,
      showProductionReleaseSchedule: false,
      showSSIMFiles: false,
      gridReRenderToogle: true,
      gridJsonData: toolsjson.GridConfig,
      gridRowData: toolsRowData,
    };
  }

  onMenuCLick = list => {
    switch (list) {
      case 'Schedule Product Assignment/Exchange Rule(s)':
        this.setState({
          gridJsonData: toolsjson.GridConfig,
          gridRowData: toolsRowData,
          gridReRenderToogle: !this.state.gridReRenderToogle,
        });
        break;
      case 'Scheduler Configuration':
        this.setState({
          gridJsonData: SchedulerConfigurationJsonData,
          gridRowData: SchedulerConfigurationRowData,
          gridReRenderToogle: !this.state.gridReRenderToogle,
        });
        break;
      case 'Production Release Schedule':
        this.setState({
          gridJsonData: ProductionReleaseScheduleJsonData,
          gridRowData: ProductionReleaseRowData,
          gridReRenderToogle: !this.state.gridReRenderToogle,
        });
        break;
      case 'SSIM Files':
        this.setState({
          gridJsonData: SSIMFilesJsonFile,
          gridRowData: SSIMFilesRowData,
          gridReRenderToogle: !this.state.gridReRenderToogle,
        });
        break;
      case 'Data Export':
        this.setState({
          gridJsonData: DataExportJsonFile,
          gridRowData: DataExportRowData,
          gridReRenderToogle: !this.state.gridReRenderToogle,
        });
        break;
      case 'Manage Menu Code':
        this.setState({
          gridJsonData: ManageMenuCodeJsonFile,
          gridRowData: ManageMenuCodeRowData,
          gridReRenderToogle: !this.state.gridReRenderToogle,
        });
        break;
      default:
    }
  };

  render() {
    return (
      <AppModule {...this.props} style={{ backgroundColor: '#d4d4d4' }}>
        <Toolbar>
          {toolsMenuList.map((list, index) => (
            <Fragment>
              <div title={list.title} style={{ padding: '6px' }} onClick={() => this.onMenuCLick(list.title)}>
                <Icon type="svg" icon={list.icon} svgIconColor="white" width="24" height="24" />
              </div>
              {list.seperator ? <Seperator /> : <Fragment />}
            </Fragment>
          ))}
        </Toolbar>
        <div
          style={{
            padding: '0',
            height: '91.8vh',
            display: 'block',
            position: 'relative',
            overflow: 'hidden',
            margin: '5px',
          }}
        >
          <DataGrid
            gridData={this.state.gridJsonData}
            rowData={this.state.gridRowData}
            gridReRenderToogle={this.state.gridReRenderToogle}
            view
            enableMultiSelect
            inModalHeight="79vh"
          />
        </div>
      </AppModule>
    );
  }
}

export default Tools;
