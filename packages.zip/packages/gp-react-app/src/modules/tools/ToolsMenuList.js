export default [
  {
    title: 'Schedule Product Assignment/Exchange Rule(s)',
    icon: 'document',
    width: '24',
    seperator: true,
  },
  {
    title: 'Scheduler Configuration',
    icon: 'imageLibrary',
    width: '24',
    seperator: true,
  },
  {
    title: 'Production Release Schedule',
    icon: 'partsCatalog',
    width: '24',
    seperator: true,
  },
  {
    title: 'Data Export',
    icon: 'excel',
    width: '24',
    seperator: true,
  },
  {
    title: 'SSIM Files',
    icon: 'partsUsage',
    width: '24',
    seperator: true,
  },
  {
    title: 'Manage Menu Code',
    icon: 'word',
    width: '24',
    seperator: true,
  },
  {
    title: 'Generate Interfaces',
    icon: 'gear',
    width: '24',
  },
];
