export default {
  GridTitle: props => {
    return {
      //width: '100%',
      bg: props.theme.colors.paxia.brand_light_blue,
      display: 'flex',
      alignItems: 'center',
      padding: 1,
      color: props.theme.colors.paxia_grid.white,
      pl: 2,
      ml: '5px',
      mr: '5px',
      borderBottomLeftRadius: '10px',
      borderBottomRightRadius: '10px',
      '&>span': {
        pl: 1,
      },
    };
  },
};
