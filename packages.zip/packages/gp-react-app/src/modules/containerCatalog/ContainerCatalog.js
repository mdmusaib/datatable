import React, { Fragment } from 'react';
import { AppModule } from '@gp/components';
import { ContainerCatalogRowData } from '../../config/containerCatalog/ContainerCatalogRowData';
import ContainerCatalogJsonData from '../../config/containerCatalog/ContainerCatalogData.json';
import { DataGrid, Button, Icon, StyledElement, GpModal } from '@gp/components';
import AddContainerForm from '../../SampleFormTest/AddContainerForm';
import gridStyle from './ContainerCatalogStyle';

const StyledButton = StyledElement(Button)({
  position: 'absolute',
  right: '10px',
  top: '7px',
});

const GridModuleNameContainer = StyledElement('div')(gridStyle.GridTitle);
const GridContainer = StyledElement('div')({
  margin: '8px',
  height: '91vh',
  position: 'relative',
});

class ContainerCatalog extends React.Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      show: false,
      fullScreenModal: false,
      showMsg: false,
      modalWidth: '80%',
      modalHeight: '75%',
    };
    return initialState;
  };

  onButtonClick = event => {
    //event.preventDefault();
    this.setState({
      show: true,
    });
  };

  onButtonMsgClick = event => {
    event.preventDefault();
    this.setState({
      showMsg: true,
    });
  };

  closeModal = e => {
    this.setState({
      show: false,
      showMsg: false,
    });
  };

  fullScreenClicked = () => {
    this.setState({
      fullScreenModal: !this.state.fullScreenModal,
      modalWidth: '80%',
      modalHeight: '75%',
    });
  };
  render() {
    return (
      <AppModule {...this.props} style={{ backgroundColor: '#d4d4d4' }}>
        {/* <GpModal
          FormatModal={true}
          show={this.state.show}
          //backdropClicked={this.closeModal}
          title="Add Container"
          closeClicked={this.closeModal}
          fullScreen={true}
          fullScreenClicked={this.fullScreenClicked}
          fullScreenModal={this.state.fullScreenModal}
          modalWidth="80%"
          modalHeight="75%"
        >
          <AddContainerForm closeClicked={this.closeModal} />
        </GpModal> */}
        <GridModuleNameContainer>
          <Icon type="svg" icon={ContainerCatalogJsonData.icon} svgIconColor="white" width="20" height="20" />
          <span>{ContainerCatalogJsonData.name}</span>
        </GridModuleNameContainer>
        {/* <StyledButton onButtonClick={this.onButtonClick}>Add</StyledButton> */}
        <GridContainer>
          <DataGrid
            onAddClick={this.onButtonClick}
            rowData={ContainerCatalogRowData}
            view
            enableMultiSelect
            gridData={ContainerCatalogJsonData}
          />
        </GridContainer>
      </AppModule>
    );
  }
}
// const ContainerCatalog = props => {
//   return (
//     <AppModule {...props}>
//       <div>
//         <StyledButton>Add</StyledButton>
//         <DataGrid rowData={ContainerCatalogRowData} enableMultiSelect gridData={ContainerCatalogJsonData} />
//       </div>
//     </AppModule>
//   );
// };
export default ContainerCatalog;
