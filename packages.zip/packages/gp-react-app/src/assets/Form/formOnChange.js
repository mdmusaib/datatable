import { checkValidity } from './validation';

export function inputChangeHandler(state, event, userInputIdentifier, formState) {
    let currentState = state;
    const updatedForm = {
        ...state[formState],
    };

    const updatedFormElement = {
        ...updatedForm[userInputIdentifier],
    };

    let rules = updatedFormElement.validation
    // console.log(updatedFormElement, 'updatedFormElement');
    if (updatedFormElement.elementType === 'MultiSelectDropdown') {
        let index = '';
        if ((index = updatedFormElement.value.indexOf(event.target.value)) === -1) {
            updatedFormElement.value.push(event.target.value);
        } else {
            updatedFormElement.value.splice(index, 1);
        }
    } else if (updatedFormElement.elementType === 'Checkbox') {
        updatedFormElement.value = !updatedFormElement.value;
    } else if (updatedFormElement.elementType === 'InputField') {

        if (rules.required && rules.pattern) {
            if (rules.pattern.test(event.target.value)) {
                updatedFormElement.value = event.target.value;
                updatedFormElement.valid = true
            }
        } else if (!rules.required && rules.pattern) {
            if (rules.pattern.test(event.target.value)) {
                updatedFormElement.value = event.target.value;
                updatedFormElement.valid = true
            }
        } else if (rules.required && !rules.pattern) {
            updatedFormElement.value = event.target.value;
            updatedFormElement.valid = true
        } else if (!rules.required && !rules.pattern) {
            updatedFormElement.value = event.target.value;
            updatedFormElement.valid = true
        } else {
            updatedFormElement.valid = false
        }
    } else {
        updatedFormElement.value = event.target.value;
    }
    console.log(updatedFormElement.touched)
    updatedFormElement.valid = checkValidity(
        updatedFormElement.value,
        updatedFormElement.validation,
        updatedFormElement.elementConfig,
    );
    updatedFormElement.touched = true;
    updatedForm[userInputIdentifier] = updatedFormElement;

    let formIsValid = true;
    let formElements = updatedForm;
    for (let userInputIdentifier in formElements) {
        if (
            formElements[userInputIdentifier].value !== undefined &&
            formElements[userInputIdentifier].validation.required
        ) {
            formIsValid = formElements[userInputIdentifier].valid && formIsValid;
        }
    }
    currentState[formState] = updatedForm;
    currentState.formIsValid = formIsValid;

    return currentState;
}
