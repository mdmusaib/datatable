export function checkValidity(value, rules, elementConfig) {
  let isValid = false;
  if (value === '' && rules.required === true) {
    isValid = false;
  } else if (elementConfig.type === 'text' && rules.pattern != undefined) {
    // console.log('inside if');

    if (typeof value === 'string') {
      // console.log('inside if 1');

      isValid = rules.pattern.test(value);
    } else {
      // console.log('inside if 2');

      isValid = value.trim() !== '';
    }
  } else {
    // console.log('inside else');

    isValid = true;
  }
  return isValid;
}
