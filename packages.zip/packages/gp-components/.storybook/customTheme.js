import { create } from '@storybook/theming/create';
import brandLogo from './logo/paxia.png';

export default create({
  base: 'light',


  brandTitle: 'Paxia GP  Custom Component Story',
  brandUrl: 'https://paxiasolutions.com/',
  brandImage: brandLogo,
});