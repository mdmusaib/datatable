import React from 'react';
import { ThemeProvider } from 'emotion-theming';
import theme from '@project/components/src/tokens';

const ThemeDecorator = storyFn => <ThemeProvider theme={theme}>{storyFn()}</ThemeProvider>;

export default ThemeDecorator;
