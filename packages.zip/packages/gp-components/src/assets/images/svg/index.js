import { ReactComponent as PrinterSVG } from './001-printer.svg';
import { ReactComponent as CsvSVG } from './002-csv.svg';
import { ReactComponent as ExcelSVG } from './003-excel.svg';
import { ReactComponent as DownloadSVG } from './004-download.svg';
import { ReactComponent as UploadSVG } from './005-upload.svg';
import { ReactComponent as FilterSVG } from './006-filter.svg';
import { ReactComponent as PdfSVG } from './007-pdf.svg';
import { ReactComponent as UiSVG } from './008-ui.svg';
import { ReactComponent as RefreshSVG } from './009-refresh.svg';
import { ReactComponent as WordSVG } from './010-word.svg';
import { ReactComponent as ForWardSVG } from './011-forward.svg';
import { ReactComponent as MultiMediaSVG } from './012-multimedia-option.svg';
import { ReactComponent as ShareSVG } from './013-share.svg';
import { ReactComponent as BackSVG } from './014-back.svg';
import { ReactComponent as SearchSVG } from './015-search.svg';
import { ReactComponent as GearSVG } from './016-gear.svg';
import { ReactComponent as OrderSVG } from './017-order.svg';
import { ReactComponent as HouseSVG } from './018-house.svg';
import { ReactComponent as MoreSVG } from './019-more.svg';
import { ReactComponent as NewDocumentSVG } from './020-new-document.svg';
import { ReactComponent as FloppyDiskSVG } from './021-floppy-disk.svg';
import { ReactComponent as VisibilitySVG } from './022-visibility.svg';
import { ReactComponent as AddSVG } from './023-add.svg';
import { ReactComponent as DeleteSVG } from './024-delete.svg';
import { ReactComponent as FileSVG } from './025-file.svg';
import { ReactComponent as File1SVG } from './026-file-1.svg';
import { ReactComponent as File2SVG } from './027-file-2.svg';
import { ReactComponent as DocumentSVG } from './028-document.svg';
import { ReactComponent as TermsOfUseSVG } from './029-terms-of-use.svg';
import { ReactComponent as CalendarSVG } from './030-calendar.svg';
import { ReactComponent as MemoriesSVG } from './031-memories.svg';
import { ReactComponent as AnalysisSVG } from './032-analysis.svg';
import { ReactComponent as DesignerSVG } from './moduleIcons/designer.svg';
import { ReactComponent as LoaderSVG } from './moduleIcons/loader.svg';
import { ReactComponent as FuelBurnSVG } from './moduleIcons/fuelBurn.svg';
import { ReactComponent as TaskManagerSVG } from './moduleIcons/taskManager.svg';
import { ReactComponent as PublisherSVG } from './moduleIcons/publisher.svg';
import { ReactComponent as CatererPortalSVG } from './moduleIcons/catererPortal.svg';
import { ReactComponent as ReferenceDataSVG } from './moduleIcons/referenceData.svg';
import { ReactComponent as ImageLibrarySVG } from './moduleIcons/imageLibrary.svg';
import { ReactComponent as PartsCatalogSVG } from './moduleIcons/partsCatalog.svg';
import { ReactComponent as ContainerCatalogSVG } from './moduleIcons/containerCatalog.svg';
import { ReactComponent as PreferencesSVG } from './moduleIcons/preferences.svg';
import { ReactComponent as ToolsSVG } from './moduleIcons/tools.svg';
import { ReactComponent as HomeSVG } from './moduleIcons/home.svg';
import { ReactComponent as PinSVG } from './pin.svg';
import { ReactComponent as EraserSVG } from './clear.svg';
import { ReactComponent as ReportSVG } from './report.svg';
import { ReactComponent as ResetToDefaultSVG } from './reset-default.svg';
import { ReactComponent as EditSVG } from './edit.svg';
import { ReactComponent as HierarchySVG } from './hierarchy.svg';
import { ReactComponent as DownArrowSVG } from './downArrow.svg';
import { ReactComponent as ClearFilterSVG } from './clearFilter.svg';
import { ReactComponent as ShapeSelectSVG } from './drawingTool/shapeSelect.svg';
import { ReactComponent as ShapeTransformSVG } from './drawingTool/shapeTransform.svg';
import { ReactComponent as ShapeLineSVG } from './drawingTool/shapeLine.svg';
import { ReactComponent as ShapeCurveSVG } from './drawingTool/shapeCurve.svg';
import { ReactComponent as ShapeFreeHandSVG } from './drawingTool/shapeFreehand.svg';
import { ReactComponent as ShapeTextSVG } from './drawingTool/shapeText.svg';
import { ReactComponent as ShapeReactSVG } from './drawingTool/shapeRectangle.svg';
import { ReactComponent as ShapeEllipseSVG } from './drawingTool/shapeEllipse.svg';
import { ReactComponent as ShapeSectorSVG } from './drawingTool/shapeSector.svg';
import { ReactComponent as ShapePlygonSVG } from './drawingTool/shapePolygon.svg';
import { ReactComponent as ShapeMagnetSVG } from './drawingTool/shapeMagnet.svg';
import { ReactComponent as DiagramSaveSVG } from './drawingTool/standardToolbar/save.svg';
import { ReactComponent as SaveImageSVG } from './drawingTool/standardToolbar/addImage.svg';
import { ReactComponent as InsertImageSVG } from './drawingTool/standardToolbar/insert-image.svg';
import { ReactComponent as PrintSVG } from './drawingTool/standardToolbar/print.svg';
import { ReactComponent as UndoSVG } from './drawingTool/standardToolbar/undo.svg';
import { ReactComponent as RedoSVG } from './drawingTool/standardToolbar/redo.svg';
import { ReactComponent as DrawingRefreshSVG } from './drawingTool/standardToolbar/refresh.svg';
import { ReactComponent as CutSVG } from './drawingTool/standardToolbar/cut.svg';
import { ReactComponent as CopySVG } from './drawingTool/standardToolbar/copy.svg';
import { ReactComponent as PasteSVG } from './drawingTool/standardToolbar/paste.svg';
import { ReactComponent as DuplicateSVG } from './drawingTool/standardToolbar/duplicate.svg';
import { ReactComponent as ClearSVG } from './drawingTool/standardToolbar/clear.svg';
import { ReactComponent as ClearAllSVG } from './drawingTool/standardToolbar/clearAll.svg';
import { ReactComponent as GroupSVG } from './drawingTool/standardToolbar/group.svg';
import { ReactComponent as UnGroupSVG } from './drawingTool/standardToolbar/unGroup.svg';
import { ReactComponent as BringToFrontSVG } from './drawingTool/standardToolbar/bringToFront.svg';
import { ReactComponent as SendToBackSVG } from './drawingTool/standardToolbar/sendToBack.svg';
import { ReactComponent as ZoomInSVG } from './drawingTool/standardToolbar/zoomIn.svg';
import { ReactComponent as ZoomOutSVG } from './drawingTool/standardToolbar/zoomOut.svg';
import { ReactComponent as ZoomResetSVG } from './drawingTool/standardToolbar/reset.svg';

import { ReactComponent as PartsUsageSVG } from './partsCatalog/parts-usage.svg';
import { ReactComponent as SetEndDateSVG } from './partsCatalog/set-end-date.svg';
import { ReactComponent as ReplacementHistorySVG } from './partsCatalog/replacement-hsitory.svg';

import { ReactComponent as PopUpMaximizeSVG } from './popupIcons/maximize.svg';
import { ReactComponent as PopUpMinimizeSVG } from './popupIcons/minimize.svg';
import { ReactComponent as PopUpCloseSVG } from './popupIcons/close.svg';
/*
  shapeFreehand: ShapeFreeHandSVG,
  shapeMagnet: ShapeMagnetSVG,
*/
export default {
  printer: PrinterSVG,
  csv: CsvSVG,
  excel: ExcelSVG,
  download: DownloadSVG,
  upload: UploadSVG,
  filter: FilterSVG,
  pdf: PdfSVG,
  ui: UiSVG,
  refresh: RefreshSVG,
  word: WordSVG,
  forward: ForWardSVG,
  multimedia: MultiMediaSVG,
  share: ShareSVG,
  back: BackSVG,
  search: SearchSVG,
  gear: GearSVG,
  order: OrderSVG,
  house: HouseSVG,
  more: MoreSVG,
  newDocument: NewDocumentSVG,
  floppyDisk: FloppyDiskSVG,
  visibility: VisibilitySVG,
  add: AddSVG,
  delete: DeleteSVG,
  file: FileSVG,
  file1: File1SVG,
  file2: File2SVG,
  document: DocumentSVG,
  terms: TermsOfUseSVG,
  calendar: CalendarSVG,
  memories: MemoriesSVG,
  analysis: AnalysisSVG,
  designer: DesignerSVG,
  loader: LoaderSVG,
  fuelBurn: FuelBurnSVG,
  taskManager: TaskManagerSVG,
  publisher: PublisherSVG,
  catererPortal: CatererPortalSVG,
  referenceData: ReferenceDataSVG,
  imageLibrary: ImageLibrarySVG,
  partsCatalog: PartsCatalogSVG,
  containerCatalog: ContainerCatalogSVG,
  preferences: PreferencesSVG,
  tools: ToolsSVG,
  home: HomeSVG,
  pin: PinSVG,
  eraser: EraserSVG,
  diagramSave: DiagramSaveSVG,
  saveImageAS: SaveImageSVG,
  insertImage: InsertImageSVG,
  print: PrintSVG,
  undo: UndoSVG,
  redo: RedoSVG,
  drawingRefresh: DrawingRefreshSVG,
  cut: CutSVG,
  copy: CopySVG,
  paste: PasteSVG,
  duplicate: DuplicateSVG,
  clear: ClearSVG,
  clearAll: ClearAllSVG,
  group: GroupSVG,
  unGroup: UnGroupSVG,
  bringToFront: BringToFrontSVG,
  sendToBack: SendToBackSVG,
  zoomIn: ZoomInSVG,
  zoomOut: ZoomOutSVG,
  zoomReset: ZoomResetSVG,
  partsUsage: PartsUsageSVG,
  setEndDateSVG: SetEndDateSVG,
  replacementHistory: ReplacementHistorySVG,
  shapeSelect: ShapeSelectSVG,
  shapeTransform: ShapeTransformSVG,
  shapeLine: ShapeLineSVG,
  shapeCurve: ShapeCurveSVG,
  shapeFreehand: ShapeFreeHandSVG,
  shapeText: ShapeTextSVG,
  shapeRectangle: ShapeReactSVG,
  shapeEllipse: ShapeEllipseSVG,
  shapeSector: ShapeSectorSVG,
  shapePolygon: ShapePlygonSVG,
  shapeMagnet: ShapeMagnetSVG,
  report: ReportSVG,
  edit: EditSVG,
  resetDefault: ResetToDefaultSVG,
  hierarchy: HierarchySVG,
  downArrow: DownArrowSVG,
  clearFilter: ClearFilterSVG,
  popUpMaximize: PopUpMaximizeSVG,
  popUpMinimize: PopUpMinimizeSVG,
  popUpClose: PopUpCloseSVG,
};
