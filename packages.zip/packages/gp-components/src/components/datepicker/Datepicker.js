import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
// import moment from 'moment';
import { InputGroup } from 'react-bootstrap';
import 'react-datepicker/dist/react-datepicker.css';

import Icon from '../icons/Icon';
import { datepickerField } from '../../tokens/components';
import { StyledElement } from '../utils/element';
import ValidationClass from '../Inputs/InputValidations';

const StyledDatepickerField = StyledElement('div')(datepickerField);

class DatepickerInput extends ValidationClass {
  // console.log(props, 'pope');

  state = {
    value: null,
    errorMessage: '',
    focusIn: false,
  };

  componentDidMount() {
    if (this.props.value) {
      this.setState({
        focusIn: true,
        focusOut: false
      })
    }
  }

  onFocusIn = () => {
    this.setState(
      {
        focusIn: true,
      },
      () => this.validation,
    );
  };

  onBlur = () => {
    if (!this.props.value) {
      this.setState(
        {
          focusIn: false,
        },
        () => this.validation,
      );
    }
  };
  render() {
    const LabelName = [this.props.elementConfig.placeholder];
    if (this.props.validation) {
      if (this.props.validation.required) {
        LabelName.push(<span style={{ color: 'red' }}> *</span>);
      }
    }
    return (
      <StyledDatepickerField
        containerWidth={this.props.elementConfig.containerWidth}
        className="datepickerField"
        {...this.props}
        inFocus={this.state.focusIn}
      >
        <InputGroup className="DatepickerGroup" disabled={true}>
          <InputGroup.Text
            className="DatepickerIconGroup"
            //   onClick={this.props.disabled === true ? null : this.togglePicker}
            id="basic-addon1"
          >
            <Icon icon="drawingToolIcons.calendar_icon" width="15" height="15" />
          </InputGroup.Text>
          <DatePicker
            popperModifiers={{
              preventOverflow: {
                enabled: true,
                escapeWithReference: false,
                boundariesElement: 'viewport',
              },
              // offset: {
              //     enabled: true,
              //     offset: "5px, 10px"
              // },
            }}
            className={this.props.elementConfig.className ? this.props.elementConfig.className : 'datepickerField'}
            isClearable={
              this.props.value === undefined || this.props.value === ''
                ? this.props.disabled === undefined || this.props.disabled === false
                  ? false
                  : true
                : true
            }
            disabled={this.props.disabled}
            name={this.props.name}
            autoComplete="off"
            showPopperArrow={true}
            showMonthDropdown
            showYearDropdown
            onKeyDown={this.props.onKeyDown}
            dropdownMode="select"
            openToDate={this.props.elementConfig.openToDate}
            dateFormat="dd/MM/yyyy"
            minDate={this.props.elementConfig.openToDate}
            //   maxDate={this.props.maxDate}
            selected={this.props.value}
            onChange={this.props.changed}
            onFocus={this.onFocusIn}
            onBlur={this.onBlur}
          // popperPlacement="top"
          // popperClassName="some-custom-class"
          // onChange={date => setStartDate(date)}
          />
          {/* <Icon icon=""></Icon> */}
        </InputGroup>
        <span className="LabelName">{LabelName}</span>
      </StyledDatepickerField>
    );
  }
}
export default DatepickerInput;
