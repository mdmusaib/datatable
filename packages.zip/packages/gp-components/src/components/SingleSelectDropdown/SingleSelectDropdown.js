import React, { useState } from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { Col, Container, Row } from 'react-bootstrap';
import { singleSelectDropdown as singleSelectDropdownStyle, inputTooltip as inputTooltipStyle } from '../../tokens/components';
import ValidationClass from '../Inputs/InputValidations';
import ReactTooltip from 'react-tooltip';

const StyledSingleSelect = styled('div')(singleSelectDropdownStyle);
const StyledTooltip = styled(ReactTooltip)(inputTooltipStyle);


class SingleSelectDropdown extends ValidationClass {
  state = {
    value: null,
    errorMessage: '',
    focusIn: false,
    focusOut: false
  };

  componentDidMount() {
    if (this.props.value) {
      this.setState({
        focusIn: true,
        focusOut: false
      })
    }
  }

  onFocusIn = () => {
    this.setState({
      focusIn: true,
    }, () => this.validation)
  }

  onBlur = () => {
    if (!this.props.value) {
      this.setState({
        focusIn: false,
        focusOut: true
      }, () => this.validation)
    }

  }

  render() {
    const LabelName = [this.props.elementConfig.placeholder];
    if (this.props.validation) {
      if (this.props.validation.required) {
        LabelName.push(<mark> *</mark>);
      }
    }

    // const [value, setValue] = useState(this.props.value)
    // console.log(this.props.valid, '-=---', this.props.touched)

    return (
      <>
        <StyledSingleSelect
          inFocus={this.state.focusIn}
          inValid={(this.state.focusOut && !this.props.value && this.props.validation.required) || (this.props.valid === false && this.props.touched === true)}
          isSelectWithInput={this.props.elementConfig.isSelectWithInput}
          value={this.props.value}
        >
          <select
            // className={classes.select}
            value={this.props.value}
            onChange={this.props.changed}
            name={this.props.name}
            onBlur={this.onBlur}
            onFocus={this.onFocusIn}
            onKeyDown={this.validation}
            // required={this.props.validation !== undefined ? this.props.validation.required : false}
            data-tip={this.state.focusOut && !this.props.value && this.props.validation.required ? 'This field is required.' : ''}
            data-for={this.props.name}
          >
            {this.props.elementConfig.isSelectWithInput ? (
              <>
                <option value="" selected disabled hidden>
                  Select
              </option>
                <option value=""> </option>
              </>
            ) : (
                <option value=""> </option>
              )}

            {this.props.elementConfig.options.map((option, index) => (
              <option key={index} value={option.value || option.rowId}>
                {option.displayValue}
              </option>
            ))}
          </select>
          {this.props.elementConfig.isSelectWithInput ? <></> : <span>{LabelName}</span>}
        </StyledSingleSelect>
        <StyledTooltip backgroundColor='#FF4713' place="right" effect="solid" id={this.props.name} />
      </>
    );
  }
}

export default SingleSelectDropdown;

SingleSelectDropdown.propTypes = {
  /**
   *This is to set the configuration of the element
   */
  elementConfig: PropTypes.object,
  /**
   *This is to show the name of the element (Comes under elementConfig)
   */
  placeholder: PropTypes.string,
  /**
   *This is to show the value of the element
   */
  value: PropTypes.any,
  /**
   *This is to give a name (id) for the element (must be unique for multiple elements)
   */
  name: PropTypes.string,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  xs: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  sm: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  md: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  lg: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  xl: PropTypes.number,
  /**
   *This is onChange function of the element
   */
  changed: PropTypes.func,
  /**
   *This is value of options in element ( format --- {value = " value", displayValue = " display value ")
   */
  options: PropTypes.array,
};
