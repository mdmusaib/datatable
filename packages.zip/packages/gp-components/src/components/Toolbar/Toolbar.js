import React, { Fragment } from 'react';
import { toolbar as toolbarStyle } from '../../tokens/components';
import { StyledElement } from '../utils/element';

let ToolbarIconStyle = StyledElement('div')(toolbarStyle.toolbarIconStyle);
let ToolbarContainer = StyledElement('div')(toolbarStyle.toolbarContainer);

let Toolbar = props => {
  return (
    <ToolbarContainer {...props}>
      <ToolbarIconStyle>{props.children}</ToolbarIconStyle>
    </ToolbarContainer>
  );
};

export default Toolbar;
