export default [
  {
    title: 'Product Library',
    icon: 'document',
    width: '24',
  },
  {
    title: 'Product Catalog',
    icon: 'imageLibrary',
    width: '24',
  },
  {
    title: 'Module Catalog',
    icon: 'partsCatalog',
    width: '24',
  },
  {
    title: 'Container Catalog',
    icon: 'excel',
    width: '24',
  },
  {
    title: 'Notes Library',
    icon: 'partsUsage',
    width: '24',
  },
  {
    title: 'Manage Schedules',
    icon: 'word',
    width: '24',
  },
  {
    title: 'Decision Support',
    icon: 'gear',
    width: '24',
  },
  {
    title: 'Scratch Pad',
    icon: 'file1',
    width: '24',
  },
];
