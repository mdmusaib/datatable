import SVGIcons from '../../assets/images/svg';
const importAll = r => {
  let images = {};
  r.keys().map((item, index) => {
    images[
      item
        .split('/')
        .slice(-1)
        .join()
        .split('.')
        .shift()
    ] = r(item);
  });

  return images;
};
const drawingToolIcons = importAll(require.context('../../assets/images/drawerTool/icons/tools', true, /.*\.*$/));
const gridIcons = importAll(require.context('../../assets/images/grid', true, /.*\.*$/));
const modalWindowIcons = importAll(require.context('../../assets/images/popMessageIcon', true, /.*\.png$/));
const treeIcon = importAll(require.context('../../assets/images/treeIcons', true, /.*\.png$/));
const partsCatalog = importAll(require.context('../../assets/images/partsCatalog', true, /.*\.*$/));
const svgs = importAll(require.context('../../assets/images/svg', true, /.*\.svg$/));
const moduleIcons = importAll(require.context('../../assets/images/moduleIcons', true, /.*\.*$/));
export default {
  drawingToolIcons,
  gridIcons,
  modalWindowIcons,
  treeIcon,
  partsCatalog,
  svgs,
  moduleIcons,
};

export { SVGIcons };
