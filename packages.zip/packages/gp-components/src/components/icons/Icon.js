import React from 'react';
import source, { SVGIcons } from './IconSource';
import { StyledElement } from '../utils/element';
import { icon as iconStyle } from '../../tokens/components';
import PropTypes from 'prop-types';
import Element from '../utils/element';

const StyledImg = StyledElement('img')(iconStyle.iconStyle);
const StyledIconBitton = StyledElement('span')(iconStyle.svgIconButtonStyle);

const Icon = ({ icon, width, height, type, as, ...props }) => {
  let isDeep = icon.indexOf('.') > 0;
  let psource = !isDeep ? source[icon] : source[icon.split('.')[0]][icon.split('.')[1]];
  if (type === 'svg') {
    const SVGIcon = SVGIcons[icon];
    // return
    if (as === 'button') {
      return (
        <StyledIconBitton>
          <Element
            as={SVGIcon}
            width={width}
            height={height}
            {...iconStyle.svgIconStyle({ ...props, width, height })}
          />
        </StyledIconBitton>
      );
    } else {
      return (
        <Element as={SVGIcon} width={width} height={height} {...props} {...iconStyle.svgIconStyle({ ...props, width, height })} />
      );
    }
  } else {
    return <StyledImg src={psource} alt={icon} width={width} height={height} {...props} />;
  }
};

export default Icon;

Icon.propTypes = {
  /**
   *Which icon needs to display
   */
  icon: PropTypes.string.isRequired,
  /**
   *This to explicit specify width
   */
  width: PropTypes.string,
  /**
   *This to explicit specify height
   */
  height: PropTypes.string,
  /**
   *This the type of the icon
   */
  type: PropTypes.string,
  /**
   *This is the color of the svg icon
   */
  svgIconColor: PropTypes.string,
};

Icon.defaultProps = {
  width: '16',
  height: '16',
  type: '',
  svgIconColor: 'svgIconColorLight',
};
