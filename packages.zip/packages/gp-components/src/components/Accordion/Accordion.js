import React, { Fragment } from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import styled from '@emotion/styled';
import Icon from './../icons/Icon';
import { accordion as accordionStyle } from '../../tokens/components';

let StyledAccordion = styled('div')(accordionStyle);

const Accordian = props => {
  return (
    <StyledAccordion {...props}>
      <Row className="accordianRow" onClick={props.toggleAccordion}>
        <Col className="accordianCol">
          <div className="accordianHeadingContainer">
            <span className="accordionToggleIcon">
              <Icon type="svg" icon="downArrow" svgIconColor="white" width="12" height="12" />
            </span>
            <span className="accordionTitle">{props.accordionHeading}</span>
          </div>
        </Col>
      </Row>
      <Row className="accordianChildren">{props.children}</Row>
    </StyledAccordion>
  );
};

export default Accordian;
