import React from 'react';
import Icon from './../icons/Icon';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { collapsedAccordion as collapsedAccordionStyle } from './../../tokens/components';

let StyledAccordion = styled('div')(collapsedAccordionStyle);

const CollapsedAccordion = props => {
  return (
    <StyledAccordion onClick={props.toggleAccordion}>
      <span className="CollapsedIcon">
        <Icon type="svg" icon="downArrow" svgIconColor="white" width="12" height="12" />
      </span>
      <span className="AccordionTitle">{props.panelName}</span>
    </StyledAccordion>
  );
};

CollapsedAccordion.propTypes = {};

export default CollapsedAccordion;
