import React from 'react';
import PropTypes from 'prop-types';
import Backdrop from './../Backdrop/Backdrop';
import styled from '@emotion/styled';
import { modal as modalStyle } from './../../tokens/components';
import Icon from './../icons/Icon';
import { Container, Row, Col } from 'react-bootstrap';
import Draggable, { DraggableCore } from 'react-draggable';

let StyledModal = styled('div')(modalStyle);

class Modal extends React.Component {

    state = {
        activeDrags: 0,
    }

    onStart = () => {
        this.setState({ activeDrags: ++this.state.activeDrags });
    };

    onStop = () => {
        this.setState({ activeDrags: --this.state.activeDrags });
    };

    render() {
        const dragHandlers = { onStart: this.onStart, onStop: this.onStop };
        return (
            this.props.show ?
                <React.Fragment>

                    <Backdrop show={this.props.show} />
                    <Draggable
                        handle=".ModalHeading"
                        {...dragHandlers}
                        bounds={this.props.FormatModal ? { top: -80, left: -100, right: 100, bottom: 100 } : { top: -200, left: -450, right: 450, bottom: 250 }}
                    >
                        <StyledModal
                            modalHeight={this.props.modalHeight}
                            modalWidth={this.props.modalWidth}
                            FormatModal={this.props.FormatModal}
                            fullScreenModal={this.props.fullScreenModal}
                            style={{
                                transform: this.props.show ? 'translateY(0)' : 'translateY(-100vh)',
                                zIndex: '600',
                                opacity: this.props.show ? '1' : '0',
                            }}
                        >
                            <div className="ModalContainer">
                                <div className="ModalHeading">
                                    <span>
                                        <p>{this.props.title}</p>
                                    </span>
                                    <div className="ModalHeadingIcon">
                                        {this.props.fullScreen ? (
                                            this.props.fullScreenModal ?
                                                // <Icon icon="treeIcon.popUpMaximize" onClick={this.props.fullScreenClicked} size={20} />
                                                <Icon style={{ margin: '0 4px' }} onClick={this.props.fullScreenClicked} type="svg" icon="popUpMinimize" svgIconColor="white" width="12" height="12" />
                                                :
                                                <Icon style={{ margin: '0 4px' }} onClick={this.props.fullScreenClicked} type="svg" icon="popUpMaximize" svgIconColor="white" width="12" height="12" />
                                        ) : (
                                                <></>
                                            )}
                                        {/* {this.props.minimize ? (
                                            <Icon icon="treeIcon.treeIcons_minimize" onClick={this.props.fullScreenClicked} size={20} />
                                        ) : (
                                                <></>
                                            )} */}
                                        <span>
                                            <Icon style={{ margin: '0 4px' }} onClick={this.props.closeClicked} type="svg" icon="popUpClose" svgIconColor="white" width="12" height="12" />
                                        </span>
                                    </div>
                                </div>
                                <div className="ModalBody">
                                    {this.props.children}
                                </div>
                            </div>
                        </StyledModal>
                    </Draggable>
                </React.Fragment>
                :
                <></>
        );
    }
}

export default Modal;

Modal.propTypes = {
    /**
     *This is to show the backdrop
     */
    show: PropTypes.bool,
    /**
     *This is to show the backdrop
     */
    backdropClicked: PropTypes.func,
    /**
     *This is set Modal size
     */
    FormatModal: PropTypes.bool,
};
