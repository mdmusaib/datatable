import React from 'react';
import PropTypes from 'prop-types';
import { button as buttonStyle } from '../../tokens/components';
import { StyledElement } from '../utils/element';

let StyledButton = StyledElement('button')(buttonStyle);
let Button = function(props) {
  return (
    <StyledButton data-testid="toggle" onClick={props.onButtonClick} {...props}>
      {props.icon ? <span className="icon">{props.icon}</span> : <></>}
      {props.children}
    </StyledButton>
  );
};

//export { Sbutton };
export default Button;

Button.propTypes = {
  /**
   * The different variants of button.
   * Can be any variants of below
   */
  variant: PropTypes.oneOf([
    'primary',
    'secondary',
    'success',
    'info',
    'warning',
    'danger',
    'focus',
    'alt',
    'light',
    'dark',
  ]),
  /**
   * The Callback function on click on the button
   */
  onButtonClick: PropTypes.func,
};

Button.defaultProps = {
  variant: 'primary',
};
