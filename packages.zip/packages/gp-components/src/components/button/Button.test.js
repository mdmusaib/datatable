import React from 'react';
import { render, unmountComponentAtNode } from 'react-dom';
import { act } from 'react-dom/test-utils';
import Button from './Button';

let container = null;
beforeEach(() => {
  // setup a DOM element as a render target
  container = document.createElement('div');
  document.body.appendChild(container);
});

afterEach(() => {
  // cleanup on exiting
  unmountComponentAtNode(container);
  container.remove();
  container = null;
});

it('trigger click event on click', () => {
  const onClick = jest.fn();
  act(() => {
    render(<Button onButtonClick={onClick}>Hello</Button>, container);
  });
  // get ahold of the button element, and trigger some clicks on it
  const button = document.querySelector('[data-testid=toggle]');
  expect(button.innerHTML).toBe('Hello');

  act(() => {
    button.dispatchEvent(new MouseEvent('click', { bubbles: true }));
  });
  expect(onClick).toHaveBeenCalledTimes(1);
});
test('adds 1 + 2 to equal 3', () => {
  expect(3).toBe(3);
});
