import React from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import Icon from './../icons/Icon';
import styled from '@emotion/styled';
import { treeLayout as treeLayoutStyle } from './../../tokens/components';

let StyledTreeLayout = styled(Container)(treeLayoutStyle);

const TreeLayout = props => {
  return (
    <StyledTreeLayout showList={props.showList} height={props.height}>
      <Row className="TreeLayoutRow">
        <Col className="TreeLayoutCol">
          <div onClick={props.headerToggle} className="TreeLayoutHeaderContainer">
            <span className="TreeLayoutHeader">{props.header}</span>
          </div>
          <div className="TreeLayoutHeaderIconContainer">
            {props.addGreen ? (
              <span className="TreeLayoutHeaderIcon">
                <Icon icon="treeIcon.add_green" width="14px" height="14px"></Icon>
              </span>
            ) : (
              <></>
            )}
            {props.refresh ? (
              <span className="TreeLayoutHeaderIcon">
                <Icon icon="treeIcon.refresh" width="14px" height="14px"></Icon>
              </span>
            ) : (
              <></>
            )}
          </div>
        </Col>
      </Row>
      {props.showList ? (
        <>
          <Row>
            <Col md={12} className="TreeLayoutSearchContainer">
              {props.hideSearchField ? (
                <div className="TreeLayoutSearchLayout">
                  <input type="text" />
                </div>
              ) : (
                <></>
              )}
              <div className="TreeLayoutSearchIconLayout">
                {props.searchGreen ? (
                  <span className="TreeLayoutSearchIconLayout-search">
                    <Icon style={{ verticalAlign: 'sub' }} icon="treeIcon.treeIcon_search"></Icon>
                  </span>
                ) : (
                  <></>
                )}
                {props.clear ? (
                  <span className="TreeLayoutSearchIconLayout-close">
                    <Icon style={{ verticalAlign: 'sub' }} icon="treeIcon.treeIcons_close"></Icon>
                  </span>
                ) : (
                  <></>
                )}
              </div>
            </Col>
          </Row>
          <Row className="TreeLayoutChildrenRow">
            <Col md={12} className="TreeLayoutChildrenCol">
              {props.children}
            </Col>
          </Row>
        </>
      ) : (
        <></>
      )}
    </StyledTreeLayout>
  );
};

export default TreeLayout;
