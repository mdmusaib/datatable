import React from 'react';
import { StyledElement } from '../utils/element';
const StyledErrorWrapper = StyledElement('div')({
  position: 'absolute',
  padding: '10px',
  width: '500px',
  height: '200px',
  left: '50%',
  top: '50%',
  transform: 'translate(-50%,-50%)',
  boxShadow: '0px 0px 5px rgba(0,0,0,.6)',
  overFlow: 'hidden',
  bg: 'white',
  '& > span': {
    fontSize: '14px',
    color: 'orange',
  },
  '& > pre': {
    color: 'grey',
    height: '80%',
    fontSize: '12px',
  },
});
class CatchShowError extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null, errorInfo: null };
  }

  componentDidCatch(error, errorInfo) {
    // Catch errors in any components below and re-render with error message
    this.setState({
      error: error,
      errorInfo: errorInfo,
    });
    // You can also log error messages to an error reporting service here
  }

  render() {
    if (this.state.errorInfo) {
      console.log(this.state.error);
      // Error path
      return (
        <StyledErrorWrapper>
          <span>Something went wrong.</span>
          <pre>
            <b>{this.state.error && this.state.error.toString()}</b>
            {this.state.errorInfo.componentStack}
          </pre>
        </StyledErrorWrapper>
      );
    }
    // Normally, just render children
    return this.props.children;
  }
}

export default CatchShowError;
