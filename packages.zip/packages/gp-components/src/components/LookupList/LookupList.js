import React, { Component } from 'react';
import styled from '@emotion/styled';
import { lookupList as StyledLookupList } from '../../tokens/components';
import Icon from './../icons/Icon';

const StyledFloatingInput = styled('div')(StyledLookupList);
class LookupList extends Component {
  state = {
    value: null,
    errorMessage: '',
    selectedItem: '',
    options: [],
  };

  componentDidMount() {
    let options = this.props.elementConfig.options;

    this.setState({
      options,
    });
  }

  listItemClicked = (event, value) => {
    event.preventDefault();
    console.log('-----', value);
    this.setState({
      selectedItem: value,
    });
  };

  clearClicked = event => {
    event.preventDefault();

    if (this.state.selectedItem) {
      let options = this.state.options.map(a => ({ ...a }));
      for (var i = 0; i < options.length; i++) {
        if (options[i].value && options[i].value === this.state.selectedItem) {
          options.splice(i, 1);
          break;
        }
      }
      this.setState({
        options: options,
      });
    }
  };

  render() {
    const LabelName = [this.props.elementConfig.placeholder];
    if (this.props.validation) {
      if (this.props.validation.required) {
        LabelName.push(<mark> *</mark>);
      }
    }

    return (
      <StyledFloatingInput>
        <div className="LookupListGroup">
          <ul>
            {this.state.options.map((list, index) => {
              return (
                <li
                  className={this.state.selectedItem === list.value ? 'ListSelect' : 'List'}
                  onClick={event => this.listItemClicked(event, list.value)}
                  key={index}
                  value={list.value}
                >
                  {list.displayValue || list.value}
                </li>
              );
            })}
          </ul>
          <div className="IconGroup">
            <span>
              <Icon type="svg" icon="search" svgIconColor="grey_31" width="15" height="15" />
            </span>
            <span onClick={e => this.clearClicked(e)}>
              <Icon type="svg" icon="clear" svgIconColor="grey_31" width="20" height="20" />
            </span>
          </div>
        </div>
        <span className="LookupListLabel">{LabelName}</span>
      </StyledFloatingInput>
    );
  }
}

export default LookupList;
