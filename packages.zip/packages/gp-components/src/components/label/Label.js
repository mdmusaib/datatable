import React from 'react';
import { StyledElement } from '../utils/element';
import PropTypes from 'prop-types';
import { label as labelStyle } from '../../tokens/components';

//const StyledLabel = styled(Element)(props => css(labelStyle(props)));
const StyledLabel = StyledElement('span')(labelStyle);

const Label = props => (
  <StyledLabel onClick={props.onClickLink} {...props}>
    {props.isMandatory ? <span>*</span> : null}
    {props.children}
  </StyledLabel>
);

Label.propTypes = {
  /**
   *This is to show its a mand
   */
  isMandatory: PropTypes.bool,
};

Label.defaultProps = {
  isMandatory: false,
};

export default Label;
