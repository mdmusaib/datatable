import React from 'react';
import Icon from './../icons/Icon';
import styled from '@emotion/styled';
import { arrow as arrowStyle } from '../../tokens/components';

const StyledArrow = styled('li')(arrowStyle);

const Checkbox = ({ selected, label, onChange, nodeType, hasChildren, level }) => {
  // console.log('selected',label)
  return (
    <StyledArrow isRoot={level}>
      <div className="NodeContainer">
        <div className="Overlay"></div>
        {!selected && hasChildren ? (
          <span>
            <Icon width="8px" height="8px" icon="treeIcon.right_arrow_black" onClick={() => onChange(!selected)} />
          </span>
        ) : hasChildren ? (
          <span>
            <Icon
              width="8px"
              height="8px"
              style={{ transform: 'rotate(90deg)' }}
              icon="treeIcon.right_arrow_black"
              onClick={() => onChange(!selected)}
            />
          </span>
        ) : (
          <></>
        )}
        <span>
          <Icon className="LabelIcon" icon={'treeIcon.' + nodeType} />
        </span>
        <span className="LabelName">{label}</span>
      </div>
    </StyledArrow>
  );
};

export default Checkbox;
