import React from 'react';
import Arrow from './Arrow';
import styled from '@emotion/styled';
import { tree as treeStyle } from '../../tokens/components';

const StyledTree = styled('ul')(treeStyle);

const Tree = ({ options, selectedOptions, onChange, level }) => {
  // let key = null

  const handleCheckboxClicked = selectedOptionId => {
    // is currently selected
    if (selectedOptions[selectedOptionId]) {
      // remove selected key from options list
      delete selectedOptions[selectedOptionId];
    } else {
      // is not currently selected
      // Add selected key to optionsList
      selectedOptions[selectedOptionId] = {};
      //saveName(selectedOptionId)
    }
    // call onChange function given by parent
    //console.log('selectedOptionId....----', selectedOptionId)
    localStorage.setItem('clickedData', selectedOptionId);
    onChange(selectedOptions);
  };

  const handleSubOptionsListChange = (optionId, subSelections) => {
    // add sub selections to current optionId
    selectedOptions[optionId] = subSelections;
    // call onChange function given by parent
    onChange(selectedOptions);
  };

  return (
    <div className="TreeContainer">
      {options.map((option, index) => (
        <StyledTree isRoot={level} key={index}>
          {console.log(level)}
          <Arrow
            level={level}
            selected={selectedOptions[option.id]}
            label={option.name}
            onChange={() => {
              handleCheckboxClicked(option.id);
            }}
            nodeType={option.type}
            hasChildren={option.hasChildren}
          />

          {/* Base Case */}
          {option.subOptions.length > 0 && selectedOptions[option.id] && (
            <Tree
              options={option.subOptions}
              selectedOptions={selectedOptions[option.id]}
              onChange={subSelections => handleSubOptionsListChange(option.id, subSelections)}
              nodeType={option.type}
              hasChildren={option.hasChildren}
              level="child"
            />
          )}
        </StyledTree>
      ))}
    </div>
  );
};

export default Tree;
