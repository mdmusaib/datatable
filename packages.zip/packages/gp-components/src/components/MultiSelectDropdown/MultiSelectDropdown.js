import React, { useState } from 'react'
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { Col, Container, Row } from 'react-bootstrap'
import { multiSelectDropdown as multiSelectDropdownStyle } from '../../tokens/components';

const StyledMultiSelect = styled('div')(multiSelectDropdownStyle)

const MultiSelectDropdown = props => {

    const [value, setValue] = useState(props.value)
    const LabelName = [props.elementConfig.placeholder];
    if (props.validation) {
        if (props.validation.required) {
            LabelName.push(<span style={{ color: 'red' }}> *</span>)
        }
    }

    return (
        <StyledMultiSelect
        // inValid={props.valid === false && props.touched === true}
        // className="MultiSelect" 
        // xs={props.elementConfig.xs || 6} sm={props.elementConfig.sm || 6} md={props.elementConfig.md || 6} lg={props.elementConfig.lg || 6} xl={props.elementConfig.xl || 6} 
        >
            {/* <Container>
                <Row>
                    <Col md={12}>
                       
                    </Col>
                    <Col md={12}> */}
            <label>{LabelName}</label>
            <select
                multiple
                native
                value={props.value}
                onChange={props.changed}
                onBlur={props.onBlur}
                onFocus={props.onFocus}
                // inputProps={this.validation}
                name={props.name}
            //style={props.style}
            >
                <option selected disabled>--SELECT--</option>
                {props.elementConfig.options.map((option, index) => (
                    <option key={index} value={option.value}>
                        {option.displayValue}
                    </option>
                ))}
            </select>
            {/* </Col>
                </Row>
            </Container> */}


        </StyledMultiSelect>
    );
}

export default MultiSelectDropdown;

MultiSelectDropdown.propTypes = {
    /**
     *This is to set the configuration of the element
     */
    elementConfig: PropTypes.object,
    /**
     *This is to show the name of the element (Comes under elementConfig)
     */
    placeholder: PropTypes.string,
    /**
     *This is to show the value of the element
     */
    value: PropTypes.array,
    /**
     *This is to give a name (id) for the element (must be unique for multiple elements)
     */
    name: PropTypes.string,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    xs: PropTypes.number,
    /**
    *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
    */
    sm: PropTypes.number,
    /**
      *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
      */
    md: PropTypes.number,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    lg: PropTypes.number,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    xl: PropTypes.number,
    /**
     *This is onChange function of the element
     */
    changed: PropTypes.func,
    /**
     *This is value of options in element ( format --- {value = " value", displayValue = " display value ")
     */
    options: PropTypes.array

};
