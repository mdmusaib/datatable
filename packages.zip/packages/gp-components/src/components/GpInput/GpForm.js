// import React, { Component } from 'react';
// import Input from './GpInput';
// import moment from 'moment';
// class GpForm extends Component {
//   constructor(props) {
//     super(props);
//     this.state = this.getInitialState();
//   }
//   getInitialState = () => {
//     // creating Complete Form Structure as a JSON object.
//     const startDate = moment('01/01/2000').toDate();
//     const initialState = {
//       FormStructure: {
//         name: {
//           elementType: 'input',
//           elementConfig: {
//             type: 'Code',
//             placeholder: 'Code',
//             md: 5,
//             lg: 5,
//             xl: 5,
//           },
//           value: '',
//           validation: {
//             required: true,
//             pattern: '^[a-zA-Z& (),._"\'-]*$',
//           },
//           valid: false,
//           touched: false,
//         },

//         select: {
//           elementType: 'select',
//           elementConfig: {
//             options: [
//               { value: 'Single', displayValue: 'Single Val' },
//               { value: 'Second', displayValue: 'Second Val' },
//               { value: 'Third', displayValue: 'Third Val' },
//             ],
//             label: '---Select---',
//             type: 'select',
//             placeholder: 'Single Select',
//             md: 6,
//             lg: 10,
//             xl: 8,
//           },

//           value: '',
//           validation: {
//             required: true,
//             pattern: '^[a-zA-Z& (),._"\'-]*$',
//           },
//           valid: false,
//           touched: false,
//         },

//         Multi: {
//           elementType: 'selectMultiple',
//           elementConfig: {
//             options: [
//               { value: 'Single', displayValue: 'Single Val' },
//               { value: 'Second', displayValue: 'Second Val' },
//               { value: 'Third', displayValue: 'Third Val' },
//             ],
//             label: '---Select---',
//             type: 'select',
//             placeholder: 'Multiple Select',
//             md: 6,
//             lg: 10,
//             xl: 8,
//           },
//           value: [],
//           validation: {
//             required: true,
//             pattern: '^[a-zA-Z& (),._"\'-]*$',
//           },
//           valid: false,
//           touched: false,
//         },
//         phoneNumber: {
//           elementType: 'input',
//           elementConfig: {
//             type: 'number',
//             placeholder: 'Number of the role',
//             md: 10,
//             lg: 10,
//             xl: 10,
//           },
//           value: '',
//           validation: {
//             required: true,
//             pattern: '[0-9]{10}$',
//           },
//           valid: false,
//           touched: false,
//         },
//         description: {
//           elementType: 'textarea',
//           elementConfig: {
//             type: 'text',
//             placeholder: 'Description of the role',
//             md: 10,
//             lg: 10,
//             xl: 10,
//           },
//           value: '',
//           validation: {
//             required: false,
//             pattern: '^[a-zA-Z0-9& (),._"\'-]*$',
//           },
//           valid: false,
//           touched: false,
//         },
//         startDate: {
//           elementType: 'startDate',
//           elementConfig: {
//             // type:'startDate',
//             minDate: null,
//             openToDate: moment('01/01/2000').toDate(),
//           },
//           value: startDate,
//           // disabled:true,
//           // minDate:moment('01/01/2000').toDate(),
//           onChangeDatePicker: this.handleDatepickerChanges,
//           validation: {
//             required: true,
//           },
//           valid: false,
//           touched: false,
//         },
//         endDate: {
//           elementType: 'endDate',
//           elementConfig: {
//             // type:'endDate',
//             // openToDate: ""
//           },
//           value: '',
//           disabled: false,
//           minDate: '',
//           onChangeDatePicker: this.handleDatepickerChanges,
//           validation: {
//             required: true,
//           },
//           valid: false,
//           touched: false,
//         },
//       },
//       formIsValid: false,
//       minDate: null,
//       formModified: false,
//     };
//     return initialState;
//   };
//   resetForm = () => {
//     this.setState(this.getInitialState());
//   };

//   checkValidity(value, rules) {
//     let isValid = false;

//     if (rules.required === true) {
//       if (typeof value === 'object') {
//         isValid = value.length !== 0;
//       } else {
//         isValid = value.trim() !== '';
//       }
//     } else {
//       isValid = true;
//     }

//     return isValid;
//   }

//   userInputChangedHandler = (event, userInputIdentifier, state = 'FormStructure') => {
//     console.log(userInputIdentifier);
//     // if (userInputIdentifier == "startDate" || "endDate") {

//     // } else {
//     let currentState = this.state;
//     const updatedUserForm = {
//       ...this.state[state],
//     };

//     const updatedUserFormElement = {
//       ...updatedUserForm[userInputIdentifier],
//     };

//     if (updatedUserFormElement.elementType === 'selectMultiple') {
//       // let data=userInputIdentifier.value.indexOf(event.target.value);
//       let index = '';
//       if ((index = updatedUserFormElement.value.indexOf(event.target.value)) === -1) {
//         updatedUserFormElement.value.push(event.target.value);
//       } else {
//         updatedUserFormElement.value.splice(index, 1);
//       }
//     } else {
//       updatedUserFormElement.value = event.target.value;
//     }

//     updatedUserFormElement.valid = this.checkValidity(updatedUserFormElement.value, updatedUserFormElement.validation);
//     updatedUserFormElement.touched = true;
//     updatedUserForm[userInputIdentifier] = updatedUserFormElement;

//     let formIsValid = true;
//     let formElements = updatedUserForm;
//     for (let userInputIdentifier in formElements) {
//       if (
//         formElements[userInputIdentifier].value !== undefined &&
//         formElements[userInputIdentifier].validation.required
//       ) {
//         formIsValid = formElements[userInputIdentifier].valid && formIsValid;
//       }
//     }
//     currentState[state] = updatedUserForm;
//     currentState.formIsValid = formIsValid;

//     this.setState(currentState);
//     // }
//   };
//   handleDatepickerChanges = (event, userInputIdentifier, state = 'FormStructure') => {
//     if (event === null) {
//       let currentState = this.state;
//       // this.setState({
//       //  currentState:currentState
//       // });
//       let userInputIdentifier = 'endDate';

//       const updatedUserForm = {
//         ...this.state[state],
//       };
//       const updatedUserFormElement = {
//         ...updatedUserForm[userInputIdentifier],
//       };
//       // console.log(updatedUserFormElement)
//       updatedUserFormElement.disabled = true;
//       updatedUserForm[userInputIdentifier] = updatedUserFormElement;
//       currentState[state] = updatedUserForm;
//       // console.log(updatedUserFormElement)
//       this.setState({
//         updatedUserFormElement,
//       });
//       // console.log(updatedUserFormElement)
//     } else {
//       let currentState = this.state;
//       let userInputIdentifier = 'endDate';

//       const updatedUserForm = {
//         ...this.state[state],
//       };
//       const updatedUserFormElement = {
//         ...updatedUserForm[userInputIdentifier],
//       };
//       console.log(updatedUserForm);
//       updatedUserFormElement.disabled = false;
//       updatedUserForm[userInputIdentifier] = updatedUserFormElement;
//       currentState[state] = updatedUserForm;
//       // console.log(updatedUserFormElement)
//       this.setState({
//         updatedUserFormElement,
//       });
//     }

//     var currentState = this.state;
//     console.log(currentState);
//     const updatedUserForm = {
//       ...this.state[state],
//     };
//     const updatedUserFormElement = {
//       ...updatedUserForm[userInputIdentifier.elementType],
//     };
//     if (userInputIdentifier.elementType === 'startDate') {
//       updatedUserFormElement.value = event;
//       currentState.minDate = event;

//       updatedUserForm[userInputIdentifier.elementType] = updatedUserFormElement;
//       currentState[state] = updatedUserForm;
//       this.setState(
//         {
//           updatedUserFormElement,
//         },
//         () => {
//           console.log(this.state);
//         },
//       );
//     } else {
//       updatedUserFormElement.value = event;
//       updatedUserForm[userInputIdentifier.elementType] = updatedUserFormElement;
//       currentState[state] = updatedUserForm;
//       this.setState({
//         updatedUserFormElement,
//       });
//     }
//   };
//   render() {
//     let inputs = [];
//     const keys = Object.keys(this.state.FormStructure);
//     for (const key of keys) {
//       const formElement = this.state.FormStructure[key];
//       console.log(formElement);
//       inputs.push(
//         <Input
//           key={key}
//           name={key}
//           elementType={formElement.elementType}
//           elementConfig={formElement.elementConfig}
//           disabled={formElement.disabled}
//           minDate={this.state.minDate}
//           value={formElement.value}
//           invalid={!formElement.valid}
//           touched={formElement.touched}
//           changed={event => {
//             if (typeof formElement.onChangeDatePicker === 'function') {
//               formElement.onChangeDatePicker(event, formElement);
//             } else {
//               this.userInputChangedHandler(event, key);
//             }
//             // } else if (typeof formElement.onChangeEndDateFunc === "function") {
//             //   formElement.onChangeEndDateFunc(event);
//             // }
//           }}
//           //   blur={event => {
//           //     this.handleBlurInputs(event, key);
//           //   }}
//           //   focus={event => {
//           //     this.handleFocusInputs(event, key);
//           //   }}
//           validation={formElement.validation}
//         />,
//       );
//     }

//     let forms = (
//       <React.Fragment>
//         {/* <h6>Create Role</h6> */}
//         <form autocomplete="off" ref={this.form} onChange={this.formModified} onSubmit={this.roleCreateConfirmHandler}>
//           {/* <Grid container spacing={24}> */}
//           {inputs}
//           {/* <FormActions
//             style={{
//               position: "absolute",
//               right: "250px",
//               bottom: "70px"
//             }}
//             formIsValid={this.state.formIsValid}
//             onCancel={this.resetForm}
//           ></FormActions> */}
//           {/* </Grid> */}
//         </form>
//       </React.Fragment>
//     );

//     return <React.Fragment>{forms}</React.Fragment>;
//   }
// }

// export default GpForm;
