// import React from 'react';
// // import classes from './Inputs.css'
// // import Add from '@material-ui/icons/Add';
// import Radio from '@material-ui/core/Radio';
// import Select from '@material-ui/core/Select';
// import Checkbox from '@material-ui/core/Checkbox';
// import FormLabel from '@material-ui/core/FormLabel';
// // import TextField from '@material-ui/core/TextField';
// // import InputLabel from '@material-ui/core/InputLabel';
// // import Typography from '@material-ui/core/Typography';
// import FormControl from '@material-ui/core/FormControl';
// // import NativeSelect from '@material-ui/core/NativeSelect';
// // import OutlinedInput from '@material-ui/core/OutlinedInput';
// import FormHelperText from '@material-ui/core/FormHelperText';
// import FormControlLabel from '@material-ui/core/FormControlLabel';

// import ValidationClass from './GpInputValidations';
// import DatePicker from 'react-datepicker';

// import 'react-datepicker/dist/react-datepicker.css';
// class GpInput extends ValidationClass {
//   constructor(props) {
//     super(props);
//     this.state = {
//       errorMessage: '',
//     };
//   }

//   render() {
//     let inputElement = null;
//     // const inputClasses = [classes.InputElement];

//     // if (this.props.isInputFocus) {
//     //     inputClasses.push(classes.InputField);
//     // }

//     // if (this.props.invalid && this.props.touched) {
//     //     inputClasses.push(classes.Invalid);
//     // }

//     switch (this.props.elementType) {
//       case 'Text Input':
//       case 'input':
//         inputElement = ( // item xs={this.props.elementConfig.xs || 12} sm={this.props.elementConfig.sm || 12} md={this.props.elementConfig.md || 12} lg={this.props.elementConfig.lg || 12} xl={this.props.elementConfig.xl || 12}>
//           <input
//             // error={(this.state.errorMessage.length > 0) ? true : false}
//             className={this.state.errorMessage.length > 0 ? 'danger' : 'normal'}
//             required={this.props.validation !== undefined ? this.props.validation.required : false}
//             id={this.props.name}
//             name={this.props.name}
//             label={this.props.elementConfig.label || this.props.elementConfig.placeholder}
//             placeholder={this.props.elementConfig.placeholder}
//             // fullWidth
//             // variant={this.props.elementConfig.variant || 'outlined'}
//             margin="none"
//             onChange={this.props.changed}
//             onBlur={this.validation}
//             onKeyDown={this.validation}
//             value={this.props.value}
//             onFocus={this.validation}
//             helperText={this.state.errorMessage}
//             type={this.props.elementConfig.type}
//             inputProps={this.props.validation}
//             disabled={this.props.disabled}
//             style={this.props.style}
//           />
//         );
//         //
//         break;

//       case 'inputState':
//         inputElement = (
//           // item xs={this.props.elementConfig.xs || 12} sm={this.props.elementConfig.sm || 12} md={this.props.elementConfig.md || 12} lg={this.props.elementConfig.lg || 12} xl={this.props.elementConfig.xl || 12}>
//           <input
//             // error={(this.state.errorMessage.length > 0) ? true : false}
//             // className={this.state.errorMessage.length>0?danger:primary}
//             // className={classes.input}
//             required={this.props.validation !== undefined ? this.props.validation.required : false}
//             id={this.props.name}
//             name={this.props.name}
//             label={this.props.elementConfig.label || this.props.elementConfig.placeholder}
//             placeholder={this.props.elementConfig.placeholder}
//             fullWidth
//             variant={this.props.elementConfig.variant || 'outlined'}
//             onChange={this.props.changedState}
//             value={this.props.value}
//             onBlur={this.props.blur}
//             onFocus={this.validation}
//             helperText={this.state.errorMessage}
//             type={this.props.elementConfig.type}
//             inputProps={this.props.validation}
//             style={this.props.style}
//           />
//         );
//         //
//         break;

//       case 'Text Area':
//       case 'textarea':
//         inputElement = ( // item xs={this.props.elementConfig.xs || 12} sm={this.props.elementConfig.sm || 12} md={this.props.elementConfig.md || 12} lg={this.props.elementConfig.lg || 12} xl={this.props.elementConfig.xl || 12}>
//           <textarea
//             error={this.state.errorMessage.length > 0 ? true : false}
//             // className={classes.input}
//             required={this.props.validation !== undefined ? this.props.validation.required : false}
//             id={this.props.name}
//             name={this.props.name}
//             label={this.props.elementConfig.label || this.props.elementConfig.placeholder}
//             placeholder={this.props.elementConfig.placeholder}
//             fullWidth
//             multiline={true}
//             rows={2}
//             variant={this.props.elementConfig.variant || 'outlined'}
//             onChange={this.props.changed}
//             value={this.props.value}
//             onBlur={this.props.blur}
//             onFocus={this.validation}
//             helperText={this.state.errorMessage}
//             inputProps={this.props.validation}
//             style={this.props.style}
//           />
//         );
//         //
//         break;

//       case 'Single Selection Drop Down':
//       case 'select':
//         inputElement = ( // item xs={this.props.elementConfig.xs || 12} sm={this.props.elementConfig.sm || 12} md={this.props.elementConfig.md || 12} lg={this.props.elementConfig.lg || 12} xl={this.props.elementConfig.xl || 12}>
//           <FormControl fullWidth variant="outlined" error={this.state.errorMessage.length > 0 ? true : false}>
//             {/* <InputLabel
//                             ref={ref => {
//                                 this.InputLabelRef = ref;
//                             }}
//                             htmlFor={this.props.name}
//                             required={this.props.validation !== undefined ? this.props.validation.required : false}

//                         >
//                             {this.props.elementConfig.label || this.props.elementConfig.placeholder}
//                         </InputLabel> */}
//             <select
//               // className={classes.select}
//               value={this.props.value}
//               onChange={this.props.changed}
//               name={this.props.name}
//               // input={
//               //     <OutlinedInput
//               //         labelWidth={((this.props.elementConfig.label || this.props.elementConfig.placeholder).trim().length) * 8}
//               //         name={this.props.name}
//               //         id={this.props.name}
//               //     />
//               // }
//               onBlur={this.validation}
//               onFocus={this.validation}
//               inputProps={this.validation}
//               style={this.props.style}
//             >
//               <option value="">{this.props.elementConfig.label || this.props.elementConfig.placeholder}</option>
//               {this.props.elementConfig.options.map((option, index) => (
//                 <option key={index} value={option.value || option.rowId}>
//                   {option.displayValue}
//                 </option>
//               ))}
//             </select>
//             {this.state.errorMessage ? <FormHelperText>{this.state.errorMessage}</FormHelperText> : ''}
//           </FormControl>
//         );
//         //;
//         break;

//       case 'Multi Selection Drop Down':
//       case 'selectMultiple':
//         let validation = this.props.validation || {};
//         validation.multiple = true;
//         inputElement = ( // item xs={this.props.elementConfig.xs || 12} sm={this.props.elementConfig.sm || 12} md={this.props.elementConfig.md || 12} lg={this.props.elementConfig.lg || 12} xl={this.props.elementConfig.xl || 12}>
//           <FormControl fullWidth variant="outlined" error={this.state.errorMessage.length > 0 ? true : false}>
//             {/* <InputLabel
//                             shrink
//                             htmlFor={this.props.name}
//                             required={this.props.validation !== undefined ? this.props.validation.required : false}

//                         >
//                             {this.props.elementConfig.label || this.props.elementConfig.placeholder}
//                         </InputLabel> */}
//             <Select
//               multiple
//               native
//               value={this.props.value}
//               onChange={this.props.changed}
//               onBlur={this.validation}
//               onFocus={this.validation}
//               inputProps={this.validation}
//               name={this.props.name}
//               // input={
//               //     <OutlinedInput
//               //         // className={classes[this.props.class]|| classes.input}
//               //         notched
//               //         labelWidth={((this.props.elementConfig.label || this.props.elementConfig.placeholder).trim().length) * 9}
//               //         name={this.props.name}
//               //         id={this.props.name}
//               //         onChange={this.props.changed}
//               //         value='arrayOf'
//               //     />
//               // }
//               style={this.props.style}
//             >
//               {this.props.elementConfig.options.map((option, index) => (
//                 <option key={index} value={option.value || option.rowId}>
//                   {option.displayValue}
//                 </option>
//               ))}
//             </Select>
//             {this.state.errorMessage ? <FormHelperText>{this.state.errorMessage}</FormHelperText> : ''}
//           </FormControl>
//         );
//         //;
//         break;

//       case 'tag':
//         if (this.props.elementConfig.show) {
//           inputElement = (
//             // className={this.props.elementConfig.className} style={this.props.elementConfig.style} item xs={this.props.elementConfig.xs || 12} sm={this.props.elementConfig.sm || 12} md={this.props.elementConfig.md || 12} lg={this.props.elementConfig.lg || 12} xl={this.props.elementConfig.xl || 12}>
//             // <Typography onClick={this.props.elementConfig.onClick} variant={this.props.elementConfig.htmltag} style={this.props.style} gutterBottom>
//             //     {this.props.elementConfig.beforeDisplayValue}{this.props.elementConfig.displayValue}{this.props.elementConfig.afterDisplayValue}
//             // </Typography>
//             <></>
//             //
//           );
//         } else {
//           inputElement = '';
//         }
//         break;

//       case 'button':
//         if (this.props.elementConfig.buttonType === 'Add') {
//           inputElement =
//             // className={this.props.elementConfig.className} style={this.props.elementConfig.style} item xs={this.props.elementConfig.xs || 12} sm={this.props.elementConfig.sm || 12} md={this.props.elementConfig.md || 12} lg={this.props.elementConfig.lg || 12} xl={this.props.elementConfig.xl || 12}>
//             this.props.elementConfig.displayValue;
//         } else {
//           inputElement = '';
//         }

//         break;

//       case 'checkbox':
//       case 'Checkbox':
//         inputElement = ( // item xs={this.props.elementConfig.xs || 12} sm={this.props.elementConfig.sm || 12} md={this.props.elementConfig.md || 12} lg={this.props.elementConfig.lg || 12} xl={this.props.elementConfig.xl || 12}>
//           <FormControl component="fieldset" className={this.props.formControlClassName}>
//             {this.props.elementConfig.options.map((option, index) => {
//               return (
//                 <FormControlLabel
//                   key={index}
//                   value={option.displayValue}
//                   control={
//                     <Checkbox
//                       checked={this.props.value.indexOf(option.value || option.rowId) > -1}
//                       onChange={this.props.changed}
//                       value={option.value || option.rowId}
//                       color="default"
//                       name={this.props.name}
//                       aria-label={this.props.name}
//                       style={this.props.style}
//                     />
//                   }
//                   label={option.displayValue}
//                   labelPlacement="end"
//                 />
//               );
//             })}
//           </FormControl>
//         );
//         //
//         break;

//       case 'Radio Button':
//       case 'radio':
//         inputElement = ( // className={this.props.elementConfig.className} item xs={this.props.elementConfig.xs || 12} sm={this.props.elementConfig.sm || 12} md={this.props.elementConfig.md || 12} lg={this.props.elementConfig.lg || 12} xl={this.props.elementConfig.xl || 12}>
//           <FormControl component="fieldset" className={this.props.formControlClassName}>
//             <FormLabel component="legend">{this.props.elementConfig.label}</FormLabel>
//             {this.props.elementConfig.options.map((option, index) => {
//               return (
//                 <FormControlLabel
//                   key={index}
//                   value={option.displayValue}
//                   control={
//                     <Radio
//                       checked={this.props.value === (option.value || option.rowId)}
//                       onChange={this.props.changed}
//                       value={option.value || option.rowId}
//                       color="default"
//                       name={this.props.name}
//                       aria-label={this.props.name}
//                       style={this.props.style}
//                     />
//                   }
//                   label={option.displayValue}
//                   labelPlacement="end"
//                 />
//               );
//             })}
//           </FormControl>
//         );
//         //
//         break;

//       case 'startDate':
//         inputElement = (
//           <DatePicker
//             className={this.state.errorMessage.length > 0 ? 'danger' : 'normal'}
//             selected={this.props.value}
//             onChange={event => {
//               this.props.changed(event);
//             }}
//             onFocus={this.validation}
//             onBlur={this.validation}
//             name={this.props.name}
//             openToDate={this.props.value === null ? this.props.elementConfig.openToDate : this.props.value}
//             showMonthDropdown
//             showYearDropdown
//             isClearable
//             popperPlacement="top-end"
//             showPopperArrow={false}
//             dateFormat="dd/MM/yyyy"
//             autoComplete
//             showDisabledMonthNavigation
//             popperModifiers={{
//               offset: {
//                 enabled: true,
//                 offset: '220px, -30px',
//               },
//             }}
//             dropdownMode="select"
//             fixedHeight
//           />
//         );

//         break;

//       case 'endDate':
//         inputElement = (
//           <DatePicker
//             className={this.state.errorMessage.length > 0 ? 'danger' : 'normal'}
//             selected={this.props.value}
//             onChange={event => {
//               this.props.changed(event);
//             }}
//             onFocus={this.validation}
//             onBlur={this.validation}
//             name={this.props.name}
//             autoComplete
//             openToDate={this.props.value === null ? this.props.elementConfig.openToDate : this.props.value}
//             showMonthDropdown
//             showYearDropdown
//             showDisabledMonthNavigation
//             isClearable
//             disabled={this.props.disabled}
//             popperPlacement="top-end"
//             showPopperArrow={false}
//             dateFormat="dd/MM/yyyy"
//             minDate={this.props.minDate}
//             popperModifiers={{
//               offset: {
//                 enabled: true,
//                 offset: '220px, -30px',
//               },
//             }}
//             dropdownMode="select"
//             fixedHeight
//           />
//         );
//         break;

//       default:
//         inputElement = '';
//     }

//     return inputElement;
//   }
// }

// export default GpInput;
