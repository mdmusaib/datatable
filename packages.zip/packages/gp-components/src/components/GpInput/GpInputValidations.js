import React from 'react';

class ValidationClass extends React.Component {
  setError = error => {
    this.setState({ errorMessage: error });
  };

  validation = event => {
    if (event.target.value.length === 0) {
      event.target.className = 'danger';
      let setErrorFunction = this.setError;
      const input = document.querySelector(`${event.target.tagName}[name=${event.target.name}]`);
      if (!input.validity.valid && input.validationMessage) {
        if (input.validity.patternMismatch) {
          input.setCustomValidity('Provided input is not valid. Please provide a valid input.');
        } else {
          input.setCustomValidity('');
        }
        setErrorFunction(input.validationMessage);
      } else {
        setErrorFunction('');
      }
      return true;
    } else {
      event.target.className = 'normal';
    }
  };
}

export default ValidationClass;
