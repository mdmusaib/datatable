import React from 'react'
import { Button, GpModal, FormSample, SampleMessage } from './../../index'

class SampleModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = this.getInitialState()
    }

    getInitialState = () => {
        const initialState = {
            show: false,
            fullScreenModal: false,
            showMsg: false
        }
        return initialState
    }

    onButtonClick = (event) => {
        event.preventDefault()
        this.setState({
            show: true
        })
    }

    onButtonMsgClick = (event) => {
        event.preventDefault()
        this.setState({
            showMsg: true
        })
    }

    closeModal = (e) => {
        this.setState(this.getInitialState())
    }

    fullScreenClicked = (event) => {
        event.preventDefault()
        console.log('-----clicked')
        this.state.fullScreenModal ?
            this.setState({
                fullScreenModal: false
            })
            :
            this.setState({
                fullScreenModal: true
            })
    }

    render() {
        return (
            <>
                <Button onButtonClick={this.onButtonClick}>Click for Form</Button>
                <Button onButtonClick={this.onButtonMsgClick}>Click for Message</Button>
                <GpModal
                    FormatModal={true}
                    show={this.state.show}
                    //backdropClicked={this.closeModal}
                    title="This is for Form POP-UP"
                    closeClicked={this.closeModal}
                    fullScreen={true}
                    fullScreenClicked={this.fullScreenClicked}
                    fullScreenModal={this.state.fullScreenModal}
                    modalWidth="80%"
                    modalHeight='80%'
                >
                    <FormSample />
                </GpModal>
                <GpModal
                    FormatModal={false}
                    show={this.state.showMsg}
                    //backdropClicked={this.closeModal}
                    title="This is for MESSAGE POP-UP"
                    closeClicked={this.closeModal}
                    modalWidth="40%"
                    modalHeight='35%'
                >
                    <SampleMessage
                        message="THIS IS SAMPLE MESSAGE!!!!!"
                    />
                </GpModal>
            </>
        );
    }
}

export default SampleModal;