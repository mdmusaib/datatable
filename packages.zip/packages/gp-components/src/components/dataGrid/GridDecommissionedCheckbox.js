import React, { Component } from 'react';

class GridDecommissionedCheckbox extends Component {
  render() {
    return <input type="checkbox" disabled checked={this.props.data.decomission} />;
  }
}

export default GridDecommissionedCheckbox;
