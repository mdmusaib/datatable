import React, { Component, Fragment } from 'react';
import Button from '../button/Button';
import { dataGrid as gridDataStyle } from '../../tokens/components';
import { StyledElement } from '../utils/element';
import Icon from './../icons/Icon';
import Reports from './../reports/Reports';
import ExportToExcel from './../exportToExcel/ExportToExcel';

let GridButtonStyle = StyledElement('div')(gridDataStyle.basicGrid.gridButtonStyle);
let GridButtonContainer = StyledElement('div')(gridDataStyle.basicGrid.gridButtonContainer);
let DropdownContent = StyledElement('div')(gridDataStyle.basicGrid.showHideDropdownContent);
let DropdownContentLayout = StyledElement('div')(gridDataStyle.basicGrid.showHideDropdownLayout);
let DropdownContentStyle = StyledElement('div')(gridDataStyle.basicGrid.showHideDropdownContentStyle);
let GridButtonParentStyle = StyledElement('div')(gridDataStyle.basicGrid.gridButtonParentStyle);
let GridRowCountStyle = StyledElement('div')(gridDataStyle.basicGrid.gridRowCountStyle);
let GridTitle = StyledElement('div')(gridDataStyle.basicGrid.gridTitle);
let GridRowCount = StyledElement('div')(gridDataStyle.basicGrid.gridCount);
let QuickLookStyle = StyledElement('div')(gridDataStyle.basicGrid.quickLookStyle);
let DropdownContainer = StyledElement('div')(gridDataStyle.basicGrid.dropdownContainer);
let ColumnSearchStyle = StyledElement('input')(gridDataStyle.basicGrid.columnSearchStyle);

class GridButton extends Component {
  constructor(props) {
    super(props);
    this.saveConfigData = {};
    this.checkedCols = [];
    this.state = {
      checkedCols: this.checkedCols, //This is for maintaining show hide column data
      showHideColumnData: [],
      columnInfo: {},
      openDropdown: false,
      columnChecked: false,
    };
  }

  showHideDropdownContent = () => {
    let saveConfigData = JSON.parse(localStorage.getItem('columnProperties'));
    if (!saveConfigData) {
      this.checkedCols = this.props.columnProperties.map(key => {
        return key.headerName;
      });
    } else {
      this.checkedCols = saveConfigData.map(key => {
        return key.headerName;
      });
    }
    this.setState({ checkedCols: this.checkedCols, openDropdown: !this.state.openDropdown });
  };

  onClick = (e, key) => {
    let colKey = key;
    let isColumnPresent = this.checkedCols.includes(colKey);
    if (!isColumnPresent) {
      this.checkedCols.push(colKey);
      let columnInfoObj = this.props.columnData.filter(col => {
        return col.headerName === colKey;
      });
      this.props.columnProperties.push(columnInfoObj[0]);
    } else {
      let columnIndex = this.props.columnProperties.findIndex(col => {
        return col.headerName === colKey;
      });
      this.checkedCols.splice(columnIndex, 1);
      const filteredColumn = this.props.columnProperties;
      filteredColumn.splice(columnIndex, 1);
      const columnInfoObj = {
        ...this.state.columnInfo,
        [colKey]: filteredColumn[0],
      };
      this.setState({
        columnData: this.state.columnData,
        columnInfo: columnInfoObj,
      });
    }
    this.props.gridApi.setColumnDefs(this.props.columnProperties);
    this.setState({ checkedCols: this.checkedCols }); //Here I restored the latest update data of show hide column
  };

  saveConfig = () => {
    const columnProperties = this.props.columnProperties;
    columnProperties.shift();
    columnProperties.map(col => {
      if (this.props.columnSizeInfo[col.field].width === 'Auto') {
        this.saveConfigData[col.field] = `${col.field} | -1 | false`;
      } else {
        this.saveConfigData[col.field] = `${col.field} | ${this.props.columnSizeInfo[col.field].width} | false`;
      }
    });
    columnProperties.unshift({
      headerCheckboxSelection: true,
      checkboxSelection: true,
      width: 32,
      pinned: 'left',
      resizable: false,
      suppressMenu: false,
      visible: 'true',
    });
    localStorage.setItem('columnProperties', JSON.stringify(this.props.columnProperties));
  };

  refreshGrid = () => {
    this.props.gridApi.setSortModel(null);
    this.props.gridApi.setRowData(this.props.rowData);
  };

  onResetToDefaultConfig = () => {
    this.props.gridColumnApi.resetColumnState();
    const allColumnIds = [];
    this.props.gridColumnApi.getAllColumns().forEach(column => {
      allColumnIds.push(column.colId);
    });
    this.props.gridColumnApi.autoSizeColumns(allColumnIds, true);
    this.props.resetToDefaultGrid();
    localStorage.clear();
  };

  hide = e => {
    if (e && e.relatedTarget) {
      e.relatedTarget.click();
    }
    this.setState({ openDropdown: false });
  };

  handleChange = () => {
    this.setState({ openDropdown: false });
  };

  displayDropdown = () => {
    this.setState({ openDropdown: !this.state.openDropdown });
  };

  render() {
    let rowData = this.props.rowData ? this.props.rowData : [];
    return (
      <GridButtonParentStyle>
        <GridRowCountStyle>
          {this.props.gridData.recordCount.show === 'true' ? (
            rowData.length > 0 ? (
              <Fragment>
                <GridTitle>{this.props.gridData.recordCount.title}</GridTitle>
                <GridTitle> &nbsp; Record</GridTitle>
                <GridRowCount>
                  &nbsp; {this.props.gridRowCount} to {this.props.lastDisplayedRow} of {rowData.length}
                </GridRowCount>
              </Fragment>
            ) : (
              <GridTitle>No Records Found</GridTitle>
            )
          ) : (
            <Fragment />
          )}
          <QuickLookStyle>
            {this.props.hideQuickLook || this.props.gridData.lookup.show === 'false' ? null : (
              <ColumnSearchStyle type="text" placeholder="All Column Search" />
            )}
          </QuickLookStyle>
        </GridRowCountStyle>
        <GridButtonContainer>
          {this.props.buttonLabel.map(label => {
            switch (label.title) {
              case 'Refresh':
                if (this.props.gridData.refresh.show === 'true') {
                  return (
                    <GridButtonStyle onClick={this.refreshGrid} title="Refresh">
                      <Icon icon="refresh" type="svg" width="20" height="20" title="Refresh" />
                    </GridButtonStyle>
                  );
                }
                break;
              case 'Clear Filter':
                if (this.props.gridData.clearFilter.show === 'true') {
                  return (
                    <GridButtonStyle onClick={this.props.clearFilter} title="Clear Filter">
                      <Icon icon="clearFilter" type="svg" width="20" height="20" title="Clear Filter" />
                    </GridButtonStyle>
                  );
                }
                break;
              // case 'Save Config':
              //   if (this.props.hideGridButtons) {
              //     return null;
              //   } else {
              //     if (this.props.gridData.config.show === 'true') {
              //       return (
              //         <GridButtonStyle onClick={this.saveConfig}>
              //           <div>
              //             <Icon icon="gridIcons.save_icon" />
              //           </div>
              //         </GridButtonStyle>
              //       );
              //     }
              //   }
              //   break;
              // case 'Reset to Default config':
              //   if (this.props.hideGridButtons) {
              //     return null;
              //   } else {
              //     if (this.props.gridData.config.show === 'true') {
              //       return (
              //         <GridButtonStyle onClick={this.onResetToDefaultConfig.bind(this)}>
              //           <div>
              //             <Icon icon="gridIcons.setAsDefault_icon" />
              //           </div>
              //         </GridButtonStyle>
              //       );
              //     }
              //   }
              //   break;
              case 'Reports':
                if (this.props.hideReportBtn) {
                  return null;
                } else {
                  if (this.props.gridData.reports.show === 'true') {
                    return (
                      <GridButtonStyle>
                        <Reports />
                      </GridButtonStyle>
                    );
                  }
                }
                break;
              case 'Export To Excel':
                if (this.props.hideExportToExcelBtn) {
                  return null;
                } else {
                  if (this.props.gridData.exportToExcel.show === 'true') {
                    return (
                      <GridButtonStyle>
                        <ExportToExcel />
                      </GridButtonStyle>
                    );
                  }
                }
                break;
              case 'Show/ Hide Columns':
                if (this.props.hideShowHideColumnButton) {
                  return null;
                } else {
                  if (this.props.gridData.hideShowColumns.show === 'true') {
                    return (
                      <GridButtonStyle
                        openDropdown={this.state.openDropdown}
                        onClick={this.showHideDropdownContent}
                        onBlur={this.hide}
                        tabIndex="1"
                      >
                        <div
                          onFocus={() => {
                            this.setState({ openDropdown: true });
                          }}
                          style={{ outline: 'none' }}
                          title="Show Hide Columns"
                        >
                          <Icon icon="gear" type="svg" width="20" height="20" title="Show Hide Columns" />
                        </div>
                        {this.state.openDropdown ? (
                          <DropdownContainer>
                            <DropdownContent>
                              {this.props.columnKey.map((name, index) => (
                                <DropdownContentLayout>
                                  <DropdownContentStyle disabled={name.disabled === 'true' ? true : false}>
                                    <div
                                      style={{ width: '100%', height: '100%', cursor: 'pointer' }}
                                      onClick={e => (name.disabled === 'true' ? null : this.onClick(e, name.title))}
                                    >
                                      <input
                                        type="checkbox"
                                        readOnly
                                        onClick={e => {
                                          e.stopPropagation();
                                          this.onClick(e, name.title);
                                        }}
                                        onMouseDown={e => e.preventDefault()}
                                        disabled={name.disabled === 'true' ? true : false}
                                        checked={this.state.checkedCols.some(col => col === name.title)}
                                      />
                                      <span
                                        onClick={e => {
                                          if (name.disabled === 'true') {
                                            e.stopPropagation();
                                          } else {
                                            e.stopPropagation();
                                            this.onClick(e, name.title);
                                          }
                                        }}
                                      >
                                        {name.title}
                                      </span>
                                    </div>
                                  </DropdownContentStyle>
                                </DropdownContentLayout>
                              ))}
                            </DropdownContent>
                          </DropdownContainer>
                        ) : null}
                        {/* </div> */}
                      </GridButtonStyle>
                    );
                  }
                }
                break;
              default:
                break;
            }
          })}
        </GridButtonContainer>
      </GridButtonParentStyle>
    );
  }
}

export default GridButton;
