import React, { Component, Fragment } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { dataGrid as gridDataStyle } from '../../tokens/components';
import { StyledElement } from '../utils/element';
import GridHeader from './GridHeader';
import GridFilter from './GridFilter';
import GridColumnCheckbox from './GridColumnCheckbox';
import GridButton from './GridButton';
import SavedView from './savedView/SavedView';
import PropTypes from 'prop-types';
import Icon from './../icons/Icon';

let GridContainerStyle = StyledElement('div')(gridDataStyle.basicGrid.gridContainer);
let DataGridStyle = StyledElement('div')(gridDataStyle.basicGrid);
let GridOuterLayout = StyledElement('div')(gridDataStyle.basicGrid.gridOuterBox);
let GridButtonStyle = StyledElement('div')(gridDataStyle.basicGrid.gridButtonBackground);
let GridStyle = StyledElement('div')(gridDataStyle.basicGrid.gridStyle);

class DataGrid extends Component {
  constructor(props) {
    super(props);
    this.dataField = [];
    this.columnDefs = [];
    this.columnSizeInfo = {};
    this.columnKey = [];
    this.ascSort = 'inactive';
    this.gridRowData = [];
    this.columnId = {};
    this.columnProperties = [];
    this.defaultColData = null;
    this.movedColumnProperties = null;
    this.pinnedColumns = {};
    this.state = {
      filterInputValuesArray: [],
      refreshGrid: null,
      columnDragged: false,
      showSortSymbol: false,
      value: '',
      columnId: {},
      setDefault: false,
      descSort: 'inactive',
      width: '',
      rowSelected: false,
      selected: false,
      rowBuffer: 0,
      defaultColDef: {
        resizable: true,
        filter: true,
        filterParams: {
          rowData: this.props.rowData,
        },
        sortable: true,
        menuTabs: ['filterMenuTab'],
      },
      frameworkComponents: {
        agGridFilter: GridFilter,
      },
      rowModelType: 'infinite',
      headerHeight: 30,
      rowHeight: 25,
      paginationPageSize: 100,
      maxBlocksInCache: 2,
      navigationOfNextCell: 'multiple', // This state is used for the navigation of the selected row
      gridApi: {},
      gridRowCount: this.props.rowData ? 1 : 0,
      // rowBuffer: 0,
      lastDisplayedRow: this.props.rowData ? 1 : 0,
      filterActive: false,
      buttonLabels: [
        {
          title: 'Refresh',
        },
        {
          title: 'Clear Filter',
        },
        {
          title: 'Reports',
        },
        {
          title: 'Export To Excel',
        },
        {
          title: 'Show/ Hide Columns',
        },
      ],
    };
  }

  generateGridColDef = () => {
    this.gridJsonData = [...this.props.gridData.columns];

    this.columnKey = this.gridJsonData.map(key => {
      return {
        title: key.title,
        field: key.dataField,
        visible: key.visible,
        disabled: key.disabled,
      };
    });
    this.columnDefs = this.gridJsonData.map((data, index) => {
      if (this.columnSizeInfo[data.dataField]) data.width = this.columnSizeInfo[data.dataField].width;
      if (this.pinnedColumns[data.dataField]) {
        data['pinned'] = this.pinnedColumns[data.dataField].pinned;
        data['lockPosition'] = this.pinnedColumns[data.dataField].lockPosition;
      } else {
        data['pinned'] = null;
        data['lockPosition'] = false;
      }
      let width = data.width === 'Auto' ? 170 : Number(data.width);
      if (data.dataType === 'CheckBox') {
        return {
          headerName: data.title,
          field: data.dataField,
          width: width,
          pinned: data.pinned,
          filter: 'agGridFilter',
          lockPosition: data.lockPosition,
          headerComponentFramework: GridHeader,
          headerComponentParams: {
            dataField: this.dataField,
            showSortBtn: this.showSortBtn,
            ascSort: this.state.ascSort,
            columnKey: this.columnKey,
            onFilterInputChange: this.onFilterInputChange,
            columnId: this.state.columnId,
            filteredColumn: this.props.filteredColumn,
            onFilterInputValues: this.onFilterInputValues,
            gridData: this.props.gridData,
            renderFilterMenu: this.renderFilterMenu,
            pinnedColumns: this.pinnedColumns,
            onColumnPin: this.onColumnPin,
            rowData: this.props.rowData,
            onRadioInputFilter: this.onRadioInputFilter,
          },
          visible: data.visible,
          cellRendererFramework: GridColumnCheckbox,
          cellRendererParams: {},
          type: data.dataType,
          sortingOrder: ['desc', 'asc'],
        };
      } else {
        return {
          headerName: data.title,
          field: data.dataField,
          width: width,
          pinned: data.pinned,
          filter: 'agGridFilter',
          lockPosition: data.lockPosition,
          headerComponentFramework: GridHeader,
          visible: data.visible,
          headerComponentParams: {
            dataField: this.dataField,
            showSortBtn: this.showSortBtn,
            ascSort: this.ascSort,
            columnKey: this.columnKey,
            onFilterInputChange: this.onFilterInputChange,
            columnId: this.state.columnId,
            filteredColumn: this.props.filteredColumn,
            onFilterInputValues: this.onFilterInputValues,
            gridData: this.props.gridData,
            renderFilterMenu: this.renderFilterMenu,
            pinnedColumns: this.pinnedColumns,
            onColumnPin: this.onColumnPin,
            selected: this.state.selected,
            onRadioInputFilter: this.onRadioInputFilter,
            onDateFilter: this.onDateFilter,
          },
          type: data.dataType,
          sortingOrder: ['desc', 'asc'],
        };
      }
    });
    if (this.props.enableMultiSelect) {
      this.columnDefs.unshift({
        headerCheckboxSelection: true,
        checkboxSelection: function(params) {
          return JSON.stringify(params.node.data) !== JSON.stringify({});
        },
        pinned: 'left',
        width: 30,
        lockPosition: true,
        visible: 'true',
      });
    }
    this.renderGrid();
  };

  renderGrid = () => {
    let saveConfigData = JSON.parse(localStorage.getItem('columnProperties'));
    if (saveConfigData) {
      let columnHeaderName = saveConfigData.map(data => {
        return data.headerName;
      });
      this.columnProperties = this.columnDefs.filter(col => {
        return columnHeaderName.includes(col.headerName);
      });
    } else if (this.movedColumnProperties) {
      this.columnProperties = this.movedColumnProperties.map((col, index) => {
        let colIndex = this.columnDefs.findIndex(defs => defs.headerName === col.headerName);
        col.width = this.columnDefs[colIndex].width;
        col.lockPosition = this.columnDefs[colIndex].lockPosition;
        col.pinned = this.columnDefs[colIndex].pinned;
        return col;
      });
    } else {
      this.columnProperties = this.columnDefs.filter(col => col.visible === 'true');
    }
    this.setState({ refreshGrid: !this.state.refreshGrid });
  };

  resetToDefaultGrid = () => {
    this.defaultColData.map(colInfo => {
      this.columnSizeInfo[colInfo.dataField] = { width: colInfo.width };
    });
    this.movedColumnProperties = null;
    this.generateGridColDef();
    this.gridApi.setColumnDefs(this.columnProperties);
  };

  onFilterInputChange = (event, columnId) => {
    if (event.key === 'Enter') {
      if (event.target.value && event.target.value !== 'none') {
        this.columnId = {
          ...this.columnId,
          [columnId]: columnId,
        };
        console.log(this.columnId, 'iletrrr');
        this.setState({ columnId: this.columnId }, () => {
          this.generateGridColDef();
          this.gridApi.refreshHeader();
        });
      } else {
        delete this.columnId[columnId];
        this.setState({ columnId: {} }, () => {
          // this.generateGridColDef();
          let columnInfo = this.gridColumnApi
            .getAllColumns()
            .filter(data => data.userProvidedColDef.field === columnId);
          columnInfo[0].userProvidedColDef.headerComponentParams.columnId = {};
          this.gridApi.refreshHeader();
        });
      }
    }
  };

  onFilterInputValues = (title, field, value) => {
    if (value && value !== 'none') {
      this.columnId = {
        ...this.columnId,
        [field]: field,
      };
      this.setState({ columnId: this.columnId }, () => {
        let columnInfo = this.gridColumnApi.getAllColumns().filter(data => data.userProvidedColDef.field === field);
        columnInfo[0].userProvidedColDef.headerComponentParams.columnId = this.columnId;
        this.gridApi.refreshHeader();
      });
    } else {
      delete this.columnId[field];
      this.setState({ columnId: {} }, () => {
        this.gridApi.refreshHeader();
      });
    }
    //this.state.filterInputValuesArray.push(value);
  };

  onRadioInputFilter = (title, field, value) => {
    if (value && value !== 'none') {
      this.columnId = {
        ...this.columnId,
        [field]: field,
      };
      this.setState({ columnId: this.columnId }, () => {
        let columnInfo = this.gridColumnApi.getAllColumns().filter(data => data.userProvidedColDef.field === field);
        columnInfo[0].userProvidedColDef.headerComponentParams.columnId = this.columnId;
        this.gridApi.refreshHeader();
      });

      let rowDefs = [...this.props.rowData];
      switch (value) {
        case 'yes':
          let filteredData = rowDefs.filter(row => row[field] === true);
          this.gridApi.setRowData(filteredData);
          break;
        case 'no':
          let notSelectedData = rowDefs.filter(row => row[field] === false || row[field] === '');
          this.gridApi.setRowData(notSelectedData);
          break;
        default:
      }
    } else {
      delete this.columnId[field];
      this.setState({ columnId: {} }, () => {
        this.gridApi.setRowData(this.props.rowData);
        this.gridApi.refreshHeader();
      });
    }
    //this.state.filterInputValuesArray.push(value);
  };

  onDateFilter = (title, field, userInput, date, date1) => {
    console.log(date, date1);
    if (date || date1) {
      this.columnId = {
        ...this.columnId,
        [field]: field,
      };
      this.setState({ columnId: this.columnId }, () => {
        let columnInfo = this.gridColumnApi.getAllColumns().filter(data => data.userProvidedColDef.field === field);
        columnInfo[0].userProvidedColDef.headerComponentParams.columnId = this.columnId;
        this.gridApi.refreshHeader();
      });

      let rowDefs = [...this.props.rowData];
      switch (userInput) {
        case 'dateGreaterThanValue':
          console.log('date', date);
          let filteredData = rowDefs.filter(row => Date.parse(row[field]) > Date.parse(date));
          this.gridApi.setRowData(filteredData);
          break;
        case 'dateLesserThanValue':
          let notSelectedData = rowDefs.filter(row => Date.parse(row[field]) < Date.parse(date));
          this.gridApi.setRowData(notSelectedData);
          break;
        case 'dateEqualsValue':
          let equalData = rowDefs.filter(row => Date.parse(row[field]) === Date.parse(date));
          this.gridApi.setRowData(equalData);
          break;
        default:
      }
    } else {
      delete this.columnId[field];
      this.setState({ columnId: {} }, () => {
        this.gridApi.setRowData(this.props.rowData);
        this.gridApi.refreshHeader();
      });
    }
  };

  clearFilter = () => {
    this.setState({ columnId: {} }, () => {
      this.gridColumnApi.getAllColumns().map(col => {
        if (col.userProvidedColDef.headerComponentParams) {
          col.userProvidedColDef.headerComponentParams.columnId = {};
        }
      });
      this.columnId = {};
      this.gridApi.refreshHeader();
      // this.generateGridColDef();
      this.gridApi.setRowData(this.props.rowData);
      this.gridApi.setColumnDefs(this.columnProperties);
    });
    this.gridApi.setFilterModel(null);
  };

  componentDidMount = () => {
    this.defaultColData = JSON.parse(JSON.stringify(this.props.gridData.columns));
    this.generateGridColDef();
  };

  componentDidUpdate(prevProps) {
    if (this.props.gridReRenderToogle !== prevProps.gridReRenderToogle) {
      this.defaultColData = JSON.parse(JSON.stringify(this.props.gridData.columns));
      this.generateGridColDef();
      let lastRow = this.props.rowData.length < 17 ? this.props.rowData.length : this.gridApi.getLastDisplayedRow();
      this.setState({ lastDisplayedRow: lastRow > 0 ? lastRow : this.state.lastDisplayedRow });
    }
    if (this.gridApi) {
      let rowDefs = [...this.props.rowData];
      if (rowDefs.length > 0 && rowDefs.length < 9) {
        for (let i = 0; i < 17; i++) {
          rowDefs.push({});
        }
        this.gridApi.setRowData(rowDefs);
      } else if (rowDefs && rowDefs.length < 17) {
        for (let i = 0; i < 3; i++) {
          rowDefs.push({});
        }
        this.gridApi.setRowData(rowDefs);
      }
    }

    if (prevProps.rowData.length > 0 && prevProps.rowData.length !== this.props.rowData.length) {
      this.gridApi.setRowData(this.props.rowData);
    }
  }

  onGridReady = params => {
    this.gridApi = params.api;
    this.gridApi.hideOverlay();
    this.gridColumnApi = params.columnApi;
    this.setState({ gridApi: this.gridApi });
    if (!this.props.rowData) {
      let columnHeaderDefs = this.columnDefs;
      columnHeaderDefs.shift();
      let rowDataObj = {};
      columnHeaderDefs.map(colDef => {
        rowDataObj = {
          ...rowDataObj,
          [colDef.field]: '',
        };
      });
      let arr = [];
      for (let i = 0; i < 20; i++) {
        arr.push(rowDataObj);
        this.gridRowData = arr;
      }
    }
    this.gridJsonData.map(colInfo => {
      this.columnSizeInfo[colInfo.dataField] = { width: colInfo.width };
    });
    let lastRow = this.props.rowData.length < 17 ? this.props.rowData.length : this.gridApi.getLastDisplayedRow();
    this.setState({ lastDisplayedRow: lastRow > 0 ? lastRow : this.state.lastDisplayedRow });
  };

  onGridScroll = event => {
    if (event.target.scrollLeft > 0) {
    } else if (event.target.scrollTop >= 0 && this.props.rowData.length > 17) {
      let lastRow = this.gridRowData.length > 0 ? 0 : this.gridApi.getLastDisplayedRow();
      let firstRow = this.gridApi.getFirstDisplayedRow();
      if (this.props.rowData && lastRow === this.props.rowData.length - 1) {
        this.setState({ lastDisplayedRow: this.props.rowData.length });
      } else {
        if (firstRow === 0) {
          firstRow = firstRow + 1;
        }
        this.setState({ gridRowCount: this.gridRowData.length > 0 ? 0 : firstRow, lastDisplayedRow: lastRow });
      }
    }
  };

  onSelectionChanged = params => {
    var selectedRows = this.gridApi.getSelectedRows();
    if (selectedRows.length === this.props.rowData.length) {
      this.setState({ rowSelected: true });
    } else {
      this.setState({ rowSelected: false, selected: true });
    }
    this.setState({ gridApi: this.gridApi });
  };

  navigateToNextCell = params => {
    var previousCell = params.previousCellPosition;
    var suggestedNextCell = params.nextCellPosition;

    var KEY_UP = 38;
    var KEY_DOWN = 40;
    var KEY_LEFT = 37;
    var KEY_RIGHT = 39;

    switch (params.key) {
      case KEY_DOWN:
        this.setState({ navigationOfNextCell: 'single' });
        previousCell = params.previousCellPosition;
        // set selected cell on current cell + 1
        this.gridApi.forEachNode(function(node) {
          if (previousCell.rowIndex + 1 === node.rowIndex) {
            node.setSelected(true);
          }
        });
        this.setState({ navigationOfNextCell: 'multiple' });
        return suggestedNextCell;

      case KEY_UP:
        this.setState({ navigationOfNextCell: 'single' });
        previousCell = params.previousCellPosition;
        // set selected cell on current cell - 1
        this.gridApi.forEachNode(function(node) {
          if (previousCell.rowIndex - 1 === node.rowIndex) {
            node.setSelected(true);
          }
        });
        this.setState({ navigationOfNextCell: 'multiple' });
        return suggestedNextCell;

      case KEY_LEFT:
        break;

      case KEY_RIGHT:
        return suggestedNextCell;

      default:
      //throw 'this will never happen, navigation is always one of the 4 keys above';
    }
  };

  onColumnResized = resizeInfo => {
    if (resizeInfo.column) {
      this.columnSizeInfo[resizeInfo.column.colDef.field].width = resizeInfo.column.actualWidth;
    }
    this.setState({ refreshGrid: !this.state.refreshGrid });
    if (resizeInfo.finished) {
      this.gridApi.setColumnDefs([]);
      this.generateGridColDef();
      if (this.movedColumnProperties) {
        this.gridApi.setColumnDefs(this.movedColumnProperties);
      } else {
        this.gridApi.setColumnDefs(this.columnProperties);
      }
    }
  };

  onColumnMoved = movedColumnInfo => {
    this.movedColumnProperties = [...this.columnProperties];
    let oldIndex = this.movedColumnProperties.findIndex(
      col => col.headerName === movedColumnInfo.column.colDef.headerName,
    );
    let newIndex = movedColumnInfo.toIndex;
    let splicedArr = this.movedColumnProperties.splice(oldIndex, 1)[0];
    this.movedColumnProperties.splice(newIndex, 0, splicedArr);
  };

  onColumnPin = (field, pinnedValue) => {
    this.pinnedColumns = {
      ...this.pinnedColumns,
      [field]: {
        pinned: pinnedValue === 'left' ? 'left' : null,
        lockPosition: pinnedValue === 'left' ? true : false,
      },
    };
    this.gridColumnApi.setColumnPinned(field, pinnedValue);
    pinnedValue !== 'left' && delete this.pinnedColumns[field];
    let columnInfo = this.gridColumnApi.getAllColumns().filter(data => data.userProvidedColDef.field === field);
    columnInfo[0].userProvidedColDef.headerComponentParams.pinnedColumns = this.pinnedColumns;
    this.gridApi.setColumnDefs([]);
    this.generateGridColDef();
    this.gridApi.setColumnDefs(this.columnProperties);
  };

  showSortBtn = fieldName => {
    if (this.dataField.length > 0) {
      this.dataField.pop();
      this.dataField.push(fieldName);
      this.ascSort = this.ascSort === 'active' ? 'inactive' : 'active';
      let columnData = this.gridColumnApi
        .getAllColumns()
        .filter(data => data.userProvidedColDef.headerName === fieldName);
      columnData[0].userProvidedColDef.headerComponentParams.ascSort = this.ascSort;
      this.gridApi.refreshHeader();
    } else {
      this.dataField.push(fieldName);
      this.gridApi.refreshHeader();
    }
    this.setState({ refreshGrid: !this.state.refreshGrid });
  };

  onRowClicked = event => {
    if (event.node.isSelected()) {
      event.node.setSelected(true, false);
    } else {
      event.node.setSelected(true);
    }
  };

  render() {
    return (
      <Fragment>
        <GridContainerStyle>
          <GridOuterLayout>
            {this.props.hideTopPanel || this.props.gridData.views.show === 'false' ? (
              <Fragment />
            ) : (
              <SavedView
                onAddClick={e => this.props.onAddClick()}
                onPartsUsageClick={e => this.props.onPartsUsageClick()}
              />
            )}
            <GridButtonStyle>
              <GridButton
                columnData={this.columnDefs}
                buttonLabel={this.state.buttonLabels} //grid button labels
                gridApi={this.gridApi}
                columnKey={this.columnKey}
                gridData={this.props.gridData} //grid json data
                rowData={this.props.rowData}
                columnSizeInfo={this.columnSizeInfo} //width info of each column
                gridColumnApi={this.gridColumnApi}
                hideShowHideColumnButton={this.props.hideShowHideColumnButton}
                gridRowCount={this.state.gridRowCount}
                lastDisplayedRow={this.state.lastDisplayedRow}
                columnProperties={this.columnProperties}
                clearFilter={this.clearFilter}
                resetToDefaultGrid={this.resetToDefaultGrid}
                hideQuickLook={this.props.hideQuickLook}
                hideReportBtn={this.props.hideReportBtn}
                hideExportToExcelBtn={this.props.hideExportToExcelBtn}
              />
            </GridButtonStyle>
            <GridStyle
              inModalHeight={this.props.inModalHeight}
              pinnedColumns={Object.keys(this.pinnedColumns).length}
              rowSelected={this.state.rowSelected}
              selected={this.state.selected}
              onScroll={this.onGridScroll}
            >
              <DataGridStyle className="ag-theme-balham">
                <AgGridReact
                  columnDefs={this.columnProperties}
                  rowData={this.gridRowData.length > 0 ? this.gridRowData : this.props.rowData}
                  defaultColDef={this.state.defaultColDef}
                  frameworkComponents={this.state.frameworkComponents}
                  rowSelection={this.state.navigationOfNextCell}
                  onGridReady={this.onGridReady} // This is for fetching grid API
                  navigateToNextCell={this.navigateToNextCell} //This is for navigation of row after selection
                  //onSelectionChanged={this.onSelectionChanged.bind(this)} // This is for getting selected rows
                  rowHeight={this.state.rowHeight}
                  onColumnResized={this.onColumnResized.bind(this)} // This is for column row auto height
                  enableSorting={true}
                  onColumnPinned={this.onColumnPinned}
                  rowBuffer={this.state.rowBuffer}
                  onColumnMoved={this.onColumnMoved}
                  suppressDragLeaveHidesColumns={true}
                  headerHeight={this.state.headerHeight}
                  onDragStopped={this.onDragStopped}
                  suppressNoRowsOverlay={true}
                  onRowClicked={this.onRowClicked}
                ></AgGridReact>
              </DataGridStyle>
            </GridStyle>
          </GridOuterLayout>
        </GridContainerStyle>
      </Fragment>
    );
  }
}

DataGrid.propTypes = {
  /**
   *This to indicate if the checkbox should be present or not in the grid
   */
  enableMultiSelect: PropTypes.bool,
  /**
   *Whether the top panel containing saved views and button panel should be hidden or not
   */
  hideTopPanel: PropTypes.bool,
  /**
   *Hide specific grid buttons based on the popup
   */
  hideGridButtons: PropTypes.bool,
  /**
   *Hiding grid footer
   */
  hideGridFooter: PropTypes.bool,
  /**
   *To show only report button on the footer
   */
  showFooterReportButton: PropTypes.bool,
  /**
   *To show only export to excel button on the footer
   */
  showFooterExportToExcelButton: PropTypes.bool,
  filteredColumn: PropTypes.string,
};

DataGrid.defaultProps = {
  enableMultiSelect: false,
  hideTopPanel: false,
  hideGridButtons: false,
  hideGridFooter: false,
  showFooterReportButton: false,
  showFooterExportToExcelButton: false,
};

export default DataGrid;
