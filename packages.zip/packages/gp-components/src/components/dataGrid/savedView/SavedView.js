import React, { Component, Fragment } from 'react';
import { Modal } from 'react-bootstrap';
//import 'bootstrap/dist/css/bootstrap.min.css';
import { StyledElement } from '../../utils/element';
import { dataGrid as gridDataStyle } from '../../../tokens/components';
import Icon from '../../icons/Icon';
import ButtonPanel from './../ButtonPanel';
import { Button, GpModal, SampleMessageWithInput, Inputs } from './../../../index';

const SavedViewParentStyle = StyledElement('div')(gridDataStyle.basicGrid.savedViewParentStyle);
const SavedViewSelectStyle = StyledElement('div')(gridDataStyle.basicGrid.savedViewSelectStyle);
const SavedViewOptionStyle = StyledElement('div')(gridDataStyle.basicGrid.savedViewOptionStyle);
const SavedViewIconsStyle = StyledElement('div')(gridDataStyle.basicGrid.savedViewIconsStyle);
const SavedViewBtn = StyledElement('div')(gridDataStyle.basicGrid.savedViewBtnStyle);
const SavedViewContainer = StyledElement('div')(gridDataStyle.basicGrid.savedViewContainer);
const SavedViewLabelStyle = StyledElement('label')(gridDataStyle.basicGrid.savedViewLabelStyle);
let DropdownContainer = StyledElement('div')(gridDataStyle.basicGrid.dropdownContainer);
let SavedViewContentLayout = StyledElement('div')(gridDataStyle.basicGrid.savedViewContentLayout);
let SavedViewInputStyle = StyledElement('div')(gridDataStyle.basicGrid.savedViewInputStyle);
let SavedViewContentStyle = StyledElement('div')(gridDataStyle.basicGrid.savedViewContentStyle);
let DropdownIcon = StyledElement('div')(gridDataStyle.basicGrid.dropdownIcon);
let SavedViewDataStyle = StyledElement('label')(gridDataStyle.basicGrid.savedViewDataStyle);

class SavedView extends Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      show: false, //This is for modal
      saveViewArray: [], //This is for save view Array
      openSavedViewDropdown: false,
      display: 'none',
      saveViewForm: {
        viewName: {
          elementType: 'InputField',
          elementConfig: {
            inputType: 'name',
            placeholder: 'View Name',
            widthNoMargin: '70%',
            type: 'text',
          },
          value: '',
          valid: false,
          touched: false,
          validation: {
            required: true,
            pattern: /^[a-zA-Z&0-9]*$/,
            message: 'Please Enter',
          },
        },
      },
      formIsValid: false,
    };
    return initialState;
  };

  //This is for handling modal
  handleShow = () => {
    this.setState({ show: true });
  };

  handleClose = () => {
    this.setState({ show: false });
  };

  modalChange = e => {
    this.setState({ saveViewValue: e.target.value });
  };

  //save button of modal
  handleSaveOfSaveView = () => {
    let saveValue = this.state.saveViewForm;
    if (saveValue !== '') {
      this.state.saveViewArray.push(saveValue.viewName.value);
      this.setState({ saveViewArray: this.state.saveViewArray, show: false });
    }
    this.setState({ show: false });
  };

  //Delete save view
  deleteSaveView = () => {
    let deletedData = [];
    deletedData = this.state.saveViewArray.filter(data => data !== this.state.saveViewData);
    this.setState({ saveViewArray: deletedData, saveViewData: '' });
  };

  //Dropdown filter
  savedViewDropDown = () => {
    this.setState({ openSavedViewDropdown: !this.state.openSavedViewDropdown });
  };

  onDataSelected = data => {
    this.setState({ saveViewData: data });
  };

  inputChangeHandler = (event, userInputIdentifier, formState) => {
    let currentState = this.state;
    const updatedForm = {
      ...this.state[formState],
    };

    const updatedFormElement = {
      ...updatedForm[userInputIdentifier],
    };

    if (updatedFormElement.elementType === 'MultiSelectDropdown') {
      // let data=userInputIdentifier.value.indexOf(event.target.value);
      let index = '';
      if ((index = updatedFormElement.value.indexOf(event.target.value)) === -1) {
        updatedFormElement.value.push(event.target.value);
      } else {
        updatedFormElement.value.splice(index, 1);
      }
    } else {
      updatedFormElement.value = event.target.value;
    }

    updatedFormElement.valid = this.checkValidity(
      updatedFormElement.value,
      updatedFormElement.validation,
      updatedFormElement.elementConfig,
    );
    updatedFormElement.touched = true;
    updatedForm[userInputIdentifier] = updatedFormElement;

    let formIsValid = true;
    let formElements = updatedForm;
    for (let userInputIdentifier in formElements) {
      if (
        formElements[userInputIdentifier].value !== undefined &&
        formElements[userInputIdentifier].validation.required
      ) {
        formIsValid = formElements[userInputIdentifier].valid && formIsValid;
      }
    }
    currentState[formState] = updatedForm;
    currentState.formIsValid = formIsValid;

    // console.log('------', currentState)
    this.setState(currentState);
  };

  checkValidity(value, rules, elementConfig) {
    let isValid = false;
    if (value === '') {
      isValid = false;
    } else if (rules.required === true && elementConfig.type === 'text') {
      // console.log('inside if');

      if (typeof value === 'string') {
        // console.log('inside if 1');

        isValid = rules.pattern.test(value);
      } else {
        // console.log('inside if 2');

        isValid = value.trim() !== '';
      }
    } else {
      // console.log('inside else');

      isValid = true;
    }
    return isValid;
  }

  closeModal = () => {
    this.setState(
      {
        show: false,
      },
      () => {
        // this.setState(this.getInitialState());
      },
    );
  };

  //   hide = e => {
  //     if (e && e.relatedTarget) {
  //       e.relatedTarget.click();
  //     }
  //     this.setState({ openSavedViewDropdown: false });
  //   };

  render() {
    let inputs = [];
    const keys = Object.keys(this.state.saveViewForm);
    for (const key of keys) {
      const formElement = this.state.saveViewForm[key];
      //console.log(formElement);
      inputs.push(
        <Inputs
          key={key}
          name={key}
          elementType={formElement.elementType}
          elementConfig={formElement.elementConfig}
          value={formElement.value}
          valid={formElement.valid}
          touched={formElement.touched}
          changed={event => this.inputChangeHandler(event, key, 'saveViewForm')}
          validation={formElement.validation}
        />,
      );
    }
    return (
      <Fragment>
        <SavedViewContainer>
          <SavedViewParentStyle>
            <SavedViewLabelStyle>Saved Views </SavedViewLabelStyle>
            <SavedViewSelectStyle
              openSavedViewDropdown={this.state.openSavedViewDropdown}
              onClick={this.savedViewDropDown}
              onMouseLeave={() => this.setState({ openSavedViewDropdown: false })}
              tabIndex="0"
            >
              <SavedViewInputStyle>
                <SavedViewDataStyle>
                  {!this.state.saveViewData ? '--Select View --' : this.state.saveViewData}
                </SavedViewDataStyle>
                <DropdownIcon saveViewData={this.state.saveViewData}>
                  <Icon icon="gridIcons.down-arrow" width="7" height="9" />
                </DropdownIcon>
              </SavedViewInputStyle>
              {this.state.openSavedViewDropdown ? (
                <DropdownContainer>
                  <SavedViewOptionStyle>
                    {this.state.saveViewArray.length > 0 ? (
                      this.state.saveViewArray.map((data, index) => (
                        <SavedViewContentLayout key={data} onClick={() => this.onDataSelected(data)}>
                          <SavedViewContentStyle>
                            <input
                              type="checkbox"
                              onClick={e => {
                                e.stopPropagation();
                                this.onDataSelected(data);
                              }}
                              onMouseDown={e => e.preventDefault()}
                              checked={data === this.state.saveViewData}
                              readOnly
                            />
                            <span>{data}</span>
                          </SavedViewContentStyle>
                        </SavedViewContentLayout>
                      ))
                    ) : (
                      <SavedViewContentStyle>
                        <div style={{ height: '25px', display: 'flex', alignItems: 'center' }}>
                          <span>--Select View--</span>
                        </div>
                      </SavedViewContentStyle>
                    )}
                  </SavedViewOptionStyle>
                </DropdownContainer>
              ) : null}
            </SavedViewSelectStyle>
            <SavedViewIconsStyle>
              <SavedViewBtn onClick={this.handleShow} title="Add view">
                <Icon as="button" icon="add" type="svg" width="20" height="20" svgIconColor="svgIconColorDark" />
              </SavedViewBtn>
              <SavedViewBtn title="Update View">
                <Icon as="button" icon="multimedia" type="svg" width="20" height="20" svgIconColor="svgIconColorDark" />
              </SavedViewBtn>
              <SavedViewBtn onClick={this.deleteSaveView} title="Delete View">
                <Icon as="button" icon="delete" type="svg" width="20" height="20" svgIconColor="svgIconColorDark" />
              </SavedViewBtn>
            </SavedViewIconsStyle>
          </SavedViewParentStyle>
          <ButtonPanel
            onAddClick={e => this.props.onAddClick()}
            onPartsUsageClick={e => this.props.onPartsUsageClick()}
          />
        </SavedViewContainer>

        <GpModal
          FormatModal={false}
          show={this.state.show}
          backdropClicked={this.closeModal}
          title="Save View"
          closeClicked={this.closeModal}
          modalWidth="20%"
          modalHeight="4cm"
        >
          <SampleMessageWithInput
            disabled={!this.state.formIsValid}
            content={inputs}
            noClicked={this.closeModal}
            yesClicked={this.handleSaveOfSaveView}
          />
        </GpModal>
      </Fragment>
    );
  }
}

export default SavedView;
