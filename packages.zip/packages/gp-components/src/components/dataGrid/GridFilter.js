import React, { Component } from 'react';
import { dataGrid as gridDataStyle } from '../../tokens/components';
import { StyledElement } from '../utils/element';
import Datepicker from './../datepicker/Datepicker';

let GridFilterComponent = StyledElement('div')(gridDataStyle.basicGrid.gridFilterComponent);
let GridInputStyle = StyledElement('div')(gridDataStyle.basicGrid.gridInputStyle);
let GridTextInput = StyledElement('input')(gridDataStyle.basicGrid.gridTextInput);
let RadioInputStyle = StyledElement('div')(gridDataStyle.basicGrid.radioInputStyle);
let NumberInputStyle = StyledElement('div')(gridDataStyle.basicGrid.numberInputStyle);
let LabelStyle = StyledElement('span')(gridDataStyle.basicGrid.labelStyle);
let Seprator = StyledElement('div')(gridDataStyle.basicGrid.seperator);
let DatePickerStyle = StyledElement('div')(gridDataStyle.basicGrid.datepickerStyle);
let InputStyle = StyledElement('input')(gridDataStyle.basicGrid.inputStyle);

class GridFilter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      text: '', //This is for normal text field filter
      greaterThan: '', //This is for Number type filter
      lesserThan: '',
      equals: '',
      displayCalendar: false,
      value: 1,
      refreshFilter: false,
    };
    this.filterInputObj = {};
    this.valueGetter = this.props.valueGetter;
    this.columnProps = this.props.column.userProvidedColDef.headerComponentParams;
    this.handleDateChange = this.handleDateChange.bind(this);
    this.checkboxValue = 'none';
    this.dateGreaterThanValue = '';
    this.dateLesserThanValue = '';
    this.dateEqualsValue = '';
  }

  isFilterActive() {
    return this.state.text !== null && this.state.text !== undefined && this.state.text !== '';
  }

  componentDidUpdate(prevProps) {
    if (JSON.stringify(prevProps.column.userProvidedColDef.headerComponentParams.columnId) === JSON.stringify({})) {
      this.checkboxValue = 'none';
    }
  }

  doesFilterPass(params) {
    return this.state.text
      .toLowerCase()
      .split(' ')
      .every(filterWord => {
        return (
          this.valueGetter(params.node)
            .toString()
            .toLowerCase()
            .indexOf(filterWord) >= 0
        );
      });
  }

  getModel(params) {
    return { value: this.state.text };
  }

  setModel(model) {
    this.setState({ text: model ? model.value : '' });
  }

  onChange = event => {
    this.props.column.userProvidedColDef.headerComponentParams.onFilterInputValues(
      this.props.column.userProvidedColDef.headerName,
      this.props.column.userProvidedColDef.field,
      event.target.value,
    );
    let newValue = event.target.value;
    this.setState({ ...this.state, [event.target.name]: event.target.value });
    if (this.state.text !== newValue) {
      this.setState(
        {
          text: newValue,
        },
        () => {
          if (this.columnProps.gridData.inlineFilter.enable === 'true') this.props.filterChangedCallback();
        },
      );
    }
  };

  handleChange = e => {
    this.props.column.userProvidedColDef.headerComponentParams.onFilterInputValues(
      this.props.column.userProvidedColDef.headerName,
      this.props.column.userProvidedColDef.field,
      e.target.value,
    );
    let newValue = e.target.value;
    this.setState({ ...this.state, [e.target.name]: e.target.value });
    if (e.target.name === 'equals') {
      this.setState({ greaterThan: '', lesserThan: '' });
    } else {
      this.setState({ equals: '' });
    }
    if (this.state.text !== newValue) {
      this.setState(
        {
          text: newValue,
        },
        () => {
          if (this.columnProps.gridData.inlineFilter.enable === 'true') this.props.filterChangedCallback();
        },
      );
    }
  };

  dateFilter = userInputIdentifier => {
    let today = this.dateGreaterThanValue;
    let today1 = this.dateLesserThanValue;

    let dd = today.getDate();
    let dd1 = today1.getDate();

    let mm = today.getMonth() + 1;
    let mm1 = today1.getMonth() + 1;
    let yyyy = today.getFullYear();
    let yyyy1 = today1.getFullYear();
    if (dd < 10) {
      dd = '0' + dd;
    }
    if (dd1 < 10) {
      dd1 = '0' + dd1;
    }

    if (mm < 10) {
      mm = '0' + mm;
    }
    if (mm1 < 10) {
      mm1 = '0' + mm1;
    }
    today = dd + '/' + mm + '/' + yyyy;
    today1 = dd1 + '/' + mm1 + '/' + yyyy1;
    this.props.column.userProvidedColDef.headerComponentParams.onDateFilter(
      this.props.column.userProvidedColDef.headerName,
      this.props.column.userProvidedColDef.field,
      'greaterAndLesserThan',
      today,
      today1,
    );
  };

  handleDateChange = (date, userInputIdentifier) => {
    switch (userInputIdentifier) {
      case 'dateGreaterThanValue':
        this.dateGreaterThanValue = date;
        if (this.dateEqualsValue !== '') {
          this.dateEqualsValue = '';
        }
        if (date != null) {
          var today = date;
          var dd = today.getDate();

          var mm = today.getMonth() + 1;
          var yyyy = today.getFullYear();
          if (dd < 10) {
            dd = '0' + dd;
          }

          if (mm < 10) {
            mm = '0' + mm;
          }
          today = dd + '/' + mm + '/' + yyyy;
        }
        this.props.column.userProvidedColDef.headerComponentParams.onDateFilter(
          this.props.column.userProvidedColDef.headerName,
          this.props.column.userProvidedColDef.field,
          userInputIdentifier,
          today,
        );
        if (this.dateGreaterThanValue && this.dateLesserThanValue) {
          this.dateFilter('dateGreaterThanValue');
        }
        break;
      case 'dateLesserThanValue':
        this.dateLesserThanValue = date;
        if (this.dateEqualsValue !== '') {
          this.dateEqualsValue = '';
        }
        if (date != null) {
          var today = date;
          var dd = today.getDate();

          var mm = today.getMonth() + 1;
          var yyyy = today.getFullYear();
          if (dd < 10) {
            dd = '0' + dd;
          }

          if (mm < 10) {
            mm = '0' + mm;
          }
          today = dd + '/' + mm + '/' + yyyy;
        }
        this.props.column.userProvidedColDef.headerComponentParams.onDateFilter(
          this.props.column.userProvidedColDef.headerName,
          this.props.column.userProvidedColDef.field,
          userInputIdentifier,
          today,
        );
        if (this.dateGreaterThanValue && this.dateLesserThanValue) {
          this.dateFilter('dateLesserThanValue');
        }
        break;
      case 'dateEqualsValue':
        this.dateEqualsValue = date;
        this.dateGreaterThanValue = '';
        this.dateLesserThanValue = '';
        if (date != null) {
          var today = date;
          var dd = today.getDate();

          var mm = today.getMonth() + 1;
          var yyyy = today.getFullYear();
          if (dd < 10) {
            dd = '0' + dd;
          }

          if (mm < 10) {
            mm = '0' + mm;
          }
          today = dd + '/' + mm + '/' + yyyy;
        }

        this.props.column.userProvidedColDef.headerComponentParams.onDateFilter(
          this.props.column.userProvidedColDef.headerName,
          this.props.column.userProvidedColDef.field,
          userInputIdentifier,
          today,
        );

        break;
      default:
    }
    this.setState({ refreshFilter: !this.state.refreshFilter });
  };

  onRadioInputChange = (e, field) => {
    let newValue = e;
    this.setState({ ...this.state, [this.props.column.colId]: field }, () => {
      this.props.column.userProvidedColDef.headerComponentParams.onRadioInputFilter(
        this.props.column.userProvidedColDef.headerName,
        this.props.column.userProvidedColDef.field,
        field,
      );
    });
    this.checkboxValue = field;
  };

  renderFilterModal = () => {
    const lessThan = '<';

    switch (this.props.colDef.type) {
      case 'Number':
      case 'Date':
        let minimumWidth = 180;
        return (
          <GridFilterComponent
            column={this.props.column}
            left={this.props.column.left}
            columnDetails={this.props.colDef.headerComponentParams.columnKey[0].field}
            type={this.props.colDef.type}
            width={this.props.column.actualWidth <= minimumWidth ? minimumWidth : this.props.column.actualWidth}
          >
            <GridInputStyle type={this.props.colDef.type}>
              <LabelStyle type={this.props.colDef.type}>
                <b>></b>
              </LabelStyle>
              {this.props.colDef.type.includes('Date') ? (
                <DatePickerStyle width={this.props.column.actualWidth}>
                  <Datepicker
                    type="Date"
                    name="dateGreaterThanValue"
                    elementConfig={{
                      options: [],
                      placeholder: '',
                      width: '124px',
                      height: '25px',
                      containerWidth: '152px',
                    }}
                    validation={{
                      required: false,
                    }}
                    value={this.dateGreaterThanValue}
                    // selected={this.state.dateGreaterThanValue}
                    onKeyDown={e => this.columnProps.onFilterInputChange(e, this.props.column.colDef.field)}
                    changed={e => this.handleDateChange(e, 'dateGreaterThanValue')}
                  ></Datepicker>
                </DatePickerStyle>
              ) : (
                <NumberInputStyle width={this.props.column.actualWidth}>
                  <InputStyle
                    ref="input"
                    width={this.props.column.actualWidth}
                    name="greaterThan"
                    value={this.state.greaterThan}
                    onChange={this.handleChange}
                    onKeyDown={e => this.columnProps.onFilterInputChange(e, this.props.column.colDef.field)}
                  />
                </NumberInputStyle>
              )}
            </GridInputStyle>
            <GridInputStyle type={this.props.colDef.type}>
              <LabelStyle type={this.props.colDef.type}>
                <b>{lessThan}</b>
              </LabelStyle>
              {this.props.colDef.type.includes('Date') ? (
                <DatePickerStyle width={this.props.column.actualWidth}>
                  <Datepicker
                    type="Date"
                    name="dateLesserThanValue"
                    elementConfig={{
                      options: [],
                      placeholder: '',
                      width: '124px',
                      height: '25px',
                      containerWidth: '152px',
                    }}
                    validation={{
                      required: false,
                    }}
                    value={this.dateLesserThanValue}
                    // selected={this.state.dateGreaterThanValue}
                    onKeyDown={e => this.columnProps.onFilterInputChange(e, this.props.column.colDef.field)}
                    changed={e => this.handleDateChange(e, 'dateLesserThanValue')}
                  ></Datepicker>
                </DatePickerStyle>
              ) : (
                <NumberInputStyle width={this.props.column.actualWidth}>
                  <InputStyle
                    ref="input"
                    width={this.props.column.actualWidth}
                    name="lesserThan"
                    value={this.state.lesserThan}
                    onKeyDown={e => this.columnProps.onFilterInputChange(e, this.props.column.colDef.field)}
                    onChange={this.handleChange}
                  />
                </NumberInputStyle>
              )}
            </GridInputStyle>
            <Seprator type={this.props.colDef.type} />
            <GridInputStyle type={this.props.colDef.type}>
              <LabelStyle type={this.props.colDef.type}>
                <b>=</b>
              </LabelStyle>
              {this.props.colDef.type.includes('Date') ? (
                <DatePickerStyle width={this.props.column.actualWidth}>
                  <Datepicker
                    type="Date"
                    name="dateEqualsValue"
                    elementConfig={{
                      options: [],
                      placeholder: '',
                      width: '124px',
                      height: '25px',
                      containerWidth: '152px',
                    }}
                    validation={{
                      required: false,
                    }}
                    value={this.dateEqualsValue}
                    disabled={false}
                    changed={e => this.handleDateChange(e, 'dateEqualsValue')}
                  ></Datepicker>
                </DatePickerStyle>
              ) : (
                <NumberInputStyle width={this.props.column.actualWidth}>
                  <InputStyle
                    width={this.props.column.actualWidth}
                    ref="input"
                    name="equals"
                    onKeyDown={e => this.columnProps.onFilterInputChange(e, this.props.column.colDef.field)}
                    value={this.state.equals}
                    onChange={this.handleChange}
                  />
                </NumberInputStyle>
              )}
            </GridInputStyle>
          </GridFilterComponent>
        );
      case 'CheckBox':
        return (
          <GridFilterComponent className="filter-container">
            <GridInputStyle>
              <RadioInputStyle onClick={e => this.onRadioInputChange(e, 'yes')}>
                <input
                  style={{ height: '15px' }}
                  onKeyDown={e => this.columnProps.onFilterInputChange(e, this.props.column.colDef.field)}
                  type="radio"
                  onChange={e => {
                    this.onRadioInputChange(e, 'yes');
                  }}
                  readOnly
                  checked={this.checkboxValue === 'yes'}
                  name={this.props.column.colId}
                  value="yes"
                />
                Yes
              </RadioInputStyle>
            </GridInputStyle>
            <GridInputStyle>
              <RadioInputStyle onClick={e => this.onRadioInputChange(e, 'no')}>
                <input
                  style={{ height: '15px' }}
                  type="radio"
                  name={this.props.column.colId}
                  onChange={e => {
                    this.onRadioInputChange(e, 'no');
                  }}
                  readOnly
                  checked={this.checkboxValue === 'no'}
                  value="no"
                  onKeyDown={e => this.columnProps.onFilterInputChange(e, this.props.column.colDef.field)}
                  className="form-control"
                />
                No
              </RadioInputStyle>
            </GridInputStyle>
            <GridInputStyle>
              <RadioInputStyle onClick={e => this.onRadioInputChange(e, 'none')}>
                <input
                  style={{ height: '15px' }}
                  type="radio"
                  name={this.props.column.colId}
                  onChange={e => {
                    this.onRadioInputChange(e, 'none');
                  }}
                  value="none"
                  readOnly
                  checked={this.checkboxValue === 'none'}
                  onKeyDown={e => this.columnProps.onFilterInputChange(e, this.props.column.colDef.field)}
                  className="form-control"
                />
                None
              </RadioInputStyle>
            </GridInputStyle>
          </GridFilterComponent>
        );
      default:
        const minWidth = 100;
        return (
          <GridTextInput
            autocomplete="off"
            name="text"
            onChange={this.onChange}
            // width={this.props.column.actualWidth}
            value={this.state[this.props.column.colDef.field]}
            left={this.props.column.left}
            onKeyDown={e => this.columnProps.onFilterInputChange(e, this.props.column.colDef.field)}
            width={this.props.column.actualWidth <= minWidth ? minWidth : this.props.column.actualWidth}
          />
        );
    }
  };

  render() {
    const minWidth = this.props.colDef.type === 'Date' ? 180 : 100;
    return (
      <GridFilterComponent
        left={this.props.column.left}
        width={this.props.column.actualWidth <= minWidth ? minWidth : this.props.column.actualWidth}
      >
        {this.renderFilterModal()}
      </GridFilterComponent>
    );
  }
}

export default GridFilter;
