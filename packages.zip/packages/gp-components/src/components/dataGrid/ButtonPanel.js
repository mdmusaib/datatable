import React, { Component } from 'react';
import Icon from './../icons/Icon';
import { StyledElement } from '../utils/element';
import { dataGrid as gridDataStyle } from '../../tokens/components';

const ButtonPanelContainer = StyledElement('div')(gridDataStyle.basicGrid.buttonPanelContainer);
const ButtonPanelIconsStyle = StyledElement('div')(gridDataStyle.basicGrid.buttonPanelIconsStyle);

class ButtonPanel extends Component {
  render() {
    return (
      <ButtonPanelContainer>
        <ButtonPanelIconsStyle title="Add" onClick={e => this.props.onAddClick()}>
          <Icon type="svg" as="button" icon="add" width="20" height="20" svgIconColor="svgIconColorDark" />
        </ButtonPanelIconsStyle>
        <ButtonPanelIconsStyle title="Edit">
          <Icon type="svg" as="button" icon="edit" width="20" height="20" svgIconColor="svgIconColorDark" />
        </ButtonPanelIconsStyle>
        <ButtonPanelIconsStyle title="Copy">
          <Icon type="svg" as="button" icon="file1" width="20" height="20" svgIconColor="svgIconColorDark" />
        </ButtonPanelIconsStyle>
        <ButtonPanelIconsStyle title="Delete">
          <Icon type="svg" as="button" icon="delete" width="20" height="20" svgIconColor="svgIconColorDark" />
        </ButtonPanelIconsStyle>
        <ButtonPanelIconsStyle title="Part Usage" onClick={e => this.props.onPartsUsageClick()}>
          <Icon type="svg" as="button" icon="partsUsage" width="20" height="20" svgIconColor="svgIconColorDark" />
        </ButtonPanelIconsStyle>
        <ButtonPanelIconsStyle title="Set End Date">
          <Icon type="svg" as="button" icon="setEndDateSVG" width="20" height="20" svgIconColor="svgIconColorDark" />
        </ButtonPanelIconsStyle>
        <ButtonPanelIconsStyle title="Replacement History">
          <Icon
            type="svg"
            as="button"
            icon="replacementHistory"
            width="20"
            height="20"
            svgIconColor="svgIconColorDark"
          />
        </ButtonPanelIconsStyle>
      </ButtonPanelContainer>
    );
  }
}

export default ButtonPanel;
