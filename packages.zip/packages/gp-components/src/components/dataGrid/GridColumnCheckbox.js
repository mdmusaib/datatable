import React, { Component, Fragment } from 'react';
import Checkbox from './../Checkbox/Checkbox';

class GridColumnCheckbox extends Component {
  render() {
    let rowData = JSON.stringify(this.props.data) !== JSON.stringify({});
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '25px' }}>
        <div style={{ position: 'relative', bottom: '18px' }}>
          {rowData ? (
            <Checkbox
              name="Name"
              elementConfig={{
                placeholder: '',
                component: 'grid',
              }}
              value={this.props.data[this.props.column.colId]}
              validation={{
                required: false,
                disabled: true,
              }}
              valid={false}
              touched={false}
            />
          ) : (
            <Fragment />
          )}
        </div>
      </div>
    );
  }
}

export default GridColumnCheckbox;
