import React, { Component, Fragment } from 'react';
import { dataGrid as gridDataStyle } from '../../tokens/components';
import { StyledElement } from '../utils/element';
import Icon from '../icons/Icon';

let GridFilterButton = StyledElement('div')(gridDataStyle.basicGrid.gridFilterButton);
let GridHeaderStyle = StyledElement('div')(gridDataStyle.basicGrid.gridHeaderStyle);
let GridHeaderComponent = StyledElement('div')(gridDataStyle.basicGrid.gridHeaderComponent);
let HeaderStyle = StyledElement('div')(gridDataStyle.basicGrid.headerStyle);
let SortStyle = StyledElement('div')(gridDataStyle.basicGrid.sortStyle);
let HeaderContainer = StyledElement('div')(gridDataStyle.basicGrid.headerContainer);
let IconLayout = StyledElement('div')(gridDataStyle.basicGrid.iconLayout);

class GridHeader extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showFilter: true, //This is for showing filter

      colFields: [],
    };
    this.pinnedColumns = {};
    this.pinVisible = {};
    this.colId = this.props.column.userProvidedColDef.headerComponentParams;
  }

  onMouseOver = () => {
    this.pinVisible = {
      ...this.pinVisible,
      [this.props.column.colDef.field]: true,
    };
    this.setState({ pinVisible: true });
  };

  onMouseOut = () => {
    this.pinVisible = {
      ...this.pinVisible,
      [this.props.column.colDef.field]: false,
    };
    this.setState({ pinVisible: false });
  };

  render() {
    let filter = null;
    filter = (
      <GridFilterButton
        ref={filterRef => {
          this.filterButton = filterRef;
        }}
        onClick={this.onFilterIconClick.bind(this)}
        sctdfy
      >
        {this.props.column.colDef.field === this.colId.filteredColumn ? (
          <Icon
            icon="filter"
            type="svg"
            width="15"
            height="15"
            style={{ marginLeft: '5px' }}
            svgIconColor="danger"
            title="Data filtered"
          />
        ) : this.colId.columnId[this.props.column.colDef.field] ? (
          <Icon
            icon="filter"
            type="svg"
            width="15"
            height="15"
            style={{ marginLeft: '5px' }}
            svgIconColor="danger"
            title="Data filtered"
          />
        ) : (
          <Icon
            icon="filter"
            type="svg"
            width="15"
            height="15"
            style={{ marginLeft: '5px' }}
            svgIconColor="white"
            title="Filter data"
          />
        )}
      </GridFilterButton>
    );
    let sort = null;
    if (this.colId.dataField[0] === this.props.displayName) {
      sort = (
        <div
          style={{
            display: 'inline-block',
          }}
          onClick={() => this.onSortRequested('desc')}
        >
          <Icon icon="downArrow" type="svg" width="12" height="11" svgIconColor="white" />
        </div>
      );
      if (this.colId.ascSort === 'active') {
        sort = (
          <div
            style={{ display: 'inline-block', transform: 'rotate(180deg)' }}
            onClick={() => this.onSortRequested('asc')}
          >
            <Icon icon="downArrow" type="svg" svgIconColor="white" width="12" height="11" />
          </div>
        );
      }
    }
    return (
      <GridHeaderComponent width={this.props.column.actualWidth}>
        {filter}
        <HeaderContainer
          width={this.props.column.actualWidth}
          onMouseEnter={this.onMouseOver}
          onMouseLeave={this.onMouseOut}
          onClick={() => {
            if (this.colId.ascSort === 'active') {
              this.onSortRequested('asc');
            } else {
              this.onSortRequested('desc');
            }
          }}
        >
          <GridHeaderStyle
            onClick={() => {
              this.colId.showSortBtn(this.props.displayName);
            }}
            width={this.props.column.actualWidth}
          >
            <HeaderStyle>{this.props.displayName}</HeaderStyle>
            <SortStyle>{sort}</SortStyle>
          </GridHeaderStyle>
          <div
            style={{
              position: 'relative',
              left: '8px',
            }}
          >
            {this.colId.pinnedColumns[this.props.column.colDef.field] &&
            this.colId.pinnedColumns[this.props.column.colDef.field].pinned === 'left' ? (
              <div onClick={() => this.colId.onColumnPin(this.props.column.colDef.field, 'null')}>
                <Icon icon="pin" type="svg" width="15" height="15" svgIconColor="white" />
              </div>
            ) : this.pinVisible[this.props.column.colDef.field] ? (
              <div
                style={{ width: '12px', height: '19px', transform: 'rotate(45deg)' }}
                onClick={() => this.colId.onColumnPin(this.props.column.colDef.field, 'left')}
              >
                <Icon icon="pin" type="svg" width="15" height="15" svgIconColor="white" />
              </div>
            ) : (
              <IconLayout></IconLayout>
            )}
          </div>
        </HeaderContainer>
      </GridHeaderComponent>
    );
  }

  onFilterIconClick = () => {
    this.setState({ showFilter: !this.state.showFilter });
    if (this.state.showFilter) {
      this.props.showColumnMenu(this.filterButton);
    }
  };

  onSortRequested = order => {
    this.props.setSort(order);
  };
}

export default GridHeader;
