import React from 'react';
import { spinner as spinnerStyle } from '../../tokens/components';
import { StyledElement } from '../utils/element';

let StyledPath = StyledElement('path')(spinnerStyle.path);
let StyledWrapper = StyledElement('div')(spinnerStyle.wrapper);
let StyledSvg = StyledElement('svg')(spinnerStyle.svg);
const LoadingProgress = props => (
  <StyledWrapper>
    <StyledSvg viewBox="0  0 75  50 ">
      <StyledPath primary d="M 25 0 L45 0 L75 30 L55 50 L45 40 L55 30" />
      <StyledPath secondary d="M 5 5 L25 5 L50 30 L30 50 L20 40 L30 30" />
    </StyledSvg>
    {/* <span>
      loading
      <span>.</span>
      <span>.</span>
      <span>.</span>
    </span> */}
  </StyledWrapper>
);
export default LoadingProgress;
