import React, { useState, useEffect } from 'react';
import styled from '@emotion/styled';
import { StyledElement } from '../utils/element';
import { sideBar as sideBarStyle } from '../../tokens/components/';
import Icon from '../../components/icons/Icon';

const SideBar = StyledElement('div')(sideBarStyle.SideBar);

const NavItem = props => {
  const [showClose, setShowClose] = useState(false);
  const StyledNav = StyledElement('div')(sideBarStyle.SideNavItem);
  const StyledCls = StyledElement('div')(sideBarStyle.NavItemClose);
  const onItemSelect = function() {
    props.OnItemSelect(props.module);
  };
  const onItemRemove = function(e) {
    e.preventDefault();
    e.stopPropagation();
    props.OnItemRemove(props.module);
  };

  const showCloseIcon = e => {
    if (props.unClosable) return;
    // if (!props.selected) return;
    //e.stopPropagation();
    setShowClose(true);
  };
  const hideCloseIcon = e => {
    if (props.unClosable) return;
    // if (!props.selected) return;
    //e.stopPropagation();
    setShowClose(false);
  };
  return (
    <StyledNav {...props} onClick={onItemSelect}>
      <Icon type="svg" icon={props.module.icon} width="15" height="15" />
      <span>{props.module.moduleName}</span>
      {props.canClose ? (
        <StyledCls onClick={onItemRemove}>
          <span>x</span>
        </StyledCls>
      ) : null}
    </StyledNav>
  );
};

const AppSideBar = props => {
  const [isExpanded, setIsExpanded] = useState(false);
  let onSelect = selectedItem => {
    props.onItemSelect(selectedItem);
  };
  let onItemRemove = selectedItem => {
    props.onItemRemove(selectedItem);
  };

  const StyledIcon = styled(Icon)`
    align-self: center;
    --margin-left: 17px;
    margin-top: auto;
    margin-bottom: 10px;
    transform: ${isExpanded ? 'rotate(-45deg)' : 'rotate(45deg)'};
  `;

  const onMouse = e => setIsExpanded(true);
  const onMouseOut = e => setIsExpanded(false);

  // This will render the navbar items based on the modules props
  const renderNavItems = navItems => {
    if (navItems !== undefined && navItems.length > 0) {
      return navItems.map(item => (
        <NavItem
          tabWidth={item.width}
          isExpanded={isExpanded}
          canClose={item.canClose}
          selected={props.selectedModule === item.moduleName}
          OnItemSelect={name => onSelect(name)}
          OnItemRemove={name => onItemRemove(name)}
          key={item.moduleName}
          module={item}
        />
      ));
    }
  };
  return (
    //onMouseEnter={onMouse} onMouseLeave={onMouseOut}
    <SideBar isExpanded={isExpanded}>
      {renderNavItems(props.navItems)}
      {/* <StyledIcon onClick={e => setIsExpanded(!isExpanded)} icon="moduleIcons.pin" width="16" height="16" /> */}
    </SideBar>
  );
};

export default AppSideBar;
