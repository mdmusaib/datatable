/**
 * @author Vimal
 * This is the wrapper componenet which will enable the modules
 * to show / hide while navigating the app side bar
 */
import React from 'react';
import { StyledElement } from '../utils/element';
import CatchError from '../errorBoundary/CatchShowError';

const AppModuleStyle = props => ({
  display: props.hide ? 'none' : 'block',
  width: '100%',
  height: '100%',
  padding: 0,
  margin: 0,
  backgroundColor: 'white',
});
const AppModule = StyledElement('div')(AppModuleStyle);
export default props => (
  <AppModule {...props}>
    <CatchError>{props.children}</CatchError>
  </AppModule>
);
