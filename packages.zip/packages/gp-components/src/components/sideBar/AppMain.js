import React, { Suspense, useState, useEffect } from 'react';
import styled from '@emotion/styled';
import AppSideBar from './AppSideBar';
import Spinner from '../spinner/Spinner';

let StyledHomePage = styled.div`
  display: grid;
  grid-template-columns: 40px auto;
  background-color: #fff;
  --background-image: linear-gradient(-145deg, #007580, #662d91);
`;
let StyledSection = styled.section`
  justify-self: center;
  align-self: center;
  width: 100%;
  height: 100%;
  padding: 0;
  --background-color: antiquewhite;
  display: flex;
  align-items: center;
  justify-content: center;
`;
const SidebarHolder = styled.div`
  width: 40px;
  height: 100vh;
`;
const AppHome = props => {
  //This function to render the modules
  const lazyLoadModules = moduleLists => {
    if (moduleLists !== undefined && moduleLists.length > 0) {
      return moduleLists.map(item => {
        return (
          <Suspense key={item.moduleName} fallback={<Spinner />}>
            <item.module hide={item.moduleName !== props.selectedModule} />
          </Suspense>
        );
      });
    }
  };

  const loadModule = module => {
    props.selectModule(module);
  };
  const unLoadModule = module => {
    let filteredModules = props.modules.filter(item => item.moduleName !== module.moduleName);
    props.removeModule(module);
    props.selectModule(filteredModules[filteredModules.length - 1]);
  };
  return (
    <StyledHomePage>
      <AppSideBar
        onItemRemove={unLoadModule}
        onItemSelect={loadModule}
        selectedModule={props.selectedModule}
        navItems={props.modules}
      />
      <SidebarHolder />

      <StyledSection>{lazyLoadModules(props.modules)}</StyledSection>
    </StyledHomePage>
  );
};

export default AppHome;
