import React, { Component } from 'react';
import Icon from '../icons/Icon';
import { exportToExcel } from '../../tokens/components';
import { StyledElement } from '../utils/element';

let ExportToExcelStyle = StyledElement('div')(exportToExcel.exportToExcelStyle);

class ExportToExcel extends Component {
  render() {
    return (
      <ExportToExcelStyle title="Export To Excel">
        <Icon icon="excel" type="svg" width="20" height="20" title="Export To Excel" />
      </ExportToExcelStyle>
    );
  }
}

export default ExportToExcel;
