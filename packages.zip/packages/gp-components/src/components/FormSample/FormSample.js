import React from 'react';
import {
  InputField,
  Textarea,
  SingleSelectDropdown,
  MultiSelectDropdown,
  Checkbox,
  Button,
  Datepicker,
} from './../../index';
import { Container, Row, Col } from 'react-bootstrap';

class FormSample extends React.Component {
  constructor(props) {
    super(props);
    this.state = this.getInitialState();
  }

  getInitialState = () => {
    const initialState = {
      multiValue: [],
    };
    return initialState;
  };

  onMultiSelectChange = event => {
    event.preventDefault();
    let multiValue = this.state.multiValue;
    let index = '';
    if ((index = multiValue.indexOf(event.target.value)) > -1) {
      multiValue.splice(index, 1);
    } else {
      multiValue.push(event.target.value);
    }
    this.setState({
      multiValue,
    });
  };

  render() {
    let inputs = [];
    inputs.push(
      <>
        <InputField
          name="part"
          elementConfig={{
            placeholder: 'Part#',
            md: 3,
            lg: 3,
            xl: 3,
          }}
          validation={{
            required: true,
          }}
          valid={false}
        />

        <InputField
          name="partName"
          elementConfig={{
            placeholder: 'Part Name',
            md: { span: 3, offset: 1 },
            lg: { span: 3, offset: 1 },
            xl: { span: 3, offset: 1 },
          }}
          validation={{
            required: true,
          }}
          valid={false}
        />

        <InputField
          name="partIssued"
          elementConfig={{
            placeholder: 'Part Issued',
            md: { span: 3, offset: 1 },
            lg: { span: 3, offset: 1 },
            xl: { span: 3, offset: 1 },
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <InputField
          name="weight"
          elementConfig={{
            placeholder: 'Weight',
            md: 2,
            lg: 2,
            xl: 2,
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <InputField
          name="maxWeight"
          elementConfig={{
            placeholder: 'Max Weight',
            md: { span: 2, offset: 2 },
            lg: { span: 2, offset: 2 },
            xl: { span: 2, offset: 2 },
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <SingleSelectDropdown
          name="weightUnit"
          elementConfig={{
            options: [
              { value: 'GR', displayValue: 'GR - GRAM' },
              { value: 'KG', displayValue: 'KG - KILOGRAM' },
            ],
            placeholder: 'Weight Unit',
            md: { span: 4, offset: 2 },
            lg: { span: 4, offset: 2 },
            xl: { span: 4, offset: 2 },
          }}
          validation={{
            required: true,
          }}
          valid={false}
          touched={false}
        />
        <InputField
          name="part2"
          elementConfig={{
            placeholder: 'Part#2',
            md: 3,
            lg: 3,
            xl: 3,
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <InputField
          name="partname2"
          elementConfig={{
            placeholder: 'Part Name 2',
            md: { span: 3, offset: 1 },
            lg: { span: 3, offset: 1 },
            xl: { span: 3, offset: 1 },
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <SingleSelectDropdown
          name="supplier"
          elementConfig={{
            options: [
              { value: '01', displayValue: '01 - ABCD' },
              { value: '02', displayValue: '02 - ABCD' },
            ],
            placeholder: 'Supplier',
            md: { span: 4, offset: 1 },
            lg: { span: 4, offset: 1 },
            xl: { span: 4, offset: 1 },
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <SingleSelectDropdown
          name="catagory"
          elementConfig={{
            options: [
              { value: '01', displayValue: '01 - ABCD' },
              { value: '02', displayValue: '02 - ABCD' },
            ],
            placeholder: 'Catagory',
            md: 3,
            lg: 3,
            xl: 3,
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <SingleSelectDropdown
          name="usageType"
          elementConfig={{
            options: [
              { value: '01', displayValue: '01 - ABCD' },
              { value: '02', displayValue: '02 - ABCD' },
            ],
            placeholder: 'Usage Type',
            md: { span: 3, offset: 1 },
            lg: { span: 3, offset: 1 },
            xl: { span: 3, offset: 1 },
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <SingleSelectDropdown
          name="shapeType"
          elementConfig={{
            options: [
              { value: '01', displayValue: '01 - ABCD' },
              { value: '02', displayValue: '02 - ABCD' },
            ],
            placeholder: 'Shape Type',
            md: { span: 4, offset: 1 },
            lg: { span: 4, offset: 1 },
            xl: { span: 4, offset: 1 },
          }}
          validation={{
            required: true,
          }}
          valid={false}
          touched={false}
        />
        <InputField
          name="height"
          elementConfig={{
            placeholder: 'Height',
            md: 2,
            lg: 2,
            xl: 2,
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <InputField
          name="width"
          elementConfig={{
            placeholder: 'Width',
            md: { span: 2, offset: 2 },
            lg: { span: 2, offset: 2 },
            xl: { span: 2, offset: 2 },
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <InputField
          name="depth"
          elementConfig={{
            placeholder: 'Depth',
            md: { span: 2, offset: 2 },
            lg: { span: 2, offset: 2 },
            xl: { span: 2, offset: 2 },
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <SingleSelectDropdown
          name="lengthUnit"
          elementConfig={{
            options: [
              { value: '01', displayValue: '01 - ABCD' },
              { value: '02', displayValue: '02 - ABCD' },
            ],
            placeholder: 'Length Unit',
            md: 3,
            lg: 3,
            xl: 3,
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <InputField
          name="cost"
          elementConfig={{
            placeholder: 'Cost',
            md: { span: 3, offset: 1 },
            lg: { span: 3, offset: 1 },
            xl: { span: 3, offset: 1 },
          }}
          validation={{
            required: true,
          }}
          valid={false}
          touched={false}
        />

        <Checkbox
          name="cost"
          elementConfig={{
            placeholder: 'Pax Dependent',
            md: { span: 2, offset: 1 },
            lg: { span: 2, offset: 1 },
            xl: { span: 2, offset: 1 },
          }}
          validation={{
            required: true,
          }}
          valid={false}
          touched={false}
        />
        <Checkbox
          name="isSellable"
          elementConfig={{
            placeholder: 'Is Sellable',
            md: 2,
            lg: 2,
            xl: 2,
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <Datepicker
          name="startDate"
          elementConfig={{
            options: [],
            placeholder: 'Eff. Date',
            md: 3,
            lg: 3,
            xl: 3,
          }}
          validation={{
            required: true,
          }}
          valid={false}
          touched={false}
          startDate={new Date('01/01/2000')}
          openToDate={new Date('01/01/2000')}
          disabled={false}
        ></Datepicker>
        <Datepicker
          elementConfig={{
            options: [],
            placeholder: 'End Date',
            md: { span: 4, offset: 1 },
            lg: { span: 4, offset: 1 },
            xl: { span: 4, offset: 1 },
          }}
          validation={{
            required: false,
          }}
          startDate={new Date()}
          minDate={new Date('01/01/2000')}
          labelName="EndDate"
          disabled={false}
        ></Datepicker>
      </>,
    );

    let inputs2 = [];
    inputs2.push(
      <>
        <Textarea
          name="description"
          elementConfig={{
            placeholder: 'Description',
            md: 12,
            lg: 12,
            xl: 12,
          }}
          validation={{
            required: false,
          }}
          valid={false}
          touched={false}
        />
        <Textarea
          name="description"
          elementConfig={{
            placeholder: 'Description 2',
            md: 12,
            lg: 12,
            xl: 12,
          }}
          validation={{
            required: true,
          }}
          valid={false}
          touched={false}
        />
      </>,
    );

    let inputs3 = [];

    inputs3.push(
      <MultiSelectDropdown
        name="passengerClass"
        elementConfig={{
          options: [
            { value: 'Single', displayValue: 'Single Val' },
            { value: 'Second', displayValue: 'Second Val' },
            { value: 'Third', displayValue: 'Third Val' },
          ],
          label: 'Passenger Class',
          placeholder: 'Passenger Class',
          md: 12,
          lg: 12,
          xl: 12,
        }}
        validation={{
          required: false,
        }}
        value={this.state.multiValue}
        changed={this.onMultiSelectChange}
        valid={false}
        touched={false}
      />,
    );

    return (
      <>
        <form style={{ padding: '15px' }}>
          <Container>
            <Row>{inputs}</Row>
            <Row>
              <Col style={{ padding: '0' }} md={7}>
                {inputs2}
              </Col>
              <Col md={5}>{inputs3}</Col>
            </Row>
            <Row style={{ float: 'right', marginRight: '10px' }}>
              <Button>Save</Button>
            </Row>
          </Container>
        </form>
      </>
    );
  }
}

export default FormSample;
