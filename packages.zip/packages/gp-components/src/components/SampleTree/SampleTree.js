import Tree from './../Tree/Tree';
import React from 'react';

class SampleTree extends React.Component {
  state = {
    sampleData: [
      {
        name: 'AIRCRAFT_FAMILY_01',
        id: 'AIRCRAFT_FAMILY_01',
        type: 'DESIGNER_AIRCRAFT_FAMILY',
        hasChildren: true,
        childrenLoaded: true,
        subOptions: [
          {
            name: 'AIRCRAFT_TYPE_01',
            id: 'AIRCRAFT_TYPE_01',
            type: 'DESIGNER_AIRCRAFT_TYPE',
            hasChildren: true,
            childrenLoaded: true,
            subOptions: [
              {
                name: 'AIRCRAFT_LAYOUT_01',
                id: 'AIRCRAFT_LAYOUT_01',
                type: 'DESIGNER_AIRCRAFT_LAYOUT',
                hasChildren: true,
                childrenLoaded: true,
                subOptions: [
                  {
                    name: 'GALLEY_01',
                    id: 'GALLEY_01',
                    type: 'DESIGNER_GALLEY',
                    hasChildren: true,
                    childrenLoaded: true,
                    subOptions: [
                      {
                        name: 'STORAGE_BAY_01',
                        id: 'STORAGE_BAY_01',
                        type: 'DESIGNER_STOWAGES',
                        hasChildren: true,
                        childrenLoaded: true,
                        subOptions: [
                          {
                            name: 'LOADING_RULE_01',
                            id: 'LOADING_RULE_01',
                            type: 'DESIGNER_CONTAINER_TYPES',
                            hasChildren: false,
                            childrenLoaded: false,
                            subOptions: [],
                          },
                          {
                            name: 'LOADING_RULE_02',
                            id: 'LOADING_RULE_02',
                            type: 'DESIGNER_CONTAINER_TYPES',
                            hasChildren: false,
                            childrenLoaded: false,
                            subOptions: [],
                          },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
          {
            name: 'AIRCRAFT_TYPE_02',
            id: 'AIRCRAFT_TYPE_02',
            type: 'DESIGNER_AIRCRAFT_TYPE',
            hasChildren: true,
            childrenLoaded: true,
            subOptions: [],
          },
        ],
      },
    ],
    selectedOptions: {},
  };

  selectOptionHandler = selectedOptions => {
    console.log('session-----', localStorage.getItem('clickedData'));
    this.setState({
      selectedOptions,
    });
  };

  render() {
    return (
      <div>
        <Tree
          options={this.state.sampleData}
          onChange={(selectedOptions, name) => this.selectOptionHandler(selectedOptions, name)}
          selectedOptions={this.state.selectedOptions}
        />
      </div>
    );
  }
}

export default SampleTree;
