import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { Button } from './../../index';
import Icon from './../icons/Icon';
class SampleMessage extends React.Component {
  render() {
    return (
      <>
        <Container>
          <Row style={{ justifyContent: 'center', height: '15vh', padding: '7px 10px' }}>
            <span style={{ fontSize: '14px', color: 'black' }}>
              <Icon width="25" height="25" icon={this.props.iconName} />
              {this.props.message}</span>
          </Row>
          <Row style={{ justifyContent: 'center', height: '4vh' }}>
            <Button onButtonClick={this.props.yesClicked} style={{ marginLeft: '8px' }}>Yes</Button>
            <Button onButtonClick={this.props.noClicked}>No</Button>
          </Row>
        </Container>

      </>
    );
  }
}

export default SampleMessage;
