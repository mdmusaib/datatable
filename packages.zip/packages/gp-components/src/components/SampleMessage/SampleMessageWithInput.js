import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import { Button } from './../../index';
import Icon from './../icons/Icon';
class SampleMessageWithInput extends React.Component {
    render() {
        return (
            <>
                <Container>
                    <Row style={{ justifyContent: 'center', height: '11vh', padding: '7px 10px' }}>
                        {this.props.content}
                    </Row>
                    <Row style={{ justifyContent: 'center', height: '4vh' }}>
                        <Button disabled={this.props.disabled} onButtonClick={this.props.yesClicked} style={{ margin: ' 0 5px' }}>Save</Button>
                        <Button variant="secondary" onButtonClick={this.props.noClicked} style={{ margin: ' 0 5px' }}>Close</Button>
                    </Row>
                </Container>

            </>
        );
    }
}

export default SampleMessageWithInput;
