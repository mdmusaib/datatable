import React from 'react';
import styled from '@emotion/styled';
import { toast as toastStyle } from './../../tokens/components';
import Icon from './../icons/Icon'

let StyledToast = styled('div')(toastStyle);


const Toast = (props) => (
    props.show ?
        <StyledToast
            show={props.show}
        >
            <div className="ToastContainer">
                {props.children}
            </div>
            {
                props.showCrossIcon ?
                    <span className="ToastCrossIcon" onClick={props.closeToast}><Icon height='15' width='15' type="svg" icon="clear" svgIconColor="white" /></span>
                    :
                    <></>
            }
        </StyledToast>
        :
        <></>
);

export default Toast;