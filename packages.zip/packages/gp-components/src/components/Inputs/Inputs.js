import React, { Component } from 'react';
import InputField from '../InputField/InputField';
import Textarea from './../Textarea/Textarea';
import SingleSelectDropdown from './../SingleSelectDropdown/SingleSelectDropdown';
import MultiSelectDropdown from './../MultiSelectDropdown/MultiSelectDropdown';
import Checkbox from './../Checkbox/Checkbox';
import RadioButton from './../RadioButton/RadioButton';
import DatePicker from './../datepicker/Datepicker';
import LookupList from './../LookupList/LookupList';

class Inputs extends Component {
  render() {
    let inputElement = null;

    switch (this.props.elementType) {
      case 'InputField':
      case 'input':
        inputElement = (
          <InputField
            validation={this.props.validation}
            name={this.props.name}
            elementConfig={this.props.elementConfig}
            changed={this.props.changed}
            value={this.props.value}
            valid={this.props.valid}
            touched={this.props.touched}
          />
        );

        break;
      case 'Textarea':
        inputElement = (
          <Textarea
            validation={this.props.validation}
            name={this.props.name}
            elementConfig={this.props.elementConfig}
            changed={this.props.changed}
            value={this.props.value}
            maxLength={this.props.maxLength}
            valid={this.props.valid}
            touched={this.props.touched}
            autocomplete={this.props.autocomplete}
          />
        );

        break;
      case 'SingleSelectDropdown':
        inputElement = (
          <SingleSelectDropdown
            validation={this.props.validation}
            name={this.props.name}
            elementConfig={this.props.elementConfig}
            changed={this.props.changed}
            value={this.props.value}
            valid={this.props.valid}
            touched={this.props.touched}
          />
        );
        break;
      case 'MultiSelectDropdown':
        inputElement = (
          <MultiSelectDropdown
            validation={this.props.validation}
            name={this.props.name}
            elementConfig={this.props.elementConfig}
            changed={this.props.changed}
            value={this.props.value}
            valid={this.props.valid}
            touched={this.props.touched}
          // onFocus={this.validation}
          // onBlue={this.validation}
          />
        );
        break;
      case 'RadioButton':
        inputElement = (
          <RadioButton
            validation={this.props.validation}
            name={this.props.name}
            elementConfig={this.props.elementConfig}
            changed={this.props.changed}
            value={this.props.value}
            valid={this.props.valid}
            touched={this.props.touched}
          />
        );
        break;
      case 'Checkbox':
        inputElement = (
          <Checkbox
            // checked={this.props.value.indexOf(option.value || option.rowId) > -1}
            validation={this.props.validation}
            name={this.props.name}
            elementConfig={this.props.elementConfig}
            changed={this.props.changed}
            value={this.props.value}
            valid={this.props.valid}
            touched={this.props.touched}
          />
        );
        break;
      case 'DatePicker':
        inputElement = (
          <DatePicker
            validation={this.props.validation}
            name={this.props.name}
            elementConfig={this.props.elementConfig}
            changed={this.props.changed}
            value={this.props.value}
            valid={this.props.valid}
            touched={this.props.touched}
            startDate={this.props.startDate}
            minDate={this.props.minDate}
            labelName={this.props.labelName}
            disabled={this.props.disabled}
          />
        );
        break;
      case 'LookupList':
        inputElement = (
          <LookupList
            validation={this.props.validation}
            name={this.props.name}
            elementConfig={this.props.elementConfig}
            changed={this.props.changed}
            value={this.props.value}
            valid={this.props.valid}
            touched={this.props.touched}
          />
        );

        break;
      default:
        inputElement = '';
        //(<InputField
        //     validation={this.props.validation}
        //     name={this.props.name}
        //     elementConfig={this.props.elementConfig}
        //     changed={this.props.changed}
        //     value={this.props.value}
        //     maxLength={this.props.maxLength}
        //     valid={this.props.valid}
        //     touched={this.props.touched}
        //     autocomplete={this.props.autocomplete}
        // />);

        break;
    }

    return inputElement;
  }
}

export default Inputs;
