import React from 'react';
// import styled from '@emotion/styled';
import Icon from '../../components/icons/Icon';
import { StyledElement } from '../utils/element';
import '../drawingTool/common/tooltipStyle.css';
import { tooltipStyle } from '../../tokens/components/';

const ToolTipElement = StyledElement('div')(tooltipStyle);

const Tooltip = props => {
  const deleteTabs = data => {
    props.deleteTabs(data);
  };

  const handleHide = e => {
    console.log('inside', e);
    // console.log((e.target.style.visibility = 'hidden'));
  };
  const handleShow = e => {
    if (e.target === undefined) {
    } else {
      // console.log((e.target.style.visibility = 'visible'));
    }
  };

  return (
    <ToolTipElement {...props}>
      <div className="mytooltip" onMouseOver={e => handleShow(props.tooltip.title)}>
        <Icon style={{ position: 'absolute', marginLeft: '-8px' }} icon="drawingToolIcons.whiteflight" />
        <span className="tooltipText">{props.tooltip.title}</span>
        <Icon
          style={{ marginTop: '2px', position: 'absolute', marginLeft: '-2px' }}
          icon="drawingToolIcons.greyCloseButton"
          width="13"
          height="13"
          onClick={e => {
            deleteTabs(props.tooltip);
          }}
        />
        <span
          id={props.tooltip.position}
          className="mytext"
          onMouseOver={e => handleHide(e)}
          onMouseLeave={e => handleShow(e)}
        >
          {' '}
          {props.tooltip.title}
        </span>
      </div>
    </ToolTipElement>
  );
};

export default Tooltip;
