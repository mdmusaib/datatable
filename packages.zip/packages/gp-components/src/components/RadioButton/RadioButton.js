import React from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { Col, Row, Container } from 'react-bootstrap';
import { radioButton as radioButtonStyle } from '../../tokens/components';

const StyledRadio = styled('label')(radioButtonStyle);

const RadioButton = props => {
  const LabelName = [props.elementConfig.placeholder];
  if (props.validation) {
    if (props.validation.required) {
      LabelName.push(<span style={{ color: 'red' }}> *</span>);
    }
  }
  return (
    // <Col xs={props.elementConfig.xs || 6} sm={props.elementConfig.sm || 6} md={props.elementConfig.md || 6} lg={props.elementConfig.lg || 6} xl={props.elementConfig.xl || 6} >
    //     <Container>
    //         <Row>

    <div style={{ display: 'flex', width: '100%' }}>
      {props.elementConfig.options.map((option, index) => {
        return (
          <StyledRadio key={index}>
            <input
              type="radio"
              id={option.value}
              name={props.name}
              value={option.value}
              onChange={props.changed}
              required={props.validation !== undefined ? props.validation.required : false}
            />
            <span className="checkmark">{option.displayValue}</span>
          </StyledRadio>
        );
      })}
    </div>
    //     </Container>
    // </Col>
  );
};

export default RadioButton;

RadioButton.propTypes = {
  /**
   *This is to set the configuration of the element
   */
  elementConfig: PropTypes.object,
  /**
   *This is to show the name of the element (Comes under elementConfig)
   */
  placeholder: PropTypes.string,
  /**
   *This is to show the value of the element
   */
  value: PropTypes.any,
  /**
   *This is to give a name (id) for the element (must be unique for multiple elements)
   */
  name: PropTypes.string,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  xs: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  sm: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  md: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  lg: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  xl: PropTypes.number,
  /**
   *This is onChange function of the element
   */
  changed: PropTypes.func,
};
