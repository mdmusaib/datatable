import React, { useState } from 'react';
import PropTypes from 'prop-types';
import FloatingLabelInput from 'react-floating-label-input';
import styled from '@emotion/styled';
import { Col, Container, Row } from 'react-bootstrap';
import { inputField as inputStyle, inputTooltip as inputTooltipStyle } from '../../tokens/components';
import FloatingLabel from 'floating-label-react';
import 'floating-label-react/styles.css';
import ValidationClass from '../Inputs/InputValidations';
import ReactTooltip from 'react-tooltip';

const StyledFloatingInput = styled('div')(inputStyle);
const StyledTooltip = styled(ReactTooltip)(inputTooltipStyle);

class InputField extends ValidationClass {
    state = {
        value: null,
        errorMessage: '',
        focusIn: false,
        focusOut: false
    };

    componentDidMount() {
        if (this.props.value) {
            this.setState({
                focusIn: true,
                focusOut: false
            })
        }
    }

    onFocusIn = () => {
        this.setState({
            focusIn: true,
        }, () => this.validation)
    }

    onBlur = () => {
        if (!this.props.value) {
            this.setState({
                focusIn: false,
                focusOut: true
            }, () => this.validation)
        }

    }

    render() {
        const LabelName = [this.props.elementConfig.placeholder];
        if (this.props.validation) {
            if (this.props.validation.required) {
                LabelName.push(<mark> *</mark>);
            }
        }
        // console.log(this.props.touched, 'this.state.errorMessage---', this.state.errorMessage)
        return (
            <>
                <StyledFloatingInput
                    for={this.props.name}
                    inValid={(this.state.focusOut && !this.props.value && this.props.validation.required) || (this.props.valid === false && this.props.touched === true)}
                    inFocus={this.state.focusIn}
                    isInputWithDropDown={this.props.elementConfig.isInputWithDropDown}
                    width={this.props.elementConfig.width}
                    widthNoMargin={this.props.elementConfig.widthNoMargin}
                    readOnly={this.props.elementConfig.readOnly}
                >
                    <input
                        // required={this.props.validation !== undefined ? this.props.validation.required : false}
                        type={this.props.elementConfig.type || 'text'}
                        id={this.props.name}
                        name={this.props.name}
                        label={this.props.elementConfig.placeholder}
                        variant={this.props.elementConfig.variant || 'outlined'}
                        onChange={this.props.changed}
                        value={this.props.elementConfig.inputType === "code" ? this.props.value.toUpperCase() : this.props.value}
                        resize="none"
                        onBlur={this.onBlur}
                        maxlength={this.props.elementConfig.inputType === "number" || this.props.elementConfig.inputType === "numberNoDot" ? 4 : this.props.elementConfig.inputType === "code" ? 30 : this.props.elementConfig.inputType === "name" ? 65 : null}
                        autocomplete="off"
                        data-tip={this.state.focusOut && !this.props.value && this.props.validation.required ? 'This field is required.' : ''}
                        data-for={this.props.name}
                        novalidate={true}
                        onFocus={this.onFocusIn}
                        onKeyDown={this.validation}
                        width={this.props.elementConfig.width}
                        readOnly={this.props.elementConfig.readOnly}
                    />
                    <span>{LabelName}</span>
                </StyledFloatingInput>
                <StyledTooltip backgroundColor='#FF4713' place="right" effect="solid" id={this.props.name} />
            </>
            // </Col>
        );
    }
    // const[value, setValue] = useState(this.props.value)


}

export default InputField;

InputField.propTypes = {
    /**
     *This is to set the configuration of the element
     */
    elementConfig: PropTypes.object,
    /**
     *This is to show the name of the element (Comes under elementConfig)
     */
    placeholder: PropTypes.string,
    /**
     *This is to show the value of the element
     */
    value: PropTypes.any,
    /**
     *This is to give a name (id) for the element (must be unique for multiple elements)
     */
    name: PropTypes.string,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    xs: PropTypes.number,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    sm: PropTypes.number,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    md: PropTypes.number,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    lg: PropTypes.number,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    xl: PropTypes.number,
    /**
     *This is onChange function of the element
     */
    changed: PropTypes.func,
};
