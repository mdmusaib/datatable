import React from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { backdrop as backdropStyle } from '../../tokens/components'

let StyledBackdrop = styled('div')(backdropStyle)

const backdrop = (props) => (

    props.show ? <StyledBackdrop onClick={props.backdropClicked}></StyledBackdrop> : null
);

export default backdrop;

backdrop.propTypes = {
    /**
     *This is to show the backdrop
     */
    show: PropTypes.bool,
    /**
     *This is onClick funtion of the element
     */
    backdropClicked: PropTypes.func,

};