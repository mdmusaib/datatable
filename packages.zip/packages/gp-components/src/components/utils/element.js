import styled from './styled';
import estyled from '@emotion/styled';
import systemProps from './system-props';
import css from '@styled-system/css';
import { variant } from 'styled-system';
//import shouldForwardProp from '@styled-system/should-forward-prop';

const Element = styled('div')(systemProps);

const StyledElement = element => style => {
  let elem = styled(element)(systemProps);
  return estyled(elem)(
    props => css(typeof style === 'function' ? style(props) : { ...style }),
    props => variant(typeof style === 'function' ? style(props) : { ...style }),
  );
};

export { StyledElement };
export default Element;
