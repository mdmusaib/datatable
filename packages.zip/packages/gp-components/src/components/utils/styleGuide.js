import React from 'react';
import styled from '@emotion/styled';
import colors from '../../tokens/colors';

let StyleWrapper = styled.div`
  align-content: flex-start;
  height: 300px;
  width: 100%;
  /* background-color: antiquewhite; */
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
`;

let paxiaColors = Object.keys(colors.paxia);

let StyledDiv = styled.div`
  display: flex;
  width: 200px;
  align-items: center;
  margin-bottom: 5px;
  --background-color: #c35e5e;
`;
let Item = styled.div(props => ({
  width: '25px',
  height: '25px',
  backgroundColor: props.color,
  borderRadius: '50%',
  boxShadow: '0px 1px 2px rgb(0,0,0,.4)',
  marginRight: '5px',
}));
function StyleGuide() {
  return (
    <StyleWrapper>
      {paxiaColors.map((item, index) => (
        <StyledDiv key={index}>
          <Item color={colors.paxia[item]} />
          <span>{item}</span>
        </StyledDiv>
      ))}
    </StyleWrapper>
  );
}
export default StyleGuide;
