import React, { Component } from 'react';
import Icon from '../icons/Icon';

class Reports extends Component {
  render() {
    return (
      <div title="Reports">
        <Icon icon="report" type="svg" width="20" height="20" title="Reports" />
      </div>
    );
  }
}

export default Reports;
