import React, { Component } from 'react';
import Icon from '../icons/Icon';
import { print } from '../../tokens/components';
import { StyledElement } from '../utils/element';

let PrintIconStyle = StyledElement('div')(print.printStyle);

class Print extends Component {
  render() {
    return (
      <PrintIconStyle>
        <Icon icon="print_icon" />
      </PrintIconStyle>
    );
  }
}

export default Print;
