import React from 'react';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { Col, Row, Container } from 'react-bootstrap';
import { checkbox as checkboxStyle } from '../../tokens/components';
import Icon from './../icons/Icon';

const StyledCheckbox = styled('div')(checkboxStyle);

const Checkbox = props => {
  const LabelName = [props.elementConfig.placeholder];
  if (props.validation) {
    if (props.validation.required) {
      LabelName.push(<span style={{ color: 'red' }}> *</span>);
    }
  }

  // console.log('------', props.value)

  return (
    // <Col xs={props.elementConfig.xs || 6} sm={props.elementConfig.sm || 6} md={props.elementConfig.md || 6} lg={props.elementConfig.lg || 6} xl={props.elementConfig.xl || 6} >
    //     <Container>
    //         <Row>
    <>
      <StyledCheckbox md={2} component={props.elementConfig.component} >
        <input
          className="CheckBox"
          type="checkbox"
          onChange={props.changed}
          disabled={props.validation.disabled}
          value={props.value}
          checked={props.value}
        />
        {/* <Icon icon="checkbox" /> */}

        <label onClick={props.changed} className="Label" for={props.name}>
          {LabelName}
        </label>
      </StyledCheckbox>
    </>
    //         </Row>
    //     </Container>
    // </Col>
  );
};

export default Checkbox;

Checkbox.propTypes = {
  /**
   *This is to set the configuration of the element
   */
  elementConfig: PropTypes.object,
  /**
   *This is to show the name of the element (Comes under elementConfig)
   */
  placeholder: PropTypes.string,
  /**
   *This is to show the value of the element
   */
  value: PropTypes.any,
  /**
   *This is to give a name (id) for the element (must be unique for multiple elements)
   */
  name: PropTypes.string,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  xs: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  sm: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  md: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  lg: PropTypes.number,
  /**
   *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
   */
  xl: PropTypes.number,
  /**
   *This is onChange function of the element
   */
  changed: PropTypes.func,
};
