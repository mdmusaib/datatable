import React, { useState } from 'react'
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import "floating-label-react/styles.css";
import FloatingLabel from "floating-label-react";
import { Col, Container, Row } from 'react-bootstrap'
import { textarea as textareaStyle, inputTooltip as inputTooltipStyle } from '../../tokens/components';
import ValidationClass from '../Inputs/InputValidations';
import ReactTooltip from 'react-tooltip';

const StyledTextarea = styled('div')(textareaStyle)
const StyledTooltip = styled(ReactTooltip)(inputTooltipStyle);

class Textarea extends ValidationClass {
    state = {
        value: null,
        errorMessage: '',
        focusIn: false,
    };

    componentDidMount() {
        if (this.props.value) {
            this.setState({
                focusIn: true
            })
        }
    }

    onFocusIn = () => {
        this.setState({
            focusIn: true
        }, () => this.validation)
    }

    onBlur = () => {
        if (!this.props.value) {
            this.setState({
                focusIn: false
            }, () => this.validation)
        }
    }


    render() {
        const LabelName = [this.props.elementConfig.placeholder];
        if (this.props.validation) {
            if (this.props.validation.required) {
                LabelName.push(<mark> *</mark>)
            }
        }
        return (
            <>
                <StyledTextarea
                    for={this.props.name}
                    inValid={(this.state.errorMessage && !this.props.value) || (this.props.valid === false && this.props.touched === true)}
                    inFocus={this.state.focusIn}
                    isInputWithDropDown={this.props.elementConfig.isInputWithDropDown}
                    width={this.props.elementConfig.width}
                    widthNoMargin={this.props.elementConfig.widthNoMargin}
                    readOnly={this.props.elementConfig.readOnly}
                >
                    <textarea
                        required={this.props.validation !== undefined ? this.props.validation.required : false}
                        id={this.props.name}
                        name={this.props.name}
                        label={this.props.elementConfig.placeholder}
                        //placeholder={LabelName}
                        fullWidth
                        multiline={true}
                        rows={4}
                        variant={this.props.elementConfig.variant || 'outlined'}
                        onChange={this.props.changed}
                        value={this.props.value}
                        resize="none"
                        onBlur={this.onBlur}
                        onFocus={this.onFocusIn}
                        onKeyDown={this.validation}
                        maxlength="265"
                    />
                    <span>{LabelName}</span>
                </StyledTextarea>
                <StyledTooltip effect="solid" clickable={true} type="info" multiline={true} />
            </>
        );
    }
}

export default Textarea;

Textarea.propTypes = {
    /**
     *This is to set the configuration of the element
     */
    elementConfig: PropTypes.object,
    /**
     *This is to show the name of the element (Comes under elementConfig)
     */
    placeholder: PropTypes.string,
    /**
     *This is to show the value of the element
     */
    value: PropTypes.any,
    /**
     *This is to give a name (id) for the element (must be unique for multiple elements)
     */
    name: PropTypes.string,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    xs: PropTypes.number,
    /**
    *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
    */
    sm: PropTypes.number,
    /**
      *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
      */
    md: PropTypes.number,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    lg: PropTypes.number,
    /**
     *This is to define the size of the element (size must be from 1-12 and comes under elementConfig)
     */
    xl: PropTypes.number,
    /**
     *This is onChange function of the element
     */
    changed: PropTypes.func

};