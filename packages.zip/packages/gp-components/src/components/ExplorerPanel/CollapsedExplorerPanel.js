import React from 'react';
import Icon from './../icons/Icon';
import PropTypes from 'prop-types';
import styled from '@emotion/styled';
import { collapsedExplorerPanel as collapsedExplorerPanelStyle } from './../../tokens/components';

let StyledExplorerPanel = styled('div')(collapsedExplorerPanelStyle);

const CollapsedExplorerPanel = props => {
  return (
    <StyledExplorerPanel {...props}>
      <span className="CollapsedIcon">
        <Icon icon="treeIcon.rightSide" width="12px" height="10px" onClick={props.openExplorer} />
      </span>
      <h3>{props.panelName}</h3>
    </StyledExplorerPanel>
  );
};

CollapsedExplorerPanel.propTypes = {};

export default CollapsedExplorerPanel;
