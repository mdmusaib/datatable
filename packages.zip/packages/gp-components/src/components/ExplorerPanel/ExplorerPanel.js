import React from 'react';
import { Col, Container, Row } from 'react-bootstrap';
import Icon from './../icons/Icon';
import styled from '@emotion/styled';
import { explorerPanel as explorerPanelStyle } from './../../tokens/components';

let StyledExplorerPanel = styled(Container)(explorerPanelStyle);

const ExplorerPanel = props => {
  return (
    <StyledExplorerPanel>
      <Row className="ExplorerRow">
        <Col md={8} className="ExplorerCol">
          <div className="ExplorerHeadingContainer">
            <span className="ExplorerToggleIcon">
              <Icon icon="treeIcon.rightSide" width="12px" height="10px" onClick={props.toggleExplorer} />
            </span>
            <span>{props.explorerHeading}</span>
          </div>
        </Col>
        <Col md={4} className="ExplorerCol">
          <div className="ExplorerHeadingIconContainer">
            {props.fleetExplorerIcons.map(icon => (
              <div
                className="ExplorerHeadingIconLayout"
                title={icon.title}
                onClick={() => props.onButtonClick(icon.title)}
              >
                <Icon type="svg" icon={icon.icon} svgIconColor={icon.color} className="ExplorerHeadingIcon" />
              </div>
            ))}
          </div>
        </Col>
      </Row>
      <Row className="ExplorerChildren">{props.children}</Row>
    </StyledExplorerPanel>
  );
};

export default ExplorerPanel;
