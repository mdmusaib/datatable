import React, { Component } from 'react'
import html2canvas from 'html2canvas'
import { Stage, Layer, Image } from 'react-konva'

export class Text extends Component {

    constructor(props) {
        super(props)
    
        this.state = {
            textArray:[], 
            textValue:'',
            textXPos:0,
            textYPos:0,
            textEditVisible:false,
            isSelected:true,
            isFinished:false,
            isApplyingStyles:false,
            baseCanvas:null,
            isStageSet:false,
            isEditing:false
        }

    }

    handleStageClick = (e) => {
        const stage = e.target.getStage()
       
        this.setState({
            textEditVisible:true,
            textXPos:stage.getPointerPosition().x,
            textYPos:stage.getPointerPosition().y,
        })

        this.refs.editText.focus()
    }

    removeElem = (id) => {
        var elem = document.getElementById(id)
        elem.remove()
    }

    handleTextEdit = (e) => {
        this.refs.editText.style.width='auto';
        this.refs.editText.style.height='auto';        
    }

    handleBlur = (e) => {
        var isappSty = this.refs.editText.getAttribute("isApplyingStyles")
        if(isappSty === 'true'){
        }else{
            if(this.refs.editText.innerHTML !== ''){
                const textArray = this.state.textArray
                textArray.push({
                    id:`text${this.state.textArray.length+1}`,
                    height:this.refs.editText.offsetHeight,
                    width:this.refs.editText.offsetWidth,
                    textValue:this.refs.editText.innerHTML,
                    textXPos:this.state.textXPos,
                    textYPos:this.state.textYPos
                })
                this.setState({
                    textArray,
                    textValue:'',
                    textXPos:0,
                    textYPos:0,
                    isEditing:false,
                    textEditVisible:true,
                    isSelected:true,
                    isFinished:false,
                    isApplyingStyles:false
                })
            }
            this.refs.editText.innerHTML = ''
            this.refs.editText.style.width='150px'
            this.refs.editText.style.height='50px'
        }
    }

    handleSelect = (ev,style) => {
        ev.preventDefault()
        document.execCommand('styleWithCSS', false, true);
        document.execCommand(style,false,ev.target.value)
    }

    render() {
        return (
            <div>
                
                <div 
                    onMouseOver={() =>this.refs.editText.setAttribute("isApplyingStyles",true)}
                    onMouseOut={() => this.refs.editText.setAttribute("isApplyingStyles",false)}
                >
                    <button onClick={ (event) => this.handleSelect(event,'bold')} ><b>B</b></button>
                    <button onClick={ (event) => this.handleSelect(event,'italic')} ><em>I</em></button>
                    <button onClick={ (event) => this.handleSelect(event,'underline')} >U</button>

                    <select name='fontFamily' onChange={ (event) => this.handleSelect(event,'fontName')} >
                        <option value="Arial">Arial</option>
                        <option value="Helvetica">Helvetica</option>
                        <option value="Times New Roman">Times New Roman</option>
                        <option value="Sans serif">Sans serif</option>
                        <option value="Courier New">Courier New</option>
                        <option value="Verdana">Verdana</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Palatino">Palatino</option>
                        <option value="Garamond">Garamond</option>
                        <option value="Comic Sans MS">Comic Sans MS</option>
                        <option value="Arial Black">Arial Black</option>
                        <option value="Tahoma">Tahoma</option>
                    </select>
                    <select name='fontSize' onChange={(event) => this.handleSelect(event,'fontSize')} >
                        <option value={1}>1</option>
                        <option value={2}>2</option>
                        <option value={3}>3</option>
                        <option value={4}>4</option>
                        <option value={5}>5</option>
                        <option value={6}>6</option>
                        <option value={7}>7</option>
                    </select>
                    <button className="fontStyle align-left" onClick={(event) => this.handleSelect(event,'justifyLeft')} >Left</button>
                    <button className="fontStyle align-center" onClick={(event) => this.handleSelect(event,'justifyCenter')}>Center</button>
                    <button className="fontStyle align-right" onClick={(event) => this.handleSelect(event,'justifyRight')}>Right</button>
                    <select name='stroke' onChange={(event) => this.handleSelect(event,'foreColor')} >
                        <option value={'#ff4000'}>Red</option>
                        <option value={'#0040ff'}>Blue</option>
                        <option value={'#00ff40'}>Green</option>
                        <option value={'#ffff00'}>Yellow</option>
                        <option value={'#8000ff'}>Violet</option>
                        <option value={'#ff00bf'}>Pink</option>        
                    </select>
                    
                </div>
                <Stage
                    width={window.innerWidth}
                    height={window.innerHeight}
                    onClick={this.handleStageClick}
                    ref="stage"
                >
                    <Layer>
                    {
                            this.state.textArray.map( data => {
                                console.log(data.textValue)
                                var elem = document.createElement('div')
                                elem.id=data.id
                                elem.innerHTML=data.textValue
                                elem.setAttribute('style','position:absolute')
                                elem.setAttribute('height',data.height)
                                elem.setAttribute('width',data.width)
                                if(!document.body.contains(elem)){
                                    document.getElementById('editableDiv').appendChild(elem)
                                }
                                html2canvas(
                                    document.getElementById(data.id)
                                ).then(
                                        canvas=>{
                                            canvas.id = 'canvas'+data.id
                                            if(!document.body.contains(elem)){
                                                document.body.appendChild(canvas)
                                                canvas.style.display='none'
                                            }
                                        }
                                )
                                
                                this.removeElem(data.id)

                                return (
                                    <Image
                                        id={data.id}
                                        key={data.id}
                                        image={document.getElementById('canvas'+data.id)}
                                        x={data.textXPos} 
                                        y={data.textYPos} 
                                        width={data.width}
                                        height={data.height}
                                    />
                                )
                            }
                            )
                    }
                    </Layer>
                </Stage>
                <div
                    contentEditable={true}
                    id='editableDiv'
                    ref='editText'
                    style={{
                        display: this.state.textEditVisible ? 'block' : 'none',
                        position: 'absolute',
                        top: this.state.textYPos + 'px',
                        left: this.state.textXPos + 'px',
                        border:'1px solid black',
                        height:'50px',
                        width:'150px'
                    }}
                    onKeyDown={this.handleTextEdit}
                    onBlur={this.handleBlur}
                >
                </div>
            </div>
        )
    }
}

export default Text