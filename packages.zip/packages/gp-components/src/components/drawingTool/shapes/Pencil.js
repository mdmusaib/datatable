import React from 'react';
import { Line, Rect, Transformer, Group } from 'react-konva';

const Pencil = props => {
  const {
    points,
    stroke,
    strokeWidth,
    handleUpdatedDrag,
    index,
    x,
    y,
    endX,
    endY,
    dragedX,
    dragedY,
    scaleX,
    scaleY,
    draggable,
    isSelected,
    transformEnabled,
  } = props;
  const shapeRef = React.useRef();
  const trRef = React.useRef();

  React.useEffect(() => {
    if (isSelected) {
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  });

  return (
    <React.Fragment>
      <Group
        draggable={draggable}
        ref={shapeRef}
        x={dragedX || 0}
        y={dragedY || 0}
        scaleX={scaleX || 1}
        scaleY={scaleY || 1}
        onDragStart={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drag', true)}
        onDragMove={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drag', true)}
        onDragEnd={e => handleUpdatedDrag(e.target.attrs, index, 'drop', false)}
        onTransformEnd={e => handleUpdatedDrag(e.target.attrs, index, 'transform')}
      >
        <Rect x={x} y={y} width={endX - x} height={endY - y} stroke={'transparent'} />
        <Line points={points} stroke={stroke || 'black'} strokeWidth={strokeWidth || 1} />
      </Group>
      {isSelected && (
        <Transformer
          rotateEnabled={false}
          anchorSize={5}
          ref={trRef}
          // listening={transformEnabled}
          resizeEnabled={transformEnabled}
          boundBoxFunc={(oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
};

export default Pencil;
