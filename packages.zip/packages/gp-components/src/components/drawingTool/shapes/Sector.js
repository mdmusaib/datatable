import React, { useState } from 'react';
import { Shape, Transformer, Rect, Group } from 'react-konva';

const DrawSector = props => {
  const {
    x,
    y,
    endX,
    endY,
    stroke,
    strokeWidth,
    dragedX,
    dragedY,
    isSelected,
    fillLinearGradientColorStops,
    dragStartFalse,
    transformEnabled,
    handleUpdatedDrag,
    draggable,
    index,
    scaleX,
    scaleY,
    height,
    width,
  } = props;
  const shapeRef = React.useRef();
  const trRef = React.useRef();

  React.useEffect(() => {
    if (isSelected) {
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  });

  return (
    <React.Fragment>
      <Group
        draggable={isSelected || (props.grouped === true && draggable)}
        ref={shapeRef}
        x={x}
        y={y}
        scaleX={scaleX || 1}
        scaleY={scaleY || 1}
        onDragStart={e => handleUpdatedDrag(e.target.attrs, index, 'drag', true)}
        onDragMove={e => handleUpdatedDrag(e.target.attrs, index, 'drag', true)}
        onDragEnd={e => handleUpdatedDrag(e.target.attrs, index, 'drop', false)}
        // onTransformStart={e => handleUpdatedDrag(e.target.attrs, index, 'transform', true)}
        onTransformEnd={e => handleUpdatedDrag(e.target.attrs, index, 'transform', true)}
      >
        <Rect x={0} y={0} width={endX - x} height={endY - y} stroke={'transparent'} />
        <Shape
          sceneFunc={(context, shape) => {
            context.beginPath();
            context.moveTo(0, 0);
            context.lineTo(0, endY - y);
            context.lineTo(endX - x, endY - y);
            context.quadraticCurveTo(endX - x, 0, 0, 0);
            context.fillStrokeShape(shape);
          }}
          stroke={stroke || 'black'}
          strokeScaleEnabled={false}
          strokeWidth={strokeWidth}
          id={props.id} // fill={fill}
          groupID={props.groupID}
          fillLinearGradientStartPoint={fillLinearGradientColorStops && { x: 50, y: 50 }}
          fillLinearGradientEndPoint={fillLinearGradientColorStops && { x: 100, y: 100 }}
          fillLinearGradientColorStops={fillLinearGradientColorStops}
          onMouseEnter={() => (document.body.style.cursor = 'pointer')}
          onMouseLeave={() => (document.body.style.cursor = 'default')}
        />
      </Group>
      {isSelected && (
        <Transformer
          rotateEnabled={false}
          anchorSize={5}
          ref={trRef}
          onMouseLeave={() => dragStartFalse(false)}
          onMouseOut={() => dragStartFalse(false)}
          resizeEnabled={transformEnabled}
          boundBoxFunc={(oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
};

export default DrawSector;
