import React, { Component } from 'react';
import { Stage, Layer, Rect, Circle, Line } from 'react-konva';

export class Select extends Component {
  constructor(props) {
    super(props);

    this.state = {
      dataArray: [
        {
          shape: 'rect',
          x1: 400,
          y1: 400,
          x2: 500,
          y2: 500,
          stroke: 'red',
          id: 'rect1',
        },
        {
          shape: 'circle',
          x1: 350,
          y1: 150,
          x2: 500,
          y2: 250,
          stroke: 'red',
          id: 'circle1',
        },
        {
          shape: 'line',
          points: [500, 100, 700, 100],
          stroke: 'red',
          id: 'linel',
          x1: 500,
          y1: 100,
          x2: 700,
          y2: 100,
        },
        {
          shape: 'rect',
          x1: 800,
          y1: 100,
          x2: 900,
          y2: 200,
          stroke: 'red',
          id: 'rect2',
        },
        {
          shape: 'freehand',
          points: [
            60.265625,
            292,
            58.265625,
            263,
            56.265625,
            227,
            56.265625,
            209,
            57.265625,
            201,
            58.265625,
            190,
            59.265625,
            185,
            59.265625,
            182,
            60.265625,
            177,
            60.265625,
            176,
            61.265625,
            176,
            61.265625,
            175,
            61.265625,
            174,
            62.265625,
            174,
            63.265625,
            174,
            66.265625,
            175,
            73.265625,
            177,
            79.265625,
            180,
            88.265625,
            184,
            91.265625,
            186,
            95.265625,
            190,
            100.265625,
            194,
            105.265625,
            199,
            120.265625,
            217,
            125.265625,
            228,
            129.265625,
            234,
            131.265625,
            239,
            139.265625,
            252,
            148.265625,
            266,
            151.265625,
            270,
            154.265625,
            275,
            155.265625,
            277,
            155.265625,
            279,
            158.265625,
            285,
            159.265625,
            287,
            160.265625,
            290,
            160.265625,
            291,
            161.265625,
            292,
            161.265625,
            293,
            162.265625,
            293,
            162.265625,
            292,
            162.265625,
            287,
            162.265625,
            285,
            162.265625,
            282,
            162.265625,
            278,
            161.265625,
            276,
            161.265625,
            275,
            161.265625,
            272,
            161.265625,
            271,
            160.265625,
            271,
            160.265625,
            270,
            160.265625,
            269,
            160.265625,
            267,
            164.265625,
            239,
            170.265625,
            201,
            172.265625,
            188,
            172.265625,
            183,
            172.265625,
            181,
            172.265625,
            180,
            172.265625,
            178,
            172.265625,
            177,
            172.265625,
            176,
            172.265625,
            175,
            172.265625,
            174,
            172.265625,
            173,
            176.265625,
            163,
            181.265625,
            155,
            183.265625,
            152,
            183.265625,
            150,
            184.265625,
            149,
            184.265625,
            148,
            185.265625,
            147,
            186.265625,
            147,
            186.265625,
            146,
            187.265625,
            146,
            190.265625,
            144,
            193.265625,
            143,
            195.265625,
            143,
            196.265625,
            142,
            197.265625,
            142,
            198.265625,
            142,
            199.265625,
            142,
            200.265625,
            142,
            202.265625,
            143,
            205.265625,
            145,
            208.265625,
            146,
            214.265625,
            150,
            219.265625,
            153,
            226.265625,
            157,
            228.265625,
            160,
            237.265625,
            167,
            240.265625,
            170,
            243.265625,
            176,
            243.265625,
            179,
            245.265625,
            180,
            246.265625,
            182,
            248.265625,
            186,
            249.265625,
            189,
            251.265625,
            193,
            252.265625,
            196,
            254.265625,
            201,
            255.265625,
            204,
            255.265625,
            207,
            255.265625,
            208,
            255.265625,
            210,
            255.265625,
            213,
            256.265625,
            214,
            256.265625,
            215,
            257.265625,
            216,
            257.265625,
            218,
            260.265625,
            220,
            261.265625,
            222,
            262.265625,
            223,
            265.265625,
            226,
            266.265625,
            227,
            268.265625,
            229,
            269.265625,
            231,
            269.265625,
            232,
            270.265625,
            232,
            272.265625,
            234,
            272.265625,
            235,
            273.265625,
            237,
            274.265625,
            238,
            274.265625,
            240,
            275.265625,
            242,
            276.265625,
            244,
            277.265625,
            244,
            278.265625,
            246,
            278.265625,
            247,
            278.265625,
            248,
            278.265625,
            249,
            279.265625,
            249,
            279.265625,
            250,
            279.265625,
            251,
            280.265625,
            251,
            281.265625,
            251,
            281.265625,
            252,
            282.265625,
            252,
            282.265625,
            253,
            284.265625,
            253,
            284.265625,
            254,
            285.265625,
            254,
            285.265625,
            255,
            286.265625,
            255,
            286.265625,
            256,
            289.265625,
            259,
            290.265625,
            259,
            291.265625,
            260,
          ],
          stroke: 'red',
          x1: 60,
          y1: 292,
          x2: 290,
          y2: 260,
          id: 'freehand1',
        },
      ],
      startPoint: {
        x: 0,
        y: 0,
      },
      endPoint: {
        x: 0,
        y: 0,
      },
      isStarted: false,
      isFinished: false,
    };
  }

  handleClick = ev => {
    const stage = ev.target.getStage();
    const mousePosition = this.getMousePosition(stage);
    this.selectShapes(mousePosition[0], mousePosition[1]);
  };

  handleMouseDown = ev => {
    const stage = ev.target.getStage();
    const mousePosition = this.getMousePosition(stage);
    this.setState({
      startPoint: {
        x: Math.round(mousePosition[0]),
        y: Math.round(mousePosition[1]),
      },
      isStarted: true,
      isFinished: false,
    });
  };

  handleMouseMove = ev => {
    if (this.state.isStarted) {
      const stage = ev.target.getStage();
      const mousePosition = this.getMousePosition(stage);

      this.setState({
        endPoint: {
          x: Math.round(mousePosition[0]),
          y: Math.round(mousePosition[1]),
        },
      });
    }
  };

  handleMouseUp = ev => {
    const stage = ev.target.getStage();
    const mousePosition = this.getMousePosition(stage);

    this.setState({
      endPoint: {
        x: Math.round(mousePosition[0]),
        y: Math.round(mousePosition[1]),
      },
      isFinished: true,
      isStarted: false,
    });

    let startPoint = this.state.startPoint;
    let endPoint = this.state.endPoint;
    var count = 0;

    if (startPoint.x > endPoint.x && startPoint.y > endPoint.y) {
      this.setState({
        startPoint: endPoint,
        endPoint: startPoint,
      });
      startPoint = this.state.startPoint;
      endPoint = this.state.endPoint;
    }

    this.state.dataArray.map(data => {
      if (data.shape === 'freehand') {
        var dataArray = this.state.dataArray;
        var start = {
          x: 0,
          y: 0,
        };
        var end = {
          x: 0,
          y: 0,
        };
        var oddArray = [];
        var evenArray = [];

        for (var i = 0; i < data.points.length; i++) {
          if (i % 2 === 0) {
            oddArray.push(data.points[i]);
          } else {
            evenArray.push(data.points[i]);
          }
        }

        var sortedOddArray = oddArray.sort((a, b) => b - a);
        var sortedEvenArray = evenArray.sort((a, b) => b - a);

        start.x = sortedOddArray[sortedOddArray.length - 1];
        start.y = sortedEvenArray[sortedEvenArray.length - 1];

        data.x1 = sortedOddArray[sortedOddArray.length - 1];
        data.y1 = sortedEvenArray[sortedEvenArray.length - 1];

        end.x = sortedOddArray[0];
        end.y = sortedEvenArray[0];

        data.x2 = sortedOddArray[0];
        data.y2 = sortedEvenArray[0];

        this.setState({
          dataArray,
        });
      }

      for (var x = data.x1; x <= data.x2; x++) {
        for (var y = data.y1; y <= data.y2; y++) {
          if (x === data.x1 || x === data.x2 || y === data.y1 || y === data.y2) {
            if (
              x >= startPoint.x &&
              y >= startPoint.y &&
              x >= startPoint.x &&
              y <= endPoint.y &&
              x <= endPoint.x &&
              y >= startPoint.y &&
              x <= endPoint.x &&
              y <= endPoint.y
            ) {
              count++;
              console.log(data.id);
              return null;
            }
          }
        }
      }
    });

    if (count !== 0) {
      this.selectShapes(startPoint.x, startPoint.y);
    }

    this.setState({
      startPoint: {
        x: 0,
        y: 0,
      },
      endPoint: {
        x: 0,
        y: 0,
      },
    });
  };

  selectShapes = (x, y) => {
    this.state.dataArray.map(data => {
      const startPoint = {
        x: data.x1,
        y: data.y1,
      };

      const endPoint = {
        x: data.x2,
        y: data.y2,
      };

      if (
        x >= startPoint.x &&
        y >= startPoint.y &&
        x >= startPoint.x &&
        y <= endPoint.y &&
        x <= endPoint.x &&
        y >= startPoint.y &&
        x <= endPoint.x &&
        y <= endPoint.y
      ) {
        console.log(data.id);
        return null;
      } else if (data.shape === 'line') {
        var points = data.points;
        if (points[0] - 10 <= x && points[2] + 10 >= x && points[1] - 10 <= y && points[3] + 10 >= y) {
          console.log(data.id);
        }
      }
    });
  };

  getMousePosition = stage => {
    return [stage.getPointerPosition().x, stage.getPointerPosition().y];
  };

  render() {
    return (
      <div>
        <Stage
          width={window.innerWidth}
          height={window.innerHeight}
          onMouseDown={this.handleMouseDown}
          onMouseMove={this.handleMouseMove}
          onMouseUp={this.handleMouseUp}
          onClick={this.handleClick}
        >
          <Layer>
            <Rect
              x={this.state.startPoint.x && this.state.startPoint.x}
              y={this.state.endPoint.y && this.state.startPoint.y}
              height={this.state.isFinished ? 0 : this.state.endPoint.y - this.state.startPoint.y}
              width={this.state.isFinished ? 0 : this.state.endPoint.x - this.state.startPoint.x}
              stroke="black"
              strokeWidth={0.5}
              dash={[5, 5]}
            />

            {this.state.dataArray.map(data => {
              switch (data.shape) {
                case 'rect':
                  return (
                    <Rect
                      x={data.x1}
                      y={data.y1}
                      width={data.x2 - data.x1}
                      height={data.y2 - data.y1}
                      stroke="red"
                      scaleX={data.scaleX}
                      strokeWidth={2}
                    />
                  );

                case 'circle':
                  return (
                    <Circle
                      x={data.x1}
                      y={data.y1}
                      width={data.x2 - data.x1}
                      height={data.y2 - data.y1}
                      stroke="red"
                      strokeWidth={2}
                    />
                  );

                case 'line':
                  return <Line points={data.points} stroke="red" strokeWidth={2} />;

                case 'freehand':
                  return <Line points={data.points} stroke="red" strokeWidth={2} scaleX={data.scaleX} />;

                default:
                  break;
              }
            })}
          </Layer>
        </Stage>
      </div>
    );
  }
}

export default Select;
