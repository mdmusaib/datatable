import React from 'react';
import { Text, Rect, Transformer, Group } from 'react-konva';

function GetText(props) {
  const shapeRef = React.useRef();
  const trRef = React.useRef();

  React.useEffect(() => {
    if (props.isSelected) {
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  });

  return (
    <React.Fragment>
      <Group
        ref={shapeRef}
        draggable={true}
        onDragStart={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drag', true)}
        onDragMove={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drag', true)}
        onDragEnd={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drop', false)}
      >
        <Rect x={props.x} y={props.y} ref={shapeRef} height={props.height} width={props.width} stroke={'transparent'} />
        <Text
          text={props.text}
          x={props.x}
          y={props.y}
          fontSize={props.fontSize}
          fontFamily={props.fontFamily}
          fontStyle={props.fontStyle}
          fontVariant={props.fontVariant}
          textDecoration={props.textDecoration}
          align={props.align}
          wrap={props.wrap}
          shape={props.shape}
          id={props.id}
          fill={props.fill}
          width={props.width}
          stroke={props.stroke}
          onMouseEnter={() => (document.body.style.cursor = 'pointer')}
          onMouseLeave={() => (document.body.style.cursor = 'default')}
          onDblClick={() => props.onDblClick(props.id)}
        />
      </Group>
      {props.isSelected && (
        <Transformer
          rotateEnabled={false}
          anchorSize={0}
          ref={trRef}
          // onMouseLeave={() => props.dragStartFalse(false)}
          // onMouseOut={() => props.dragStartFalse(false)}
          boundBoxFunc={(oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
}

export default GetText;
