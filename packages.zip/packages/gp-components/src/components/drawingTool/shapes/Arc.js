import React, { useState } from 'react';
import { Line, Rect } from 'react-konva';
import shapeName from '../common/shapeNameConst';

const FinalArc = props => {
  const {
    x,
    y,
    endX,
    endY,
    dragStartFalse,
    index,
    handleDropLine,
    id,
    stroke,
    strokeWidth,
    handleUpdatedDrag,
    transformEnabled,
    shapeType,
    updateArcEndPoint,
    centerX,
    centerY,
    dragedEndX,
    dragedEndY,
    dragedX,
    dragedY,
    dragedCenterX,
    dragedCenterY,
    finalEndX,
    finalEndY,
    isSelected,
    draggable,
  } = props;
  let start, center, end;
  start = {
    x: dragedX ? dragedX : x,
    y: dragedY ? dragedY : y,
  };
  center = {
    x: dragedCenterX ? dragedCenterX : centerX ? centerX : x + (endX - x) / 2,
    y: dragedCenterY ? dragedCenterY : centerY ? centerY : y + (endY - y) / 2,
  };
  end = {
    x: dragedEndX ? dragedEndX : finalEndX ? finalEndX : endX - x + x,
    y: dragedEndY ? dragedEndY : finalEndY ? finalEndY : endY,
  };

  const [draged, updateDraged] = useState(null);

  const handleMove = (e, type, dragStatus) => {
    switch (type) {
      case 'start':
        updateArcEndPoint(e.x, e.y, index, type);
        break;
      case 'center':
        updateArcEndPoint(e.x, e.y, index, type);
        break;
      case 'end':
        updateArcEndPoint(e.x, e.y, index, type);
        break;
      case 'line':
        if (dragStatus === 'end') {
          handleUpdatedDrag(e, index, 'drag', false);
        } else {
          handleUpdatedDrag(e, index, 'drag', true);
        }
        updateDraged(e);
        break;
      default:
        break;
    }
  };

  let points = [
    draged ? start?.x - draged.x : start?.x,
    draged ? start.y - draged.y : start?.y,
    draged ? center?.x - draged.x : center?.x,
    draged ? center?.y - draged.y : center?.y,
    draged ? end?.x - draged.x : end?.x,
    draged ? end?.y - draged.y : end?.y,
  ];
  if (shapeType === shapeName.LINE) {
    let removed = points.splice(2, 2);
  }

  const handleDragStart = e => {
    handleMove(e.target.attrs, 'line');
  };

  const handleDragMove = e => {
    handleMove(e.target.attrs, 'line');
  };

  const handleDragEnd = e => {
    handleMove(e.target.attrs, 'line', 'end');
    handleDropLine('drop');
  };

  return (
    <React.Fragment>
      <Line
        x={0}
        y={0}
        points={points}
        stroke={stroke || 'black'}
        strokeHitEnabled={10000}
        hitStrokeWidth={20}
        strokeWidth={strokeWidth > 1 ? strokeWidth : 1 || 1}
        tension={shapeType !== 'line' ? 0.6 : false}
        draggable={isSelected || (props.grouped === true && draggable)}
        id={id}
        groupID={props.groupID}
        onMouseEnter={() => (document.body.style.cursor = 'pointer')}
        onMouseLeave={() => (document.body.style.cursor = 'default')}
        onDragStart={e => handleDragStart(e)}
        onDragMove={e => handleDragMove(e)}
        onDragEnd={e => handleDragEnd(e)}
      />
      {isSelected && (
        <Rect
          x={start?.x - 2.5}
          y={start?.y - 2.5}
          height={6}
          width={6}
          stroke={'#5e69ef'}
          fill={'#ffffff'}
          onMouseEnter={() => (document.body.style.cursor = 'nw-resize')}
          onMouseLeave={() => (document.body.style.cursor = 'default')}
          strokeWidth={1}
          draggable={transformEnabled}
          onDragStart={() => dragStartFalse(true)}
          onDragMove={e => handleMove(e.target.attrs, 'start')}
          onDragEnd={() => dragStartFalse(false)}
        />
      )}
      {isSelected && shapeType !== shapeName.LINE && (
        <Rect
          x={center?.x - 2.5}
          y={center?.y - 2.5}
          height={6}
          width={6}
          stroke={'#5e69ef'}
          fill={'#ffffff'}
          onMouseEnter={() => (document.body.style.cursor = 'nw-resize')}
          onMouseLeave={() => (document.body.style.cursor = 'default')}
          strokeWidth={1}
          draggable={transformEnabled}
          onDragStart={() => dragStartFalse(true)}
          onDragMove={e => handleMove(e.target.attrs, 'center')}
          onDragEnd={() => dragStartFalse(false)}
        />
      )}
      {isSelected && (
        <Rect
          x={end?.x - 3.5}
          y={end?.y - 3.5}
          height={6}
          width={6}
          stroke={'#5e69ef'}
          fill={'#ffffff'}
          onMouseEnter={() => (document.body.style.cursor = 'nw-resize')}
          onMouseLeave={() => (document.body.style.cursor = 'default')}
          strokeWidth={1}
          draggable={transformEnabled}
          onDragStart={() => dragStartFalse(true)}
          onDragMove={e => handleMove(e.target.attrs, 'end')}
          onDragEnd={() => dragStartFalse(false)}
        />
      )}
    </React.Fragment>
  );
};

export default FinalArc;
