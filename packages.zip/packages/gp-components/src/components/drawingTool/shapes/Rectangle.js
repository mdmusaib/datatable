import React from 'react';
import { Rect, Transformer } from 'react-konva';

function DrawRectangle(props) {
  const {
    x,
    y,
    endY,
    endX,
    width,
    stroke,
    id,
    handleClick,
    height,
    strokeWidth,
    fill,
    shadowBlur,
    grouped,
    cornerRadius,
    fillLinearGradientColorStops,
    draggable,
    isSelected,
    handleUpdatedDrag,
    index,
    scaleX,
    group,
    dragStartFalse,
    scaleY,
    transformEnabled,
  } = props;
  const shapeRef = React.useRef();
  const trRef = React.useRef();

  React.useEffect(() => {
    if (isSelected) {
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  }, [isSelected]);

  return (
    <React.Fragment>
      <Rect
        ref={shapeRef}
        x={x}
        y={y}
        height={height ? height : endY - y}
        width={width ? width : endX + x}
        stroke={stroke || 'black'}
        strokeWidth={strokeWidth}
        fill={fill}
        fillLinearGradientStartPoint={fillLinearGradientColorStops && { x: 50, y: 50 }}
        fillLinearGradientEndPoint={fillLinearGradientColorStops && { x: 100, y: 100 }}
        fillLinearGradientColorStops={fillLinearGradientColorStops}
        shadowBlur={shadowBlur}
        cornerRadius={cornerRadius}
        draggable={isSelected || (props.grouped === true && draggable)}
        id={id}
        groupID={props.groupID}
        onMouseEnter={() => (document.body.style.cursor = 'pointer')}
        onMouseLeave={() => (document.body.style.cursor = 'default')}
        onClick={() => handleClick}
        onDragStart={e => handleUpdatedDrag(e.target.attrs, index, 'drag', true)}
        onDragMove={e => handleUpdatedDrag(e.target.attrs, index, 'drag', true)}
        onDragEnd={e => handleUpdatedDrag(e.target.attrs, index, 'drop', false)}
        // onTransformStart={e => handleUpdatedDrag(e.target.attrs, index, 'transform', true)}
        onTransformEnd={e => handleUpdatedDrag(e.target.attrs, index, 'transform', true)}
        strokeScaleEnabled={false}
        scaleX={scaleX || 1}
        scaleY={scaleY || 1}
      />
      {isSelected && (
        <Transformer
          rotateEnabled={false}
          anchorSize={5}
          ref={trRef}
          onMouseLeave={() => dragStartFalse(false)}
          onMouseOut={() => dragStartFalse(false)}
          // listening={transformEnabled}
          resizeEnabled={transformEnabled}
          boundBoxFunc={(oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
      {grouped !== undefined && grouped === true && (
        <Transformer
          rotateEnabled={false}
          anchorSize={5}
          ref={trRef}
          // listening={transformEnabled}
          resizeEnabled={transformEnabled}
          boundBoxFunc={(oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
}

export default DrawRectangle;
