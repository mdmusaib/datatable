import React, { Component } from 'react';
import { Line } from 'react-konva';

export class DisplayGrid extends Component {
  constructor(props) {
    super(props);

    this.state = {
      heightPoints: [],
      widthPoints: [],
      points: [],
    };
  }

  componentDidMount() {
    this.drawGrid();
  }

  drawGrid = () => {
    let points = this.state.points;
    let padding = 10;
    let width = 1500;
    let height = window.innerHeight;

    for (let j = 0; j <= height / padding; j++) {
      points.push([0, Math.round(j * padding), width, Math.round(j * padding)]);
    }

    for (let i = 0; i <= width / padding; i++) {
      points.push([Math.round(i * padding), 0, Math.round(i * padding), height]);
    }

    this.setState({
      points,
    });
  };

  render() {
    return (
      <>
        {this.state.points.map(data => {
          return (
            <Line
              points={data}
              stroke={'#181a1b'}
              strokeWidth={(data[0] !== 0 && data[0] % 90 === 0) || (data[1] !== 0 && data[1] % 90) === 0 ? 0.45 : 0.2}
            />
          );
        })}
      </>
    );
  }
}

export default DisplayGrid;
