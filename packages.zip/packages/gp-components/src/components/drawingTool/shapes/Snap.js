import React from 'react';
import { Line, Rect, Group, Transformer, Shape } from 'react-konva';

function DrawSnap(props) {
  const shapeRef = React.useRef();
  const trRef = React.useRef();
  React.useEffect(() => {
    if (props.isSelected) {
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  });

  let oddArray = [];
  let evenArray = [];
  let point = props.points;
  point !== undefined &&
    point.map((value, i) => {
      if (i % 2 === 0) {
        oddArray.push(value);
      } else {
        evenArray.push(value);
      }
    });

  let minY = Math.min(...evenArray);
  let minX = Math.min(...oddArray);
  let maxY = Math.max(...evenArray);
  let maxX = Math.max(...oddArray);

  return (
    <React.Fragment>
      <Group
        draggable={props.draggable}
        ref={shapeRef}
        x={props.dragedX || 0}
        y={props.dragedY || 0}
        scaleX={props.scaleX || 1}
        scaleY={props.scaleY || 1}
        onDragStart={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drag', true)}
        onDragMove={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drag', true)}
        onDragEnd={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drop', false)}
        onTransformEnd={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'transform')}
      >
        <Line
          points={props.points}
          stroke={props.stroke || 'black'}
          strokeWidth={props.strokeWidth || 1}
          height={props.height}
          width={props.width}
          fill={props.fill}
          closed={props.isClosed}
          shadowBlur={props.shadowBlur}
        />
        <Rect x={minX} y={minY} width={maxX - minX} height={maxY - minY} stroke={'transparent'} />
      </Group>
      {props.isSelected && (
        <Transformer
          rotateEnabled={false}
          anchorSize={5}
          ref={trRef}
          resizeEnabled={props.transformEnabled}
          boundBoxFunc={(oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
}

export default DrawSnap;
