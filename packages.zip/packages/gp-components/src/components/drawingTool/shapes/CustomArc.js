import React, { Component } from 'react';
import Konva from 'konva';

export default class DrawArc extends Component {
  state = {
    cords: {
      start: {
        x: 310,
        y: 0,
      },
      center: {
        x: 405,
        y: 0,
      },
      end: {
        x: 500,
        y: 0,
      },
    },
    mouseDown: false,
    drawComplete: false,
  };
  componentDidMount() {
    this.Arc();
  }

  handleMouseDown = e => {
    if (this.state.cords.start.x === null && this.state.cords.start.y === null) {
      this.setState({
        cords: {
          start: {
            x: e.clientX,
            y: e.clientY,
          },
          center: {
            x: e.clientX,
            y: e.clientY,
          },
          end: {
            x: e.clientX,
            y: e.clientY,
          },
        },
        mouseDown: true,
      });
    }
  };

  handleMouseMove = e => {
    if (this.state.mouseDown) {
      this.setState(
        {
          cords: {
            start: {
              x: this.state.cords.start.x,
              y: this.state.cords.start.y,
            },
            center: {
              x: this.state.cords.start.x,
              y: this.state.cords.start.y,
            },
            end: {
              x: e.clientX,
              y: e.clientY,
            },
          },
        },
        () => this.Arc(),
      );
    }
  };

  handleMouseUp = e => {
    if (this.state.mouseDown) {
      this.setState(
        {
          cords: {
            start: {
              x: this.state.cords.start.x,
              y: this.state.cords.start.y,
            },
            center: {
              x: (e.clientX - this.state.cords.start.x) / 2 + this.state.cords.start.x,
              y: (e.clientY - this.state.cords.start.y) / 2 + this.state.cords.start.y,
            },
            end: {
              x: e.clientX,
              y: e.clientY,
            },
          },
          mouseDown: false,
          drawComplete: true,
        },
        () => this.Arc(),
      );
    }
  };

  handleCords = (e, type) => {
    let cords = this.state.cords;

    switch (type) {
      case 'start':
        cords.start = {
          x: e.clientX,
          y: e.clientY,
        };
        break;
      case 'center':
        cords.center = {
          x: e.clientX,
          y: e.clientY,
        };
        break;
      case 'end':
        cords.end = {
          x: e.clientX,
          y: e.clientY,
        };
        break;
      case 'line':
        let width = cords.end.x - cords.start.x;

        cords.start = {
          x: e.clientX - this.state.mouseCords,
          y: e.clientY,
        };

        cords.center = {
          x: e.clientX + width / 2 - this.state.mouseCords,
          y: e.clientY,
        };

        cords.end = {
          x: e.clientX + width - this.state.mouseCords,
          y: e.clientY,
        };
        break;
      default:
        break;
    }

    this.setState(
      {
        cords,
      },
      () => this.Arc(),
    );
  };

  Arc = () => {
    let stage = new Konva.Stage({
      container: 'container',
      width: window.innerWidth,
      height: window.innerHeight,
    });

    let layer = new Konva.Layer();

    let redLine = new Konva.Line({
      points: [
        this.state.cords.start.x,
        this.state.cords.start.y,
        this.state.cords.center.x !== null && this.state.cords.center.x,
        this.state.cords.center.y !== null && this.state.cords.center.y,
        this.state.cords.end.x !== null && this.state.cords.end.x,
        this.state.cords.end.y !== null && this.state.cords.end.y,
      ],
      stroke: 'red',
      strokeWidth: 2,
      tension: 0.6,
      draggable: true,
    });

    let circle1 = new Konva.Circle({
      x: this.state.cords.start.x,
      y: this.state.cords.start.y,
      radius: 5,
      fill: '#fff',
      stroke: 'black',
      strokeWidth: 1,
      draggable: true,
    });

    let circle2 = new Konva.Circle({
      x: this.state.cords.center.x,
      y: this.state.cords.center.y,
      radius: 5,
      fill: '#fff',
      stroke: 'black',
      strokeWidth: 1,
      draggable: true,
    });

    let circle3 = new Konva.Circle({
      x: this.state.cords.end.x,
      y: this.state.cords.end.y,
      radius: 5,
      fill: '#fff',
      stroke: 'black',
      strokeWidth: 1,
      draggable: true,
    });

    redLine.on('dragmove', e => {
      this.handleCords(e.evt, 'line');
    });

    redLine.on('dragstart', e => {
      this.setState({ mouseCords: e.evt.x - this.state.cords.start.x });
    });

    circle1.on('dragmove', e => {
      this.handleCords(e.evt, 'start');
    });

    circle2.on('dragmove', e => {
      this.handleCords(e.evt, 'center');
    });

    circle3.on('dragmove', e => {
      this.handleCords(e.evt, 'end');
    });

    layer.add(redLine);
    this.state.drawComplete && layer.add(circle1, circle2, circle3);
    stage.add(layer);
  };

  render() {
    return (
      <div
        id="container"
        onMouseDown={this.handleMouseDown}
        onMouseMove={this.handleMouseMove}
        onMouseUp={this.handleMouseUp}
      />
    );
  }
}
