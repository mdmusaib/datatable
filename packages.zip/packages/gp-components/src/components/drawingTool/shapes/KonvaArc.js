import React, { Component } from 'react';
import { Circle, Line } from 'react-konva';

export default class SampleArc extends Component {
    constructor(props) {
        super(props);
        this.state = this.initialCordsState(props)
    }

    initialCordsState = (props) => {
        if (props.shapeType !== 'line') {
            return {
                start: {
                    x: props.x,
                    y: props.y,
                },
                center: {
                    x: (props.x + (props.endX - props.x) / 2),
                    y: (props.y + (props.endY - props.y) / 2),
                },
                end: {
                    x: (props.endX - props.x) + props.x,
                    y: props.endY
                },
                drag: false
            }
        } else {
            return {
                start: {
                    x: props.x,
                    y: props.y,
                },
                end: {
                    x: (props.endX - props.x) + props.x,
                    y: props.endY
                },
                drag: false
            }
        }
    }

    static getDerivedStateFromProps(props, state) {
        if (state.end.x !== props.endX && state.end.y !== props.endY) {
            if (props.endType && props.shapeType !== 'line') {
                return {
                    center: {
                        x: (props.x + (props.endX - props.x) / 2),
                        y: (props.y + (props.endY - props.y) / 2),
                    },
                }
            } else {
                return {
                    center: {
                        x: (props.x + (props.endX - props.x) / 2),
                        y: (props.y + (props.endY - props.y) / 2),
                    },
                    end: {
                        x: (props.endX - props.x) + props.x,
                        y: props.endY
                    }
                }
            }
        } else if (props.centerX && props.centerY && props.shapeType !== 'line') {
            return {
                center: {
                    x: props.centerX,
                    y: props.centerY,
                },
            }
        }
    }

    handleMove = (e, type) => {
        if (this.state.drag) {
            switch (type) {
                case "start":
                    this.setState({
                        start: {
                            x: e.x,
                            y: e.y
                        }
                    })
                    break;
                case "center":
                    this.setState({
                        center: {
                            x: e.x,
                            y: e.y
                        }
                    }, () => this.props.updateArcEndPoint(e.x, e.y, this.props.index, type))
                    break;
                case "end":
                    this.setState({
                        end: {
                            x: e.x,
                            y: e.y
                        }
                    }, () => this.props.updateArcEndPoint(e.x, e.y, this.props.index, type, true))
                    break;
                case "line":

                    break;
                default:
                    break;
            }
        }
    }

    handleDrag = value => {
        this.setState({
            drag: value
        })
    }

    render() {
        return (
            <React.Fragment>
                <Line
                    x={0}
                    y={0}
                    points={[this.state.start?.x, this.state.start?.y, this.state.center?.x, this.state.center?.y, this.state.end?.x, this.state.end?.y]}
                    stroke="red"
                    strokeWidth={this.props.strokeWidth}
                    tension={this.props.shapeType !== 'line' ? 0.6 : false}
                    draggable={true}
                    onDragMove={(e) => this.handleMove(e.target.attrs, 'line')}
                    onDragStart={() => this.handleDrag(true)}
                    onDragEnd={() => this.handleDrag(false)}
                />
                <Circle
                    x={this.state.start?.x}
                    y={this.state.start?.y}
                    radius={5}
                    fill={"red"}
                    strokeWidth={1}
                    draggable={true}
                    onDragMove={e => this.handleMove(e.target.attrs, 'start')}
                    onDragStart={() => this.handleDrag(true)}
                    onDragEnd={() => this.handleDrag(false)}
                />
                {this.props.shapeType !== 'line' && <Circle
                    x={this.state.center?.x}
                    y={this.state.center?.y}
                    radius={5}
                    fill={"red"}
                    strokeWidth={1}
                    draggable={true}
                    onDragMove={e => this.handleMove(e.target.attrs, 'center')}
                    onDragStart={() => this.handleDrag(true)}
                    onDragEnd={() => this.handleDrag(false)}
                />}
                <Circle
                    x={this.state.end?.x}
                    y={this.state.end?.y}
                    radius={5}
                    fill={"red"}
                    strokeWidth={1}
                    draggable={true}
                    onDragMove={e => this.handleMove(e.target.attrs, 'end')}
                    onDragStart={() => this.handleDrag(true)}
                    onDragEnd={() => this.handleDrag(false)}
                />
            </React.Fragment>
        );
    }
}