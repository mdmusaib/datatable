import React from 'react';
import { Rect, Group, Transformer, Shape } from 'react-konva';

function DrawPolygon(props) {
  const shapeRef = React.useRef();
  const trRef = React.useRef();

  React.useEffect(() => {
    if (props.isClosed && props.isSelected) {
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  });

  let arrayPoints = [];

  props.points &&
    props.points.map(data => {
      arrayPoints.push(data.x, data.y);
    });

  if (true) {
    var startX = 0;
    var startY = 0;
    var endX = 0;
    var endY = 0;

    var oddArray = [];
    var evenArray = [];

    for (var i = 0; i < arrayPoints.length; i++) {
      if (i % 2 === 0) {
        oddArray.push(arrayPoints[i]);
      } else {
        evenArray.push(arrayPoints[i]);
      }
    }

    var sortedOddArray = oddArray.sort((a, b) => b - a);
    var sortedEvenArray = evenArray.sort((a, b) => b - a);

    startX = sortedOddArray[sortedOddArray.length - 1];
    startY = sortedEvenArray[sortedEvenArray.length - 1];

    endX = sortedOddArray[0];
    endY = sortedEvenArray[0];
  }

  return (
    <React.Fragment>
      <Group
        ref={shapeRef}
        draggable={props.isSelected || (props.grouped === true && props.draggable)}
        x={props.x || startX}
        y={props.y || startY}
        scaleX={props.scaleX || 1}
        scaleY={props.scaleY || 1}
        onDragStart={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drag', true)}
        onDragMove={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drag', true)}
        onDragEnd={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'drop', false)}
        onMouseEnter={() => (document.body.style.cursor = 'pointer')}
        onMouseLeave={() => (document.body.style.cursor = 'default')}
        // onTransformStart={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'transform', true)}
        onTransformEnd={e => props.handleUpdatedDrag(e.target.attrs, props.index, 'transform', true)}
      >
        <Rect x={0} y={0} height={endY - startY} width={endX - startX} stroke={'transparent'} />
        <Shape
          sceneFunc={(context, shape) => {
            context.beginPath();
            props.points && props.points.map((data, i) => context.lineTo(data.x - startX, data.y - startY));
            props.isClosed && context.closePath();
            context.fillStrokeShape(shape);
          }}
          stroke={props.stroke || 'black'}
          strokeScaleEnabled={false}
          strokeWidth={props.strokeWidth || 1}
          fillLinearGradientStartPoint={
            props.fillLinearGradientColorStops && { x: (startX - endX) / 2, y: (startY - endY) / 2 }
          }
          id={props.id}
          groupID={props.groupID}
          onMouseEnter={() => (document.body.style.cursor = 'pointer')}
          onMouseLeave={() => (document.body.style.cursor = 'default')}
          fillLinearGradientEndPoint={props.fillLinearGradientColorStops && { x: endX, y: endY }}
          fillLinearGradientColorStops={props.isClosed && props.fillLinearGradientColorStops}
        />
      </Group>
      {props.isClosed && props.isSelected && (
        <Transformer
          rotateEnabled={false}
          anchorSize={5}
          ref={trRef}
          onMouseLeave={() => props.dragStartFalse(false)}
          onMouseOut={() => props.dragStartFalse(false)}
          resizeEnabled={props.transformEnabled !== undefined && props.transformEnabled}
          boundBoxFunc={(oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
}

export default DrawPolygon;
