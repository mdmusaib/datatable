import React from 'react';
import { Ellipse, Transformer } from 'react-konva';

function DrawEllipse(props) {
  const {
    x,
    y,
    endX,
    endY,
    stroke,
    grouped,
    strokeWidth,
    fill,
    shadowBlur,
    fillLinearGradientColorStops,
    isSelected,
    handleUpdatedDrag,
    index,
    handleClick,
    draggable,
    scaleX,
    scaleY,
    id,
    radiusX,
    radiusY,
    transformEnabled,
    dragStartFalse,
  } = props;
  const shapeRef = React.useRef();
  const trRef = React.useRef();

  React.useEffect(() => {
    if (isSelected) {
      trRef.current.setNode(shapeRef.current);
      trRef.current.getLayer().batchDraw();
    }
  });

  return (
    <React.Fragment>
      <Ellipse
        ref={shapeRef}
        x={radiusX ? x : endX > x ? x + (endX - x) / 2 : x - (x - endX) / 2}
        y={radiusY ? y : endY > y ? y + (endY - y) / 2 : y - (y - endY) / 2}
        height={radiusY ? null : endY > y ? endY - y : y - endY}
        width={radiusX ? null : endX > x ? endX - x : x - endX}
        radiusX={radiusX && radiusX}
        radiusY={radiusY && radiusY}
        id={id}
        groupID={props.groupID}
        stroke={stroke || 'black'}
        strokeWidth={strokeWidth || 2}
        fill={fill}
        fillLinearGradientStartPoint={fillLinearGradientColorStops && { x: -50, y: -50 }}
        fillLinearGradientEndPoint={fillLinearGradientColorStops && { x: 50, y: 50 }}
        fillLinearGradientColorStops={fillLinearGradientColorStops}
        shadowBlur={shadowBlur}
        draggable={isSelected || (props.grouped === true && draggable)}
        onMouseEnter={() => (document.body.style.cursor = 'pointer')}
        onMouseLeave={() => (document.body.style.cursor = 'default')}
        onClick={() => handleClick}
        onDragStart={e => handleUpdatedDrag(e.target.attrs, index, 'drag', true)}
        onDragMove={e => handleUpdatedDrag(e.target.attrs, index, 'drag', true)}
        onDragEnd={e => handleUpdatedDrag(e.target.attrs, index, 'drop', false)}
        // onTransformStart={e => handleUpdatedDrag(e.target.attrs, index, 'transform', true)}
        onTransformEnd={e => handleUpdatedDrag(e.target.attrs, index, 'transform', true)}
        scaleX={scaleX || 1}
        scaleY={scaleY || 1}
        strokeScaleEnabled={false}
      />
      {isSelected && (
        <Transformer
          rotateEnabled={false}
          anchorSize={5}
          ref={trRef}
          // listening={transformEnabled}
          resizeEnabled={transformEnabled}
          onMouseLeave={() => dragStartFalse(false)}
          onMouseOut={() => dragStartFalse(false)}
          boundBoxFunc={(oldBox, newBox) => {
            if (newBox.width < 5 || newBox.height < 5) {
              return oldBox;
            }
            return newBox;
          }}
        />
      )}
    </React.Fragment>
  );
}

export default DrawEllipse;
