import React, { Component } from 'react';
import { Line, Stage, Layer } from 'react-konva';

export default class LineShape extends Component {
  constructor(props) {
    super(props);
    this.state = {
      startPoint: {
        left: 0,
        top: 0,
      },
      endPoint: {
        left: 0,
        top: 0,
      },
      mouseDown: false,
    };
  }

  handleMouseDown = e => {
    this.setState({ startPoint: { top: e.clientY, left: e.clientX }, mouseDown: true });
  };

  handleMouseMove = e => {
    if (this.state.mouseDown) {
      this.setState({ endPoint: { top: e.clientY, left: e.clientX } });
    }
  };

  handleMouseUp = e => {
    if (this.state.mouseDown) {
      this.setState({ mouseDown: false });
    }
  };

  render() {
    return (
      <div onMouseDown={this.handleMouseDown} onMouseMove={this.handleMouseMove} onMouseUp={this.handleMouseUp}>
        <Stage width={window.innerWidth} height={window.innerHeight}>
          <Layer>
            <Line
              x={this.state.endPoint.left && this.state.startPoint.left}
              y={this.state.endPoint.top && this.state.startPoint.top}
              points={[
                0,
                0,
                this.state.endPoint.left - this.state.startPoint.left,
                this.state.endPoint.top - this.state.startPoint.top,
              ]}
              stroke="black"
              strokeWidth="1"
            />
          </Layer>
        </Stage>
      </div>
    );
  }
}
