import React, { Component } from 'react';
import { Container, Col, Row } from 'react-bootstrap';
import styled from '@emotion/styled';
import { StyledElement } from '../../utils/element';
import css from '@styled-system/css';
import { drawingTool } from '../../../tokens/components';
import DrawingToolbar from './drawingToolbar';
import Menu from './menu';
import DrawingArea from './drawingArea';
// import TooltipComponent from '../../Tooltip/tooltip';
import StandardToolbar from './standardToolbar';
import FormattingToolbar from './formattingToolbar';

// import { Tooltip } from '@gp/components';
// import DatePicker from 'react-datepicker';

import 'react-datepicker/dist/react-datepicker.css';
import shapeNameConst from './shapeNameConst';

import { GpModal, SampleMessage, Inputs, Button } from './../../../index';

const StyledDrawingTool = StyledElement('div')(drawingTool);
class DesignerLayout extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeShape: null,
      standard_toolbar: true,
      drawing_toolbar: true,
      formatting_toolbar: true,
      roundedRect: false,
      displayGrid: false,
      overlayDrawing: false,
      alignShape: '',
      showTreeExplorer: props.showExplorer,
      showMsg: false,
      refreshCanvas: false,
      imageSource: null,
      showVerticalSpacing: false,
      verticalSpacingValue: '',
      showHorizontalSpacing: false,
      horizontalSpacingValue: '',
      verticalSpaceValue: '',
      horizontalSpaceValue: '',
    };
  }
  renderLayout = () => <Col md={12}></Col>;

  handleActiveShape = shape => {
    // if (this.state.activeShape === shapeNameConst.SQUARE) {
    //   if (this.state.curveInput === 30) {
    //     this.setState({
    //       curveInput: 0,
    //     });
    //   }
    // }

    if (
      this.state.toolbar !== undefined &&
      this.state.toolbar === false &&
      this.state.activeShape === shapeNameConst.SQUARE
    ) {
      // this.handleProps(1, 'stroke');
      // this.handleProps(0, 'curve');
      console.log('calledSQR');
    }
    this.setState(
      {
        activeShape: this.state.activeShape === 'DISPLAYGRID' ? (shape === 'DISPLAYGRID' ? '' : shape) : shape,
        standardToolbarClickedShape: false,
      },
      () => {
        this.selectedShape(shape);
        this.doEmptyShapeOperations();
      },
    );
    // }
  };

  handleSqaueClick = () => {
    this.setState({
      curveInput: 0,
    });
  };

  alignGridActiveShape = shape => {
    if (this.state.AlignGridActiveShapeName !== shapeNameConst.ALIGNGRID) {
      this.setState({
        AlignGridActiveShapeName: shape,
      });
    } else {
      this.setState({
        AlignGridActiveShapeName: null,
      });
    }
  };
  defaultActiveShape = shape => {
    if (this.state.defaultActiveShapeName !== shapeNameConst.DISPLAYGRID) {
      this.setState({
        defaultActiveShapeName: shape,
      });
    } else {
      this.setState({
        defaultActiveShapeName: null,
      });
    }
  };
  drawRoundedRectangle = shape => {
    console.log(shape);
    // this.setState({
    //   roundedRectangle: !this.state.roundedRect,
    // });
  };

  componentWillReceiveProps(props) {
    console.log('up', props);
    this.setState({
      showTreeExplorer:
        props.showExplorer !== this.state.showTreeExplorer ? !this.state.showTreeExplorer : this.state.showTreeExplorer,
    });
  }
  handleTextOperations = (text, val) => {
    switch (text) {
      case 'fontFamily':
        this.setState(
          {
            fontFamily: val,
          },
          () => this.sendTextProps(text),
        );
        break;
      case 'fontSize':
        this.setState(
          {
            fontSize1: val,
          },
          () => this.sendTextProps(text),
        );
        break;
      case 'foreColor':
        this.setState(
          {
            foreColor: val,
          },
          () => this.sendTextProps(text),
        );
        break;

      case 'bold':
        this.setState(
          {
            fontStyleBold: this.state.fontStyleBold === 'bold' ? 'normal' : 'bold',
            fontStyleItalic: '',
          },
          () => this.sendTextProps(text),
        );
        break;
      case 'italic':
        this.setState(
          {
            fontStyleItalic: this.state.fontStyleItalic === 'italic' ? 'normal' : 'italic',
            fontStyleBold: '',
          },
          () => this.sendTextProps(text),
        );
        break;
      case 'underline':
        this.setState(
          {
            textDecoration: this.state.textDecoration === 'underline' ? 'none' : 'underline',
          },
          () => this.sendTextProps(text),
        );
        break;

      default:
        break;
    }
  };

  sendTextProps = text => {
    let textOperations = {
      FONTFAMILY: { fontFamily: this.state.fontFamily === undefined ? 'verdana' : this.state.fontFamily },
      FORECOLOR: { foreColor: this.state.foreColor === undefined ? 'black' : this.state.foreColor },
      FONTSIZE: { fontSize1: this.state.fontSize1 === undefined ? '15' : this.state.fontSize1 },
      // BOLD: this.state.textOperations?.BOLD === 'false' ? '' : text === 'bold' ? 'true' : '',
      // ITALIC: this.state.textOperations?.ITALIC === 'false' ? '' : text === 'italic' ? 'true' : '',
      // UNDERLINE: this.state.textOperations?.UNDERLINE === 'false' ? '' : text === 'underline' ? 'true' : '',
      BOLD: { bold: this.state.fontStyleBold },
      ITALIC: { italic: this.state.fontStyleItalic },
      UNDERLINE: { underline: this.state.textDecoration },
    };

    this.setState({
      textOperations: textOperations,
    });
  };

  handleClickedShape = shape => {
    if (shape != null || shape !== undefined) {
      let shapeOperations = {
        SAVE: shape === shapeNameConst.SAVE || '',
        SAVEASIMAGE: shape === shapeNameConst.SAVEASIMAGE || '',
        INSERTIMAGE: shape === shapeNameConst.INSERTIMAGE || '',
        PRINT: shape === shapeNameConst.PRINT || '',
        UNDO: shape === shapeNameConst.UNDO || '',
        REDO: shape === shapeNameConst.REDO || '',
        REFRESH: shape === shapeNameConst.REFRESH || '',
        CUT: shape === shapeNameConst.CUT || '',
        COPY: shape === shapeNameConst.COPY || '',
        PASTE: shape === shapeNameConst.PASTE || '',
        DUPLICATE: shape === shapeNameConst.DUPLICATE || '',
        DELETE: shape === shapeNameConst.DELETE || '',
        CLEARALL: shape === shapeNameConst.CLEARALL || '',
        // GROUP: shape === shapeNameConst.GROUP || '',
        UNGROUP: shape === shapeNameConst.UNGROUP || '',
        BRINGTOFRONT: shape === shapeNameConst.BRINGTOFRONT || '',
        SENDTOBACK: shape === shapeNameConst.SENDTOBACK || '',
        NORMAL: shape === shapeNameConst.NORMAL || '',
        ZOOMIN: shape === shapeNameConst.ZOOMIN || '',
        ZOOMOUT: shape === shapeNameConst.ZOOMOUT || '',
        ROUNDED: shape === shapeNameConst.SQUARE || '',
      };

      let shapeAlignment = {
        ALIGNLEFT: shape === shapeNameConst.ALIGNLEFT || '',
        ALIGNRIGHT: shape === shapeNameConst.ALIGNRIGHT || '',
        ALIGNTOP: shape === shapeNameConst.ALIGNTOP || '',
        ALIGNBOTTOM: shape === shapeNameConst.ALIGNBOTTOM || '',
        VERTICALALIGNMIDDLE: shape === shapeNameConst.VERTICALALIGNMIDDLE || '',
        HORIZONTALALIGNCENTER: shape === shapeNameConst.HORIZONTALALIGNCENTER || '',
        VERTICALSPACING: shape === shapeNameConst.VERTICALSPACING || '',
        HORIZONTALSPACING: shape === shapeNameConst.HORIZONTALSPACING || '',
        SIZETOFIT: shape === shapeNameConst.SIZETOFIT || '',
        SIZETHIN: shape === shapeNameConst.SIZETHIN || '',
        SIZEWIDE: shape === shapeNameConst.SIZEWIDE || '',
        SIZESHORT: shape === shapeNameConst.SIZESHORT || '',
        SIZETALL: shape === shapeNameConst.SIZETALL || '',
        TEXTFONT: shape === shapeNameConst.TEXTFONT || '',
        TEXT: shape === shapeNameConst.TEXT || '',
        TEXTFONTSELECT: shape === shapeNameConst.TEXTFONTSELECT || '',
        FONTSIZE: shape === shapeNameConst.FONTSIZE || '',
        FONTSIZESELECT: shape === shapeNameConst.FONTSIZESELECT || '',
        TEXTCOLOR: shape === shapeNameConst.TEXTCOLOR || '',
        TEXTCOLORPICKER: shape === shapeNameConst.TEXTCOLORPICKER || '',
        BOLD: shape === shapeNameConst.BOLD || '',
        ITALIC: shape === shapeNameConst.ITALIC || '',
        UNDERLINE: shape === shapeNameConst.UNDERLINE || '',
        // DISPLAYGRID:
        // ALIGNGRID:
      };
      console.log(this.state);
      this.setState({
        shapeOperations: shapeOperations,
        standardToolbarClickedShape: shape,
        shapeAlignMent: shapeAlignment,
      });
    }
  };

  doEmptyShapeAlignmentOperations = () => {
    let shapeAlignMents = {
      ALIGNLEFT: '',
      ALIGNRIGHT: '',
      ALIGNTOP: '',
      ALIGNBOTTOM: '',
      VERTICALALIGNMIDDLE: '',
      HORIZONTALALIGNCENTER: '',
      VERTICALSPACING: '',
      HORIZONTALSPACING: '',
      SIZETOFIT: '',
      SIZETHIN: '',
      SIZEWIDE: '',
      SIZESHORT: '',
      SIZETALL: '',
      TEXT: '',
      TEXTFONT: '',
      TEXTFONTSELECT: '',
      FONTSIZE: '',
      FONTSIZESELECT: '',
      TEXTCOLOR: '',
      TEXTCOLORPICKER: '',

      BOLD: '',
      ITALIC: '',
      UNDERLINE: '',
      // DISPLAYGRID:
      // ALIGNGRID:
    };
    this.setState({
      shapeAlignMent: shapeAlignMents,
    });
  };
  doEmptyShapeOperations = () => {
    let shapeOperations = {
      SAVE: '',
      SAVEASIMAGE: '',
      INSERTIMAGE: '',
      PRINT: '',
      UNDO: '',
      REDO: '',
      REFRESH: '',
      CUT: '',
      COPY: '',
      PASTE: '',
      DUPLICATE: '',
      DELETE: '',
      CLEARALL: '',
      // GROUP: shape === shapeNameConst.GROUP || '',
      UNGROUP: '',
      BRINGTOFRONT: '',

      SENDTOBACK: '',
      NORMAL: '',
      ZOOMIN: '',
      ZOOMOUT: '',
      ROUNDED: '',
    };
    this.setState({
      shapeOperations: shapeOperations,
    });
  };
  doEmptyTextOperations = textOperations => {
    // let textOperations = {
    //   FONTFAMILY: '',
    //   FORECOLOR: '',
    //   FONTSIZE: '',
    //   BOLD: '',
    //   ITALIC: '',
    //   UNDERLINE: '',
    // };

    console.log('shp', textOperations);

    this.setState({
      textOperations: textOperations,
    });
  };
  selectedShape = shape => {
    // if (shape === shapeNameConst.ROUNDED) {
    //   this.shapeOperationToolbar();
    // }

    // if (this.state.activeShape === shapeNameConst.SELECT || this.state.activeShape === shapeNameConst.SQUARE) {
    //   if (this.state.curveInput === 30) {
    //     shape === shapeNameConst.ROUNDED
    //       ? (document.getElementById('curveInput').value = 30)
    //       : (document.getElementById('curveInput').value = 0);

    //     this.setState({
    //       curveInput: 30,
    //       stroke: 1,
    //     });
    //   } else {
    //     document.getElementById('strokeInput').value = 1;
    //     this.setState({
    //       curveInput: this.state.curveInput !== 0 ? 0 : this.state.curveInput,
    //       stroke: 1,
    //     });
    //     shape === shapeNameConst.ROUNDED
    //       ? (document.getElementById('curveInput').value = 30)
    //       : (document.getElementById('curveInput').value = 0);
    //   }
    // } else {
    //   document.getElementById('strokeInput').value = 1;
    //   this.setState({
    //     stroke: 1,
    //   });
    // }

    switch (this.state.activeShape) {
      case shapeNameConst.ALIGNLEFT:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.ALIGNRIGHT:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.ALIGNTOP:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.ALIGNBOTTOM:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.VERTICALALIGNMIDDLE:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.HORIZONTALALIGNCENTER:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.HORIZONTALSPACING:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.VERTICALSPACING:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.SIZETOFIT:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.SIZETHIN:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.SIZEWIDE:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.SIZETALL:
        this.shapeAlignmentToolbar();
        break;
      case shapeNameConst.SIZESHORT:
        this.shapeAlignmentToolbar();
        break;

      default:
    }
  };
  handleToolbarClickedShape = (shape, toolbar) => {
    console.log(shape, toolbar);

    if (shape === 'standard_toolbar') {
      this.setState({
        standard_toolbar: !this.state.standard_toolbar,
      });
    } else if (shape === 'drawing_toolbar') {
      this.setState({ drawing_toolbar: !this.state.drawing_toolbar });
    } else if (shape === 'formatting_toolbar') {
      this.setState({
        formatting_toolbar: !this.state.formatting_toolbar,
      });
    }
  };
  doCurveEmpty = () => {
    this.setState(
      {
        toolbar: false,
      },
      () => {
        this.handleProps(30, 'curve');
        if (document.getElementById('curveInput')) {
          document.getElementById('curveInput').value = 30;
        }
      },
    );
  };
  handleRoundedRectClicked = toolbar => {
    // console.log('toolbar', toolbar);
    this.setState(
      {
        toolbar: true,
        emptyID: true,
        squareClicked: false,
      },
      () => {
        this.handleProps(30, 'curve');
        this.handleProps(1, 'stroke');
        document.getElementById('strokeInput').value = 1;
        document.getElementById('curveInput').value = 30;
      },
    );
  };

  handleSquareFromMenu = sqaure => {
    this.setState(
      {
        squareClicked: sqaure,
        toolbar: false,
      },
      () => {
        this.handleProps(0, 'curve');
        this.handleProps(1, 'stroke');
        document.getElementById('strokeInput').value = 1;
        document.getElementById('curveInput').value = 0;
      },
    );
  };

  shapeOperationToolbar = () => {
    let shapeOperations = {
      SAVE: this.state.activeShape === shapeNameConst.SAVE || '',
      SAVEASIMAGE: this.state.activeShape === shapeNameConst.SAVEASIMAGE || '',
      INSERTIMAGE: this.state.activeShape === shapeNameConst.INSERTIMAGE || '',
      PRINT: this.state.activeShape === shapeNameConst.PRINT || '',
      UNDO: this.state.activeShape === shapeNameConst.UNDO || '',
      REDO: this.state.activeShape === shapeNameConst.REDO || '',
      REFRESH: this.state.activeShape === shapeNameConst.REFRESH || '',
      CUT: this.state.activeShape === shapeNameConst.CUT || '',
      COPY: this.state.activeShape === shapeNameConst.COPY || '',
      PASTE: this.state.activeShape === shapeNameConst.PASTE || '',
      DUPLICATE: this.state.activeShape === shapeNameConst.DUPLICATE || '',
      DELETE: this.state.activeShape === shapeNameConst.DELETE || '',
      CLEARALL: this.state.activeShape === shapeNameConst.CLEARALL || '',
      GROUP: this.state.activeShape === shapeNameConst.GROUP || '',
      UNGROUP: this.state.activeShape === shapeNameConst.UNGROUP || '',
      BRINGTOFRONT: this.state.activeShape === shapeNameConst.BRINGTOFRONT || '',
      SENDTOBACK: this.state.activeShape === shapeNameConst.SENDTOBACK || '',
      NORMAL: this.state.activeShape === shapeNameConst.NORMAL || '',
      ZOOMIN: this.state.activeShape === shapeNameConst.ZOOMIN || '',
      ZOOMOUT: this.state.activeShape === shapeNameConst.ZOOMOUT || '',
      ROUNDED: this.state.activeShape === shapeNameConst.SQUARE || '',
    };
    this.setState({
      shapeOperations: shapeOperations,
    });
  };
  shapeAlignmentToolbar = () => {
    let alignShape = {
      ALIGNLEFT: this.state.activeShape === shapeNameConst.ALIGNLEFT ? shapeNameConst.ALIGNLEFT : '',
      ALIGNBOTTOM: this.state.activeShape === shapeNameConst.ALIGNBOTTOM ? shapeNameConst.ALIGNBOTTOM : '',
      ALIGNRIGHT: this.state.activeShape === shapeNameConst.ALIGNRIGHT ? shapeNameConst.ALIGNRIGHT : '',
      ALIGNTOP: this.state.activeShape === shapeNameConst.ALIGNTOP ? shapeNameConst.ALIGNTOP : '',
      VERTICALALIGNMIDDLE:
        this.state.activeShape === shapeNameConst.VERTICALALIGNMIDDLE ? shapeNameConst.VERTICALALIGNMIDDLE : '',
      HORIZONTALALIGNCENTER:
        this.state.activeShape === shapeNameConst.HORIZONTALALIGNCENTER ? shapeNameConst.HORIZONTALALIGNCENTER : '',
      HORIZONTALSPACING:
        this.state.activeShape === shapeNameConst.HORIZONTALSPACING ? shapeNameConst.HORIZONTALSPACING : '',
      VERTICALSPACING: this.state.activeShape === shapeNameConst.VERTICALSPACING ? shapeNameConst.VERTICALSPACING : '',
      SIZETOFIT: this.state.activeShape === shapeNameConst.SIZETOFIT ? shapeNameConst.SIZETOFIT : '',
      SIZETHIN: this.state.activeShape === shapeNameConst.SIZETHIN ? shapeNameConst.SIZETHIN : '',
      SIZEWIDE: this.state.activeShape === shapeNameConst.SIZEWIDE ? shapeNameConst.SIZEWIDE : '',
      SIZETALL: this.state.activeShape === shapeNameConst.SIZETALL ? shapeNameConst.SIZETALL : '',
      SIZESHORT: this.state.activeShape === shapeNameConst.SIZESHORT ? shapeNameConst.SIZESHORT : '',
    };

    this.setState({
      displayGrid: this.state.activeShape === 'DISPLAYGRID' ? true : false,
      alignShape: alignShape,
    });
  };

  handleProps = (value, type) => {
    if (type === 'curve') {
      this.setState({
        curveInput: value,
        curveField: 'curve',
      });
    } else {
      this.setState({
        [type]: value,
        colorType: type,
      });
    }
  };

  handleSelectedId = id => {
    if (id === true) {
      this.setState(
        {
          emptyID: true,
        },
        () => {
          // console.log(this.state.selectedId);
        },
      );
    }
  };
  handleRoundedRect = () => {
    if (this.state.roundedRectangle === shapeNameConst.ROUNDED) {
      this.setState({
        roundedRectangle: null,
      });
    } else {
      this.setState({
        roundedRectangle: shapeNameConst.ROUNDED,
      });
    }
  };

  shapeAlignMentDone = () => {
    this.setState({
      alignShape: null,
    });
  };
  handleCloseTabs = () => {
    console.log('called');
    this.setState({
      overlayDrawing: !this.state.overlayDrawing,
    });
  };
  toggle = () => {
    this.component.setOpen(this.focus);
    this.focus = !this.focus;
  };

  drawingAreaResponsive = () => {
    if (this.state.formatting_toolbar === false && this.state.standard_toolbar === false) {
      return '95vh';
    } else if (this.state.formatting_toolbar === false) {
      return '89vh';
    } else if (this.state.standard_toolbar === false) {
      return '90vh';
    } else {
      return '84vh';
    }
  };

  emptyRoundedRectangle = param => {
    this.setState({
      emptyRoundedRect: param,
    });
  };
  // zoomFunClicked = () => {
  //   this.setState({
  //     activeShape: null,
  //   });
  // };

  refreshClicked = () => {
    this.setState({
      showMsg: true,
      activeShape: null,
    });
  };

  yesClicked = () => {
    this.setState(
      {
        refreshCanvas: true,
      },
      () => {
        this.closeModal();
      },
    );
  };

  closeModal = () => {
    this.setState({
      showMsg: false,
      refreshCanvas: false,
      showHorizontalSpacing: false,
      showVerticalSpacing: false,
    });
  };

  handleInsertImageClick = (shape, imageSource) => {
    console.log(shape, imageSource);
    this.setState({
      imageSource: imageSource,
      activeShape: shape,
      standardToolbarClickedShape: false,
    });
  };

  emptySelectdId = val => {
    this.setState({
      emptySelectedId: val,
      emptyID: false,
    });
    console.log('called', this.state.emptySelectedId);
  };

  // showCurveInputField = () => {
  //   alert('called');
  // };

  handleSelectTextAlign = (e, font) => {
    this.setState({
      selectedFontFamilyEvent: e,
      selectedFontFamily: font,
    });
  };

  verticalSpacingClicked = () => {
    this.setState({
      showVerticalSpacing: true,
    });
  };

  horizontalSpacingClicked = () => {
    this.setState({
      showHorizontalSpacing: true,
    });
  };

  verticalSpacingHandler = e => {
    this.setState({
      verticalSpacingValue: e.target.value,
    });
    return this.state.verticalSpacingValue;
  };

  horizontalSpacingHandler = e => {
    this.setState({
      horizontalSpacingValue: e.target.value,
    });
    return this.state.horizontalSpacingValue;
  };

  saveSpacingValue = () => {
    let verticalSpacingValue = this.state.verticalSpacingValue;
    let horizontalSpacingValue = this.state.horizontalSpacingValue;
    this.setState({
      verticalSpaceValue: verticalSpacingValue,
      horizontalSpaceValue: horizontalSpacingValue,
    });
    this.closeModal();
  };

  render() {
    return (
      <>
        <StyledDrawingTool>
          <div className={this.state.overlayDrawing ? 'drawingTool' : ''}>
            <Container fluid={true} style={{ padding: '0px' }}>
              <Row>
                <Col md={12}>
                  <Menu
                    standard_toolbar={this.state.standard_toolbar}
                    drawing_toolbar={this.state.drawing_toolbar}
                    handleActiveShape={this.handleActiveShape}
                    handleSqaueClick={this.handleSqaueClick}
                    emptySelected={this.state.emptySelectedId}
                    emptyRounded={this.state.emptyRoundedRect}
                    handleSquareFromMenu={this.handleSquareFromMenu}
                    activeShape={this.state.activeShape}
                    handleRoundedRectClicked={this.handleRoundedRectClicked}
                    formatting_toolbar={this.state.formatting_toolbar}
                    handleToolbarClickedShape={this.handleToolbarClickedShape}
                    handleSelectedId={this.handleSelectedId}
                    handleProps={this.handleProps}
                    drawRoundedRectangle={this.drawRoundedRectangle}
                    handleClickedShape={this.handleClickedShape}
                    handleInsertImageClick={this.handleInsertImageClick}
                    alignGridActiveShape={this.alignGridActiveShape}
                    defaultActiveShape={this.defaultActiveShape}
                  ></Menu>
                </Col>
                {/* <Col md={12}></Col> */}
                <Col md={12}>
                  <>
                    {this.state.drawing_toolbar === true ? (
                      <DrawingToolbar
                        activeShape={this.state.activeShape}
                        handleActiveShape={this.handleActiveShape}
                        handleProps={this.handleProps}
                        handleSelectedId={this.handleSelectedId}
                        emptySelected={this.state.emptySelectedId}
                        handleRoundedRect={this.handleRoundedRect}
                        {...this.state}
                      ></DrawingToolbar>
                    ) : (
                      this.renderLayout
                    )}
                    {this.state.standard_toolbar === true ? (
                      <StandardToolbar
                        showTreeExplorer={this.state.showTreeExplorer}
                        isLeft={this.state.drawing_toolbar === true ? false : true}
                        handleActiveShape={this.handleActiveShape}
                        handleClickedShape={this.handleClickedShape}
                        handleInsertImageClick={this.handleInsertImageClick}
                      ></StandardToolbar>
                    ) : (
                      this.renderLayout
                    )}
                    {/* formatting toolbar */}
                    {this.state.formatting_toolbar === true ? (
                      <FormattingToolbar
                        showTreeExplorer={this.state.showTreeExplorer}
                        isTop={this.state.standard_toolbar === true ? false : true}
                        isLeft={this.state.drawing_toolbar === true ? false : true}
                        handleSelectTextAlign={this.handleSelectTextAlign}
                        handleTextFontSize={this.handleTextFontSize}
                        activeShape={this.state.activeShape}
                        handleTextOperations={this.handleTextOperations}
                        handleActiveShape={this.handleActiveShape}
                        alignGridActiveShape={this.alignGridActiveShape}
                        handleClickedShape={this.handleClickedShape}
                        defaultActiveShape={this.defaultActiveShape}
                        handleProps={this.handleProps}
                        {...this.state}
                      ></FormattingToolbar>
                    ) : (
                      this.renderLayout
                    )}

                    {/* drawingArea */}
                    <div
                      className="MainDrawingArea"
                      style={{
                        // width: this.state.drawing_toolbar === true ? '91.4%' : '99%',
                        width: 'auto',
                        height: this.drawingAreaResponsive(),
                        overflow: 'auto',
                        position: 'relative',
                        marginTop: '0px',
                        //background: '#DCDCDC',
                        marginLeft: this.state.drawing_toolbar === true ? '85px' : '5px',
                      }}
                    >
                      <Col md={12} className="canvasStyle">
                        <DrawingArea
                          emptySelectdId={this.emptySelectdId}
                          handleCloseTabs={this.handleCloseTabs}
                          {...this.state}
                          handleProps={this.handleProps}
                          doCurveEmpty={this.doCurveEmpty}
                          doEmptyShapeOperations={this.doEmptyShapeOperations}
                          doEmptyTextOperations={this.doEmptyTextOperations}
                          handleRoundedRectClicked={this.handleRoundedRectClicked}
                          doEmptyShapeAlignmentOperations={this.doEmptyShapeAlignmentOperations}
                          shapeAlignMentDone={this.shapeAlignMentDone}
                          // zoomFunClicked={this.zoomFunClicked}
                          refreshClicked={this.refreshClicked}
                          emptyRoundedRectangle={this.emptyRoundedRectangle}
                          handleClickedShape={this.handleClickedShape}
                          horizontalSpacingClicked={this.horizontalSpacingClicked}
                          verticalSpacingClicked={this.verticalSpacingClicked}
                        ></DrawingArea>
                      </Col>
                    </div>
                  </>
                </Col>
              </Row>
            </Container>
          </div>
        </StyledDrawingTool>
        <GpModal
          FormatModal={false}
          show={this.state.showMsg}
          //backdropClicked={this.closeModal}
          title="Warning"
          closeClicked={this.closeModal}
          modalWidth="25%"
          modalHeight="25%"
        >
          <SampleMessage
            yesClicked={this.yesClicked}
            noClicked={this.closeModal}
            message="You will lose all of your local changes, do you want to continue?"
            iconName="drawingToolIcons.warning"
          />
        </GpModal>
        <GpModal
          FormatModal={false}
          show={this.state.showVerticalSpacing || this.state.showHorizontalSpacing}
          //backdropClicked={this.closeModal}
          title={
            this.state.showVerticalSpacing ? (
              'Vertical Space'
            ) : this.state.showHorizontalSpacing ? (
              'Horizontal Spacing'
            ) : (
              <></>
            )
          }
          closeClicked={this.closeModal}
          modalWidth="20%"
          modalHeight="20%"
        >
          <>
            <div style={{ width: '80%', margin: '0 auto', display: 'flex', paddingTop: '7px', height: '60px' }}>
              {this.state.showHorizontalSpacing ? (
                <Inputs
                  name="horizontalSpace"
                  elementType="InputField"
                  elementConfig={{
                    placeholder: 'Space in pixels',
                    inputType: 'string',
                    type: 'Number',
                  }}
                  value={this.state.horizontalSpacingValue}
                  valid={false}
                  touched={false}
                  validation={{
                    required: false,
                    pattern: /^[0-9]*$/,
                    message: 'test abcd abcd acbd test',
                  }}
                  changed={e => this.horizontalSpacingHandler(e)}
                />
              ) : this.state.showVerticalSpacing ? (
                <Inputs
                  name="spaceinpixels"
                  elementType="InputField"
                  elementConfig={{
                    placeholder: 'Space in pixels',
                    inputType: 'string',
                    type: 'Number',
                  }}
                  value={this.state.verticalSpacingValue}
                  valid={false}
                  touched={false}
                  validation={{
                    required: false,
                    pattern: /^[0-9]*$/,
                    message: 'test abcd abcd acbd test',
                  }}
                  changed={e => this.verticalSpacingHandler(e)}
                />
              ) : (
                <></>
              )}
            </div>
            <div style={{ width: '80%', margin: '0 auto', display: 'flex', justifyContent: 'center' }}>
              <Button onButtonClick={this.saveSpacingValue} style={{ marginRight: '8px' }}>
                OK
              </Button>
              <Button onButtonClick={this.closeModal} variant="secondary">
                Close
              </Button>
            </div>
          </>
        </GpModal>
      </>
    );
  }
}

export default DesignerLayout;
