import React, { Component } from 'react';
import styled from '@emotion/styled';
import { StyledElement } from '../../utils/element';
import Icon from '../../icons/Icon';
import css from '@styled-system/css';
import shapeName from './shapeNameConst';
// import designerLayout from '../../../tokens/components/gpDesignerLayout';
// import { menu as designerMenu } from '../../../tokens/components/';
import { formattingToolbarStyle } from '../../../tokens/components/';
import { Form } from 'react-bootstrap';
import '../../../tokens/components/caretStyle.css';
const StyledFormattingToolbar = StyledElement('div')(formattingToolbarStyle);

class FormattingToolbar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data1: [
        {
          shapeName: shapeName.ALIGNLEFT,
          title: 'alignLeft',
          src: 'drawingToolIcons.alignLeft',
          icon: 'shape3s',
          className: 't321hird',
        },
        {
          shapeName: shapeName.ALIGNRIGHT,
          title: 'alignRight',
          src: 'drawingToolIcons.alignRight',
          icon: 'shape321s',
          className: 'thi321rd',
        },
        {
          shapeName: shapeName.ALIGNTOP,
          title: 'alignTop',
          src: 'drawingToolIcons.alignTop',
          icon: 'shape321s',
          className: 'thi321rd vl',
        },
        {
          shapeName: shapeName.ALIGNBOTTOM,
          title: 'alignBottom',
          src: 'drawingToolIcons.alignbottom',
          icon: 'shape321s',
          className: 'thi321rd vl',
        },
        {
          shapeName: shapeName.VERTICALALIGNMIDDLE,
          title: 'verticalAlignMiddle',
          src: 'drawingToolIcons.verticalAlignMiddle',
          icon: 'shape43s',
          className: 'th42ird',
        },
        {
          shapeName: shapeName.HORIZONTALALIGNCENTER,
          title: 'Horizontal Align Middle',
          src: 'drawingToolIcons.horizontalAlignCenter',
          icon: 'shape321s',
          className: 'thi321rd ',
        },

        {
          shapeName: shapeName.VERTICALSPACING,
          title: 'Verticle Spacing',
          src: 'drawingToolIcons.verticalSpacing',
          icon: 'shape321s',
          className: 'thi321rd vl ',
        },
        {
          shapeName: shapeName.HORIZONTALSPACING,
          title: 'Horizontal Spacing',
          src: 'drawingToolIcons.horizontalSpacing',
          icon: 'shape321s',
          className: 'thi321rd ',
        },
        {
          shapeName: shapeName.SIZETOFIT,
          title: 'sizeToFit',
          src: 'drawingToolIcons.sizeToFit',
          icon: 'shapes43',
          className: 'thir434d vl',
        },
        {
          shapeName: shapeName.SIZETHIN,
          title: 'sizeThin',
          src: 'drawingToolIcons.sizeThin',
          icon: 'shapes',
          className: 'third',
        },
        // {
        //   shapeName: shapeName.SIZEWIDE,
        //   title: 'sizeWide',
        //   src: 'drawingToolIcons.sizeWide',
        //   icon: 'shapes',
        //   className: 'third',
        // },
        {
          shapeName: shapeName.SIZESHORT,
          title: 'sizeShort',
          src: 'drawingToolIcons.sizeShort',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: shapeName.SIZETALL,
          title: 'sizeTall',
          src: 'drawingToolIcons.sizeTall',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: shapeName.SIZEWIDE,
          title: 'sizeWide',
          src: 'drawingToolIcons.sizeWide',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: shapeName.TEXTFONT,
          title: 'Text Font',
          src: 'drawingToolIcons.textFont',
          icon: 'shapes',
          className: 'third vl',
        },
        // {
        //   shapeName: shapeName.TEXTFONTSELECT,
        //   title: 'Text Font',
        //   src: 'drawingToolIcons.',
        //   icon: '',
        //   className: '',
        // },
        {
          shapeName: shapeName.FONTSIZE,
          title: 'FontSize',
          src: 'drawingToolIcons.fontSize',
          icon: 'shapes',
          className: 'third',
        },
        // {
        //   shapeName: shapeName.FONTSIZESELECT,
        //   title: 'FontSize',
        //   src: 'drawingToolIcons.fontSize',
        //   icon: 'shapes',
        //   className: 'third',
        // },

        {
          shapeName: shapeName.TEXTCOLORPICKER,
          title: 'Text Color',
          src: 'drawingToolIcons.textColor',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: shapeName.BOLD,
          title: 'Bold',
          src: 'drawingToolIcons.bold',
          icon: 'shapes',
          className: 'third vl',
        },
        {
          shapeName: shapeName.ITALIC,
          title: 'Italic',
          src: 'drawingToolIcons.italic',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: shapeName.UNDERLINE,
          title: 'Underline',
          src: 'drawingToolIcons.underline',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: shapeName.DISPLAYGRID,
          title: 'DisplayGrid',
          src: 'drawingToolIcons.alignGrid',
          icon: 'shapes',
          className: 'third vl',
        },
      ],
      fontFamilyArray: [
        'Arial',
        'Courier',
        'Courier New',
        'Geneva',
        'Georgia',
        'Helvetica',
        'Times New Roman',
        'Times',
        'Verdana',
      ],
      showFontFamilyList: false,
      showFontSizeList: false,
      selectedFontFamily: 'Verdana',
      selectedFontSizeList: 8,
    };
  }
  handleClick = shape => {
    console.log('called', shape);
    if (shape === shapeName.BOLD) {
      this.props.handleTextOperations('bold', true);
    }
    if (shape === shapeName.ITALIC) {
      this.props.handleTextOperations('italic', true);
    }
    if (shape === shapeName.UNDERLINE) {
      this.props.handleTextOperations('underline', true);
    }
    // this.props.handleActiveShape(shape);
    this.props.handleClickedShape(shape);
  };
  handleDisplayGrid = shape => {
    this.props.defaultActiveShape(shape);
  };
  handleAlignGrid = shape => {
    this.props.alignGridActiveShape(shape);
  };
  handleChange = event => {
    event.target.setAttribute('size', 1);
    console.log(event.target.blur());
  };
  handleOpen = e => {
    e.preventDefault();
    e.target.blur();
    // window.focus();
    this.setState({
      showFontFamilyList: !this.state.showFontFamilyList,
    });
  };
  handleSelectedFontFamily = (e, font) => {
    this.setState(
      {
        selectedFontFamilyEvent: e,
        selectedFontFamily: font,
      },
      () => {
        this.setState(
          {
            showFontFamilyList: !this.state.showFontFamilyList,
          },
          () => {
            this.props.handleTextOperations('fontFamily', this.state.selectedFontFamily);
          },
        );
      },
    );
  };

  handleSelectedFontSizeList = font => {
    this.setState(
      {
        selectedFontSizeList: font,
      },
      () => {
        this.setState(
          {
            showFontSizeList: !this.state.showFontSizeList,
          },
          () => {
            this.props.handleTextOperations('fontSize', this.state.selectedFontSizeList);
          },
        );
      },
    );
  };
  genereateFontSizeNumbers = () => {
    let fontSizeNo = [];
    for (var i = 5; i <= 72; i++) fontSizeNo.push(i);
    return fontSizeNo;
  };
  handleOpenFontSize = e => {
    e.preventDefault();
    e.target.blur();
    // window.focus();
    this.setState(
      {
        showFontSizeList: !this.state.showFontSizeList,
      },
      () => {},
    );
  };

  handleMouseOut = () => {
    console.log('clg');
  };
  handleBlurFontFamily = e => {
    e.preventDefault();
    e.target.blur();
    // window.focus();
    this.setState({
      showFontFamilyList: !this.state.showFontFamilyList,
    });
  };
  handleBlurFontSize = e => {
    e.preventDefault();
    e.target.blur();
    // window.focus();
    this.setState({
      showFontSizeList: !this.state.showFontSizeList,
    });
  };

  handleChangeColor = (e, type) => {
    // this.props.handleProps(e.target.value, type);
    this.props.handleTextOperations('foreColor', e.target.value);
  };
  render() {
    return (
      <StyledFormattingToolbar className="formattingToolbarHead" {...this.props}>
        <div className="formattingToolbar" style={{ marginLeft: this.props.drawing_toolbar === false ? '0px' : '5px' }}>
          {this.state.data1.map(data =>
            data.shapeName === shapeName.TEXTFONTSELECT ||
            data.shapeName === shapeName.FONTSIZESELECT ||
            data.shapeName === shapeName.TEXTCOLORPICKER ? (
              <div>
                <Form>
                  {data.shapeName === shapeName.FONTSIZESELECT ? (
                    <>
                      <div
                        style={{
                          marginLeft: '10px',
                          position: 'relative',
                          flexDirection: 'row',
                          display: 'flex',
                          /* justify-content: center; */
                          alignItems: 'center',
                          justifyItems: 'center',
                        }}
                      >
                        <Icon
                          icon="drawingToolIcons.fontSize"
                          title={data.shapeName}
                          style={{ margin: '0px 5px 0px 5px' }}
                          onClick={e => this.handleClick(data.shapeName)}
                        />
                        {/* <Form.Control
                          title={data.shapeName}
                          as="select"
                          autoComplete="off"
                          className="fontSizeInputs"
                          custom
                          size="0"
                          onClick={this.handleOpenFontSize}
                        > */}
                        <input
                          type="text"
                          title={data.shapeName}
                          className="fontSizeInputs"
                          value={this.state.selectedFontSizeList}
                        />
                        <div className="caret_icon" onClick={this.handleOpenFontSize}></div>
                        {/* <option>
                          {this.state.selectedFontSizeList != null ? '' : 'this.genereateFontSizeNumbers()[3]'}
                        </option> */}

                        {this.state.showFontSizeList && (
                          <ul
                            class="fontSize-menu"
                            onMouseLeave={e => {
                              this.handleBlurFontSize(e);
                            }}
                          >
                            {this.genereateFontSizeNumbers().map(t => (
                              <li
                                key={t}
                                className={this.state.selectedFontSizeList === t ? 'selectedFont' : 'unselectedFont'}
                                onClick={() => {
                                  this.handleSelectedFontSizeList(t);
                                }}
                              >
                                {t}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </>
                  ) : data.shapeName === shapeName.TEXTCOLORPICKER ? (
                    <>
                      <div
                        style={{
                          marginLeft: '10px',
                          position: 'relative',
                          flexDirection: 'row',
                          display: 'flex',
                          /* justify-content: center; */
                          alignItems: 'center',
                          justifyItems: 'center',
                        }}
                      >
                        <Icon
                          icon="drawingToolIcons.textColor"
                          title={data.shapeName}
                          style={{ margin: '0px 5px 0px 5px' }}
                          onClick={e => this.handleClick(data.shapeName)}
                        />
                        <input
                          type="color"
                          title={data.shapeName}
                          ref={data.shapeName}
                          list={shapeName.TEXTCOLORPICKER}
                          style={{
                            backgroundColor: 'transparent',
                            marginLeft: '-10px',
                            marginTop: '0px',
                          }}
                          className="textColorPicker"
                          onChange={e => this.handleChangeColor(e, data.shapeName)}
                        />
                        <datalist id={shapeName.TEXTCOLORPICKER}>
                          <option>red</option>
                          <option>blue</option>
                          <option>green</option>
                          <option>yellow</option>
                          <option>orange</option>
                          <option>white</option>
                          <option>black</option>
                        </datalist>
                      </div>
                    </>
                  ) : (
                    <>
                      <div
                        style={{
                          borderLeft: '1px solid #ccc',
                          height: '30px',
                          position: 'relative',
                          flexDirection: 'row',
                          display: 'flex',
                          /* justify-content: center; */
                          alignItems: 'center',
                          justifyItems: 'center',
                        }}
                      >
                        <Icon
                          icon="drawingToolIcons.textFont"
                          title={data.shapeName}
                          style={{ margin: '0px 5px 0px 5px' }}
                          onClick={e => this.handleClick(data.shapeName)}
                        />
                        {/* <Form.Control
                          title={data.shapeName}
                          as="select"
                          className="selectInput"
                          custom
                          size="0"
                          onClick={this.handleOpen}
                        >
                          <option>
                            {this.state.selectedFontFamily != null
                              ? this.state.selectedFontFamily
                              : this.state.fontFamilyArray[8]}
                          </option>
                        </Form.Control> */}
                        <input
                          type="text"
                          title={data.shapeName}
                          className="selectInput"
                          value={this.state.selectedFontFamily}
                        />
                        <div className="caret_icon" onClick={this.handleOpen}></div>

                        {this.state.showFontFamilyList && (
                          <ul
                            class="sub-menu"
                            onMouseLeave={e => {
                              this.handleBlurFontFamily(e);
                            }}
                          >
                            {this.state.fontFamilyArray.map(t => (
                              <li
                                key={t}
                                className={this.state.selectedFontFamily === t ? 'selectedInput' : 'unselected'}
                                onClick={e => {
                                  this.handleSelectedFontFamily(e, t);
                                }}
                              >
                                {t}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </>
                  )}
                </Form>
              </div>
            ) : data.shapeName !== shapeName.DISPLAYGRID ? (
              <span
                title={data.shapeName}
                style={{ marginLeft: data.title === 'Bold' ? '-18px' : '' }}
                className={data.className}
                onClick={e => this.handleClick(data.shapeName)}
              >
                <Icon icon={data.src} />
              </span>
            ) : (
              <></>
            ),
          )}

          <span title={shapeName.DISPLAYGRID} onClick={e => this.handleDisplayGrid(shapeName.DISPLAYGRID)}>
            <Icon
              icon="drawingToolIcons.alignGrid"
              className={this.props.defaultActiveShapeName === shapeName.DISPLAYGRID ? 'hoverDisplayGrid ' : ''}
            />
          </span>
          <span title={shapeName.ALIGNGRID} className="" onClick={e => this.handleAlignGrid(shapeName.ALIGNGRID)}>
            <Icon icon="drawingToolIcons.alignGrid" />
          </span>
        </div>
      </StyledFormattingToolbar>
    );
  }
}

export default FormattingToolbar;
