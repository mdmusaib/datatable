import React, { Component } from 'react';
import styled from '@emotion/styled';
import Element from '../../utils/element';
import Icon from '../../icons/Icon';
import css from '@styled-system/css';
// import designerLayout from '../../../tokens/components/gpDesignerLayout';
// import { menu as designerMenu } from '../../../tokens/components/';
import { layout as designerLayout } from '../../../tokens/components/';
import shapeNameConst from './shapeNameConst';
const StyledStandardToolbar = styled(Element)(props => css(designerLayout(props)));
class StandardToolbar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data1: [
        {
          shapeName: shapeNameConst.SAVE,
          title: 'Save',
          src: 'floppyDisk',
          type: 'svg',
          icon: 'shape3s',
          className: 't321hird',
          catagory: 'standardTools',
        },
        {
          shapeName: shapeNameConst.SAVEASIMAGE,
          title: 'Save as Image',
          src: 'saveImageAS',
          type: 'svg',
          icon: 'shape321s',
          catagory: 'standardTools',
          className: 'thi321rd',
        },
        {
          shapeName: shapeNameConst.INSERTIMAGE,
          title: 'Insert Image',
          src: 'insertImage',
          type: 'svg',
          icon: 'shape321s',
          catagory: 'standardTools',
          className: 'thi321rd ',
        },
        {
          shapeName: shapeNameConst.PRINT,
          title: 'Print',
          src: 'printer',
          type: 'svg',
          icon: 'shape321s',
          catagory: 'standardTools',
          className: '',
        },
        {
          shapeName: shapeNameConst.UNDO,
          title: 'undo',
          src: 'undo',
          type: 'svg',
          icon: 'shape321s',
          catagory: 'standardTools',
          className: 'undo vl ',
        },
        {
          shapeName: shapeNameConst.REDO,
          title: 'redo',
          src: 'redo',
          type: 'svg',
          icon: 'shape321s',
          catagory: 'standardTools',
          className: 'redo ',
        },

        {
          shapeName: shapeNameConst.REFRESH,
          title: 'refresh',
          src: 'multimedia',
          type: 'svg',
          icon: 'shape43s',
          catagory: 'standardTools',
          className: 'refresh th42ird',
        },
        {
          shapeName: shapeNameConst.CUT,
          title: 'cut',
          src: 'cut',
          type: 'svg',
          icon: 'shapes43',
          catagory: 'standardTools',
          className: 'thir434d vl',
        },
        {
          shapeName: shapeNameConst.COPY,
          title: 'copy',
          src: 'file1',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third',
        },
        {
          shapeName: shapeNameConst.PASTE,
          title: 'paste',
          src: 'paste',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third',
        },
        {
          shapeName: shapeNameConst.DUPLICATE,
          title: 'duplicate',
          src: 'duplicate',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third ',
        },
        {
          shapeName: shapeNameConst.DELETE,
          title: 'delete',
          src: 'delete',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third vl',
        },
        {
          shapeName: shapeNameConst.CLEARALL,
          title: 'clear ',
          src: 'clearAll',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third',
        },
        {
          shapeName: shapeNameConst.GROUP,
          title: 'group',
          src: 'group',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third vl',
        },
        {
          shapeName: shapeNameConst.UNGROUP,
          title: 'ungroup',
          src: 'unGroup',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third',
        },
        {
          shapeName: shapeNameConst.BRINGTOFRONT,
          title: 'bringTofront',
          src: 'bringToFront',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third vl',
        },
        {
          shapeName: shapeNameConst.SENDTOBACK,
          title: 'Send to Back',
          src: 'sendToBack',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third',
        },
        {
          shapeName: shapeNameConst.NORMAL,
          title: 'normal',
          src: 'zoomReset',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third vl',
        },
        {
          shapeName: shapeNameConst.ZOOMIN,
          title: 'zoomin',
          src: 'zoomIn',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third ',
        },
        {
          shapeName: shapeNameConst.ZOOMOUT,
          title: 'zoomout',
          src: 'zoomOut',
          type: 'svg',
          icon: 'shapes',
          catagory: 'standardTools',
          className: 'third',
        },
      ],
      standardToolbarClickedShape: false,
      imageSource: null,
    };
  }

  handleClick = shape => {
    if (shape === shapeNameConst.GROUP) {
      this.setState(
        {
          standardToolbarClickedShape: !this.props.standardToolbarClickedShape,
        },
        () => {
          this.props.handleClickedShape(this.state.standardToolbarClickedShape);
        },
      );
    } else {
      this.props.handleClickedShape(shape);
    }
    if (shape === shapeNameConst.INSERTIMAGE) {
      this.upload.click();
    }
  };

  handleInsertImageClick = (event, shape) => {
    event.stopPropagation();
    event.preventDefault();
    let imageSource = null;
    let file = event.target.files;
    [...file].map(file => {
      imageSource = URL.createObjectURL(file);
    });
    console.log(imageSource);
    this.props.handleInsertImageClick(shape, imageSource);

    // this.setState({
    //     imageSource
    // })

    //console.log('--------', this.state.imageSource);
    console.log('--------', imageSource);
    // this.props.handleInsertImageClick(shape, imageSource);
    //this.props.handleActiveShape(shape);
  };

  render() {
    // console.log(document.getElementsByClassName('refresh'));
    return (
      <StyledStandardToolbar
        {...this.props}
        style={{
          marginLeft: this.props.isLeft ? '5px' : '85px',
          background: '#F2F2F2',
          borderTop: '1px solid #fff',
          borderBottom: '1px solid #ccc',
          borderLeft: '1px solid #fff',
          display: 'flex',
          alignItems: 'center',
          height: '35px',
          width: this.props.isLeft ? '99.2%' : this.props.showTreeExplorer === false ? '92.6%' : '91.4%',
          borderTopLeftRadius: '10px',
          borderTopRightRadius: '10px',
        }}
      >
        <div className="standardToolbar">
          {this.state.data1.map(data => (
            <button>
              <span title={data.shapeName} className={data.className} onClick={e => this.handleClick(data.shapeName)}>
                {data.shapeName === shapeNameConst.INSERTIMAGE ? (
                  <>
                    <Icon
                      svgIconColor="grey_32"
                      type={data.type}
                      width="19"
                      height="19"
                      icon={data.src}
                      // className={this.state.activeShape === data.shapeName ? 'currentShape' : ''}
                    />
                    <input
                      type="file"
                      id="img"
                      ref={ref => (this.upload = ref)}
                      style={{ display: 'none' }}
                      onChange={e => this.handleInsertImageClick(e, data.shapeName)}
                    />
                  </>
                ) : (
                  <Icon
                    svgIconColor="grey_32"
                    type={data.type}
                    width="19"
                    height="19"
                    icon={data.src}
                    // className={this.state.activeShape === data.shapeName ? 'currentShape' : ''}
                  />
                )}
              </span>
            </button>
          ))}
        </div>
      </StyledStandardToolbar>
    );
  }
}

export default StandardToolbar;
