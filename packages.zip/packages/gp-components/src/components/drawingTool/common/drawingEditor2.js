import React, { Component } from 'react';
import DrawRectangle from '../shapes/Rectangle';
import { Stage, Layer, Rect, Image, Text, Transformer } from 'react-konva';
import DrawEllipse from '../shapes/Ellipse';
import DrawSector from '../shapes/Sector';
import DrawPolygon from '../shapes/Polygon';
import shapeName from './shapeNameConst';
import Pencil from '../shapes/Pencil';
import FinalArc from '../shapes/Arc';
import DisplayGrid from '../shapes/DisplayGrid';
import shapeNameConst from './shapeNameConst';
import DrawSnap from '../shapes/Snap';
import html2canvas from 'html2canvas';
import GetText from '../shapes/GetText';
import { object } from 'prop-types';

class DrawingEditor extends Component {
  constructor(props) {
    super(props);
    this.state = {
      currentShape: '',
      selectedId: [],
      dragStart: false,
      displayGridComponent: <DisplayGrid {...this.props} />,
      shapeHistory: false,
      shapeCords: [
        // {
        //   id: 'Text_1',
        //   x: 114,
        //   y: 98,
        //   isSelected: false,
        //   draggable: false,
        //   transformEnabled: false,
        //   endX: 238,
        //   endY: 148,
        //   height: 50,
        //   width: 124,
        //   textValue: 'cbbxcbnxcbncxcx\nsdhjdsbds',
        //   textXPosition: 114,
        //   textYPosition: 98,
        //   shape: 'Text',
        //   fontSize: 15,
        //   fontFamily: 'Calibri',
        // },
      ],
      baseCanvas: null,
      startPoint: {
        x: null,
        y: null,
      },
      endPoint: {
        x: null,
        y: null,
      },
      startingPoint: {
        x: null,
        y: null,
      },
      endingPoint: {
        x: null,
        y: null,
      },
      points: [],
      alignShape: null,
      data: {},
      isFinished: false,
      isSelect: false,
      lineColor: '#000000',
      fillColour: 'transparent',
      // gradientFillColour: 'transparent',
      polygonCount: 0,
      curve: 0,
      displayGrid: false,
      historyStep: 0,
      groupCount: 0,
      verticalSpacing: 50,
      horizontalSpacing: 50,
      selectedShapeCordsToCopy: [],
      historyCords: [[]],
      scaleWidth: 0,
      alignToGrid: true,
      scaleHeight: 0,
      refreshClicked: false,
      polygonStart: false,
      textOperations: null,
      fontSize: 15,
      fontFamily: 'Calibri',
    };
  }

  static getDerivedStateFromProps(props, state) {
    if (props) {
      return {
        ...props,
      };
    }
  }

  componentDidUpdate(prevProps, prevState) {
    this.state.selectedId.length > 0 && this.handleShapeColours(prevState);

    if (this.state.emptyID !== prevState.emptyID && this.state.emptyID === true) {
      this.setState(
        {
          selectedId: [],
        },
        () => {
          if (this.state.activeShape === shapeName.SQUARE) {
            document.getElementById('strokeInput').value = 1;
            document.getElementById('curveInput').value = 0;
          }
          if (
            this.state.activeShape === shapeName.SQUARE ||
            this.state.activeShape === shapeName.CIRCLE ||
            this.state.activeShape === shapeName.SECTOR ||
            this.state.activeShape === shapeName.POLYGON ||
            this.state.activeShape === shapeName.LINE ||
            this.state.activeShape === shapeName.ARC
          ) {
            this.props.doCurveEmpty();
            this.props.handleProps(1, 'stroke');
            this.props.handleProps(0, 'curve');
            document.getElementById('strokeInput').value = 1;
          }
        },
      );
    }
    if (this.state.toolbar !== undefined && this.state.toolbar === true) {
      if (this.state.activeShape === shapeName.SQUARE) {
        console.log('rounded');
        // document.getElementById('curveInput').value = 30;
      }
      // this.setState(
      //   {
      //     curveInput: 30,
      //   },
      //   () => {
      //     // this.props.doCurveEmpty();
      //   },
      // );
      // this.state.curveInput = 30;
    }

    if (this.state.squareClicked !== undefined && this.state.squareClicked === true) {
      if (this.state.activeShape === shapeName.SQUARE) {
        // document.getElementById('curveInput').value = 0;
      }
      // this.setState(
      //   {
      //     curveInput: 30,
      //   },
      //   () => {
      //     // this.props.doCurveEmpty();
      //   },
      // );
      // this.state.curveInput = 0;
    }

    if (
      this.state.shapeCords.length > 0 &&
      this.state.activeShape === shapeName.TRANSFORM &&
      this.state.activeShape !== prevState.activeShape
    ) {
      let cords = this.state.shapeCords;
      let selectedShape = this.state.selectedId;
      cords
        .filter(list => selectedShape.includes(list.id))
        .map(shape => {
          shape.transformEnabled = true;
        });
      this.setState({ shapeCords: cords, initialSelect: false });
    }

    this.state.activeShape !== shapeName.SELECT &&
      this.state.activeShape !== shapeName.TRANSFORM &&
      this.state.shapeHistory &&
      prevState.shapeHistory !== this.state.shapeHistory &&
      this.state.activeShape !== shapeName.POLYGON &&
      this.handleHistory(prevState);

    if (
      (this.state.standardToolbarClickedShape === shapeName.UNDO ||
      this.state.standardToolbarClickedShape === shapeName.REDO
        ? this.state.historyCords.length > 0
        : this.state.shapeCords.length > 0) &&
      (this.didStandardToolabarTrue() === 'COPY' ||
        this.didStandardToolabarTrue() === 'CUT' ||
        this.didStandardToolabarTrue() === 'PASTE' ||
        this.didStandardToolabarTrue() === 'DUPLICATE' ||
        this.didStandardToolabarTrue() === 'DELETE' ||
        this.didStandardToolabarTrue() === 'CLEARALL' ||
        this.didStandardToolabarTrue() === 'REFRESH' ||
        this.didStandardToolabarTrue() === 'SENDTOBACK' ||
        this.didStandardToolabarTrue() === 'BRINGTOFRONT' ||
        this.didStandardToolabarTrue() === 'UNGROUP' ||
        this.didStandardToolabarTrue() === 'ROUNDED' ||
        this.didStandardToolabarTrue() === 'UNDO' ||
        this.didStandardToolabarTrue() === 'REDO' ||
        this.didStandardToolabarTrue() === 'SQUARE' ||
        this.didStandardToolabarTrue() === 'SAVEASIMAGE')
    ) {
      this.handleToolsClicked(this.didStandardToolabarTrue());
    } else {
      if (
        this.state.selectedShapeCordsToCopy.length > 0 &&
        (this.didStandardToolabarTrue() === 'COPY' ||
          this.didStandardToolabarTrue() === 'CUT' ||
          this.didStandardToolabarTrue() === 'PASTE' ||
          this.didStandardToolabarTrue() === 'DUPLICATE' ||
          this.didStandardToolabarTrue() === 'DELETE' ||
          this.didStandardToolabarTrue() === 'CLEARALL' ||
          this.didStandardToolabarTrue() === 'REFRESH' ||
          this.didStandardToolabarTrue() === 'SENDTOBACK' ||
          this.didStandardToolabarTrue() === 'BRINGTOFRONT' ||
          this.didStandardToolabarTrue() === 'UNGROUP')
      ) {
        console.log('clicked', this.didStandardToolabarTrue());

        this.handleToolsClicked(this.didStandardToolabarTrue());
      }
    }
    if (this.state.shapeCords.length > 0 && this.state.refreshCanvas) {
      this.setState({ ...this.state, shapeCords: [], refreshCanvas: false }, () => {});
    }

    if (
      this.state.shapeCords.length >= 0 &&
      (this.didStandardToolabarTrue() === 'ZOOMIN' ||
        this.didStandardToolabarTrue() === 'ZOOMOUT' ||
        this.didStandardToolabarTrue() === 'NORMAL')
    ) {
      this.zoomFun(this.didStandardToolabarTrue());
    }
    if (
      this.state.imageSource &&
      this.state.activeShape !== prevState.activeShape &&
      this.state.activeShape === shapeName.INSERTIMAGE
    ) {
      console.log(shapeName.INSERTIMAGE, 'this.state.imageSource', this.state.activeShape);
      let imageId = 'Image' + '_' + (Number(this.state.shapeCords.length) + 1);

      let shapeCords = this.state.shapeCords;

      const image = new window.Image();
      image.src = this.state.imageSource;
      let imageData = {
        x: 0,
        y: 0,
        shape: 'Image',
        height: 410,
        width: 800,
        endX: 410,
        endY: 800,
        id: imageId,
        imageSource: image,
      };
      shapeCords.push(imageData);
      image.onload = () => {
        this.setState(
          {
            image: image,
            shapeCords,
          },
          () => this.handleHistory(),
        );
      };
    }
  }

  // handleClearAll = (shape) => {
  //     console.log(shape, '.....')
  // }

  zoomFun = shape => {
    switch (shape) {
      case 'ZOOMIN':
        const tempValForIncreasingZoomIn = 0.05; //Here I am storing the temp value for increasing the zoom in
        const PageZoomIn = document.getElementsByClassName('konvajs-content'); //PageZoomIn store the Konvajs-content element
        const zoomInScale = PageZoomIn[0].style['transform']; //zoomInScale store the konvajs-conent style(transform) [ex:scale(1.1)]

        //zoomInScaleVal store the only number after separating number from string(which I got above in zoomInScale)
        const zoomInScaleVal = zoomInScale.replace(/[^0-9\.]/g, '');
        var zoomInScaleNumVal = Number(zoomInScaleVal); //Here I am converting string to number

        if (zoomInScaleNumVal <= 1) zoomInScaleNumVal = 1;

        //In this if condition I am performing operation (I am increasing the scale size 0.05)
        if (zoomInScaleNumVal <= 2.1) {
          PageZoomIn[0].style['transform'] = `scale(${zoomInScaleNumVal + tempValForIncreasingZoomIn})`;
          PageZoomIn[0].style['transform-origin'] = `${0}%` + `${0}%`;
        }
        this.props.doEmptyShapeOperations();
        break;
      case 'ZOOMOUT':
        const tempValForIncreasingZoomOut = 0.05;
        const PageZoomOut = document.getElementsByClassName('konvajs-content');
        const zoomOutScale = PageZoomOut[0].style['transform'];

        const zoomOutScaleVal = zoomOutScale.replace(/[^0-9\.]/g, '');
        var zoomOutScaleNumVal = Number(zoomOutScaleVal);

        if (zoomOutScaleNumVal <= 1) zoomOutScaleNumVal = 1;

        if (zoomOutScaleNumVal >= 1) {
          PageZoomOut[0].style['transform'] = `scale(${zoomOutScaleNumVal - tempValForIncreasingZoomOut})`;
          PageZoomOut[0].style['transform-origin'] = `${0}%` + `${0}%`;
        }
        this.props.doEmptyShapeOperations();
        break;
      case 'NORMAL':
        const PageNormalSize = document.getElementsByClassName('konvajs-content');
        PageNormalSize[0].style['transform'] = `scale(${1})`;
        PageNormalSize[0].style['transform-origin'] = `${0}%` + `${0}%`;

        this.props.doEmptyShapeOperations();
        break;
      default:
        break;
    }
  };

  handleToolsClicked = shape => {
    let shapeCords = this.state.shapeCords.map(a => ({ ...a }));
    let selectedId = [...this.state.selectedId];
    let selectedShapeCordsToCopy;
    // console.log('......', this.state.shapeCords);
    switch (shape) {
      case 'CUT':
        selectedShapeCordsToCopy = shapeCords.filter(array => selectedId.some(filter => filter === array.id));
        for (var i = shapeCords.length - 1; i >= 0; i--) {
          for (var j = 0; j < selectedId.length; j++) {
            if (shapeCords[i] && shapeCords[i].id === selectedId[j]) {
              shapeCords.splice(i, 1);
            }
          }
        }

        this.setState(
          {
            ...this.state,
            shapeCords: shapeCords,
            selectedShapeCordsToCopy: selectedShapeCordsToCopy,
          },
          () => this.handleHistory(),
        );

        break;
      case 'COPY':
        selectedShapeCordsToCopy = shapeCords.filter(array => selectedId.some(filter => filter === array.id));

        this.setState({
          ...this.state,
          selectedShapeCordsToCopy,
        });

        break;
      case 'PASTE':
        if (this.state.selectedShapeCordsToCopy && this.state.selectedId) {
          this.state.selectedShapeCordsToCopy.forEach((data, index) => {
            data.id = data.shape + '_' + (Number(shapeCords.length) + index + 1);
            data.x = 400;
            data.y = 150;
            data.endX = data.width + 400;
            data.endY = data.height + 150;
            data.draggable = false;
            data.isSelected = true;
          });
          let newCords = [...this.state.shapeCords, ...this.state.selectedShapeCordsToCopy];
          this.setState(
            {
              ...this.state,
              shapeCords: newCords,
            },
            () => this.handleHistory(),
          );
        } else {
          alert('please select anything');
        }

        break;
      case 'DUPLICATE':
        selectedShapeCordsToCopy = shapeCords.filter(array => selectedId.some(filter => filter === array.id));

        selectedShapeCordsToCopy.forEach((data, index) => {
          data.id = data.shape + '_' + (Number(shapeCords.length) + index + 1);
          data.x = data.x + 20;
          data.y = data.y + 20;
          data.endX = data.width + data.x;
          data.endY = data.height + data.y;
          data.draggable = false;
          data.isSelected = false;
        });

        let newCords = [...this.state.shapeCords, ...selectedShapeCordsToCopy];

        this.setState(
          {
            ...this.state,
            shapeCords: newCords,
          },
          () => this.handleHistory(),
        );

        break;
      case 'DELETE':
        let groupCords = this.state.groupCords;
        //selectedShapeCordsToCopy = shapeCords.filter(array => selectedId.some(filter => filter === array.id));
        for (var i = shapeCords.length - 1; i >= 0; i--) {
          for (var j = 0; j < selectedId.length; j++) {
            if (shapeCords[i] && shapeCords[i].id === selectedId[j]) {
              shapeCords.splice(i, 1);
            }
          }
        }

        this.setState(
          {
            ...this.state,
            shapeCords: shapeCords,
            //selectedShapeCordsToCopy: selectedShapeCordsToCopy
          },
          () => this.handleHistory(),
        );

        break;
      case 'CLEARALL':
        //selectedShapeCordsToCopy = shapeCords.filter(array => selectedId.some(filter => filter === array.id));

        this.setState(
          {
            ...this.state,
            shapeCords: [],
            groupCords: [],
            //selectedShapeCordsToCopy: selectedShapeCordsToCopy
          },
          () => this.handleHistory(),
        );

        break;
      case 'REFRESH':
        this.props.refreshClicked();
        break;
      case 'SAVEASIMAGE':
        let canvas1 = document.querySelector('canvas');
        let ctx = canvas1.getContext('2d');
        let lnk = document.createElement('a'),
          e;
        lnk.download = `${this.props.fileName}.png`;
        lnk.href = canvas1.toDataURL({
          format: 'png',
          left: 300,
          top: 250,
          width: 200,
          height: 150,
          quality: 1,
        });

        if (document.createEvent) {
          e = document.createEvent('MouseEvents');
          e.initMouseEvent('click', true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null);

          lnk.dispatchEvent(e);
        } else if (lnk.fireEvent) {
          lnk.fireEvent('onclick');
        }
        break;

      case 'SENDTOBACK':
        selectedShapeCordsToCopy = shapeCords.filter(array => selectedId.some(filter => filter === array.id));

        for (var i = shapeCords.length - 1; i >= 0; i--) {
          for (var j = 0; j < selectedId.length; j++) {
            if (shapeCords[i] && shapeCords[i].id === selectedId[j]) {
              shapeCords.splice(i, 1);
            }
          }
        }
        shapeCords = [...selectedShapeCordsToCopy, ...shapeCords];
        this.setState(
          {
            shapeCords,
          },
          () => this.handleHistory(),
        );
        break;

      case 'BRINGTOFRONT':
        selectedShapeCordsToCopy = shapeCords.filter(array => selectedId.some(filter => filter === array.id));

        for (var i = shapeCords.length - 1; i >= 0; i--) {
          for (var j = 0; j < selectedId.length; j++) {
            if (shapeCords[i] && shapeCords[i].id === selectedId[j]) {
              shapeCords.splice(i, 1);
            }
          }
        }
        shapeCords = [...shapeCords, ...selectedShapeCordsToCopy];
        this.setState(
          {
            shapeCords,
          },
          () => this.handleHistory(),
        );
        break;

      case 'UNGROUP':
        if (this.state.shapeCords.length > 0) {
          let cords = this.state.shapeCords.filter(shape =>
            shape.isSelected === true
              ? ((shape['isSelected'] = false),
                (shape['draggable'] = false),
                delete shape['grouped'],
                delete shape['groupID'])
              : shape,
          );
          this.setState({
            shapeCords: cords,
            groupCords: [],
          });
          console.log('ungroup', cords);
        }
        break;

      case 'ROUNDED':
        if (this.state.selectedId.length > 0) {
          this.setState(
            {
              selectedId: [],
            },
            () => {
              this.props.handleProps(30, 'curve');
            },
          );
        }
        break;
      case 'UNDO':
        this.handleUndo();
        break;

      case 'REDO':
        this.handleRedo();
        break;
      default:
        break;
    }

    this.props.doEmptyShapeOperations();
  };

  handleHistory = prevState => {
    let history = this.state.historyCords || [];
    let historyPush = [];
    let cordsData = [];
    let list = {};
    this.state.shapeCords.map(data => {
      list = {
        x: data.x,
        y: data.y,
        endX: data.endX,
        endY: data.endY,
        scaleX: data.scaleX,
        scaleY: data.scaleY,
        height: data.height,
        width: data.width,
        stroke: data.stroke,
        id: data.id,
        strokeWidth: data.strokeWidth,
        shape: data.shape,
        transformEnabled: false,
        cornerRadius: data.cornerRadius,
        fillLinearGradientColorStops: data.fillLinearGradientColorStops,
        isSelected: false,
        draggable: false,
      };
      if (list.shape === shapeName.POLYGON) {
        list.points = data.points;
        list.isClosed = data.isClosed;
      } else if (list.shape === shapeName.ARC) {
        list.dragedCenterX = data.dragedCenterX;
        list.centerX = data.centerX;
        list.centerY = data.centerY;
        list.dragedCenterY = data.dragedCenterY;
      }
      cordsData.push(list);
    });
    this.state.historyCords.map((data, i) => {
      if (i <= this.state.historyStep) {
        historyPush.push(data);
      }
    });
    historyPush.push(cordsData);
    // history.push(cordsData);
    this.setState({ shapeHistory: false, historyCords: historyPush, historyStep: historyPush.length - 1 });
  };

  handleUndo = () => {
    if (this.state.historyStep > 0) {
      let undoCords = this.state.historyCords[this.state.historyStep - 1];
      this.setState({
        shapeCords: undoCords,
        historyStep: this.state.historyStep - 1,
        standardToolbarClickedShape: false,
      });
    }
  };

  handleRedo = () => {
    if (this.state.historyCords.length - 1 > this.state.historyStep) {
      let redoCords = this.state.historyCords[this.state.historyStep + 1];
      this.setState({
        shapeCords: redoCords,
        historyStep: this.state.historyStep + 1,
        standardToolbarClickedShape: null,
      });
    }
  };

  settingHistoryCords = () => {
    // let historyCords = [];
    // if (true) {
    //   this.state.historyCords.map((data, i) => {
    //     if (i <= this.state.historyStep - 1) {
    //       console.log("called", data)
    //       historyCords.push(data)
    //     }
    //   })
    // }
    // console.log("called", this.state.historyCords, historyCords)
  };

  getMousePosition = stage => {
    return [stage.getPointerPosition().x, stage.getPointerPosition().y];
  };

  handleDisplayGrid = () => {
    this.setState({
      displayGrid: !this.state.displayGrid,
    });
  };

  handleMouseDown = e => {
    this.props.emptySelectdId(false);
    // this.props.emptyRoundedRectangle(false);
    // this.props.doCurveEmpty();

    const mousePosition = this.getMousePosition(e.target.getStage());

    // curveField Hide and Show
    if (this.state.activeShape === shapeNameConst.SQUARE) {
      document.getElementById('curveField').style.display = 'none';
    }
    if (
      (this.state.activeShape === shapeName.SELECT || this.state.activeShape === shapeName.TRANSFORM) &&
      !this.state.dragStart
    ) {
      this.setState({
        isSelectFinished: false,
        startingPoint: {
          x: mousePosition[0],
          y: mousePosition[1],
        },
      });
    }

    if (this.state.activeShape === shapeName.TEXT) {
      // if (this.state.baseCanvas === null) {
      //   const stage = e.target.getStage();
      //   const baseCanvas = stage.children[0].canvas._canvas;
      //   baseCanvas.id = 'baseCanvas';
      //   this.setState({
      //     baseCanvas,
      //   });
      // }
      if (this.state.textEditVisible) {
        this.setState({
          textEditVisible: false,
        });
      } else {
        this.setState({
          textEditVisible: true,
          textXPosition: mousePosition[0],
          textYPosition: mousePosition[1],
        });
      }
      // this.refs.editText.focus();
    }
    if (!this.state.startPoint.x && !this.state.startPoint.y) {
      this.setState({
        startPoint: {
          x: mousePosition[0],
          y: mousePosition[1],
        },
        mouseDown: true,
        mouseMove: false,
        textMouseMove: true,
      });
    }
    if (this.state.lastShapeId) {
      this.state.shapeCords.map(list => {
        list.isSelected = false;
      });
      this.setState({
        lastShapeId: null,
      });
    }

    if (this.state.activeShape === shapeName.SNAP) {
      let cords = this.state.shapeCords;
      let data = {
        shape: this.state.activeShape,
        id: this.state.activeShape + '_' + this.state.shapeCords.length,
        stroke: this.state.lineColor,
        strokeWidth: Number(this.state.strokeWidth),
        points: [mousePosition[0], mousePosition[1]],
      };
      cords.push(data);
      this.setState({ shapeCords: cords });
    }
  };

  handleMouseMove = e => {
    const mousePosition = this.getMousePosition(e.target.getStage());
    const cords = this.state.shapeCords;

    if (
      this.state.activeShape &&
      this.state.activeShape !== shapeName.SELECT &&
      this.state.activeShape !== shapeName.TRANSFORM &&
      this.state.activeShape !== shapeName.SNAP &&
      this.state.activeShape !== shapeName.POLYGON &&
      this.state.activeShape !== shapeName.TEXT
    ) {
      if (this.state.activeShape !== shapeName.FREE_HAND) {
        let width = mousePosition[0] - this.state.startPoint.x;
        let height = mousePosition[1] - this.state.startPoint.y;
        if (this.state.mouseDown && this.state.activeShape) {
          if (!this.state.mouseMove) {
            let finalShapeCords = [];
            const data = {
              x: this.state.startPoint.x,
              y: this.state.startPoint.y,
              height: height,
              dragedX: 0,
              dragedY: 0,
              width: width,
              stroke: this.state.lineColor,
              id: `${this.state.activeShape}_${this.state.shapeCords.length}`,
              strokeWidth: this.state.stroke > 0 ? Number(this.state.stroke) : 1 || 1,
              shape: this.state.activeShape,
              transformEnabled: false,
            };
            if (this.state.activeShape === shapeName.SQUARE && Number(this.state.curveInput) > 0) {
              data.cornerRadius = [
                this.state.curveInput,
                this.state.curveInput,
                this.state.curveInput,
                this.state.curveInput,
              ];
            }
            if (this.state.fillColour) {
              data.fillLinearGradientColorStops = [0, this.state.fillColour, 1, this.state.fillColour];
            }
            if (this.state.gradientFillColour) {
              data.fillLinearGradientColorStops = [0, this.state.fillColour, 1, this.state.gradientFillColour];
            }
            cords.map(dataList => {
              finalShapeCords.push(dataList);
            });
            finalShapeCords.push(data);
            this.setState({
              mouseMove: true,
              shapeCords: finalShapeCords,
              // historyStep: this.state.historyStep + 1,
            });
          } else {
            const lastIndex = cords.length - 1;
            const data = cords[lastIndex];
            const updatedData = {
              x: this.state.startPoint.x,
              y: this.state.startPoint.y,
              height: height,
              width: width,
              stroke: this.state.lineColor,
              id: data.id,
              strokeWidth: data.strokeWidth,
              shape: this.state.activeShape,
              transformEnabled: data.transformEnabled,
              endX: mousePosition[0],
              endY: mousePosition[1],
              cornerRadius: data.cornerRadius,
              //stroke: data.stroke,
              fillLinearGradientColorStops: data.fillLinearGradientColorStops,
            };
            let finalShapeCords = [];
            this.state.shapeCords.map((datas, i) => {
              if (data.id === datas.id) {
                finalShapeCords.push(updatedData);
              } else {
                finalShapeCords.push(datas);
              }
            });
            this.setState({ shapeCords: finalShapeCords, lastShapeId: data.id, selectedId: [data.id] });
            // this.handleUnselectShapes();
          }
        }
      } else {
        this.state.mouseDown && this.updateFreeHand(e);
      }
    }

    if (this.state.mouseDown) {
      this.setState({
        endPoint: {
          x: mousePosition[0],
          y: mousePosition[1],
        },
        // textMouseMove: true,
      });
      if (this.state.activeShape === shapeName.SELECT || this.state.activeShape === shapeName.TRANSFORM) {
        this.setState({
          endingPoint: {
            x: mousePosition[0],
            y: mousePosition[1],
          },
        });
      }

      if (this.props.activeShape === shapeName.SNAP && this.state.mouseDown) {
        const mousePosition = this.getMousePosition(e.target.getStage());
        let cords = this.state.shapeCords;
        let data = cords[this.state.shapeCords.length - 1];
        var points = data.points;

        if (points[points.length - 1] - 5 <= mousePosition[1] && points[points.length - 1] + 5 >= mousePosition[1]) {
          if (points[points.length - 2] - 2 <= mousePosition[0] && points[points.length - 2] + 2 >= mousePosition[0]) {
          } else {
            points.push(mousePosition[0], points[points.length - 1]);
            this.setState({
              mousePosition,
              points,
            });
          }
        } else if (
          points[points.length - 2] - 5 <= mousePosition[0] &&
          points[points.length - 2] + 5 >= mousePosition[0]
        ) {
          if (points[points.length - 1] - 2 <= mousePosition[1] && points[points.length - 1] + 2 >= mousePosition[1]) {
          } else {
            points.push(points[points.length - 2], mousePosition[1]);
            this.setState({
              mousePosition,
              points,
              lastShapeId: data.id,
            });
          }
        } else {
          points.push(mousePosition[0], mousePosition[1]);
        }
      }
    }

    if (this.state.activeShape === shapeName.POLYGON) {
      // this.handleUnselectShapes();
      this.setState({
        mousePosition: {
          x: mousePosition[0],
          y: mousePosition[1],
        },
      });
    }
  };

  handleMouseUp = e => {
    if (this.state.historyUpdateMouseUp) {
      this.handleHistory();
      this.setState({
        historyUpdateMouseUp: false,
      });
    }
    this.setState({
      mouseDown: false,
      mouseMove: false,
      shapeHistory: true,
      startPoint: {
        x: null,
        y: null,
      },
      isSelectFinished: true,
      textMouseMove: false,
      dragStart: false,
      mousePosition: [],
    });

    if (this.state.lastShapeId) {
      this.state.shapeCords.map(list => {
        if (list.id === this.state.lastShapeId) {
          list.isSelected = true;
        }
      });
    }

    if (this.state.activeShape === shapeName.SNAP) {
      let cords = this.state.shapeCords;
      let data = cords[this.state.shapeCords.length - 1];
      let points = data.points;

      let values = this.getStartAndEndCords(data.points);

      let height = values[3] - values[1];
      let width = values[2] - values[0];
      data.x = values[0];
      data.y = values[1];
      data.endX = values[2];
      data.endY = values[3];
      data.height = height;
      data.width = width;
      data.points = points;

      data.dragedX = 0;
      data.dragedY = 0;

      this.setState({
        shapeCords: cords,
        points: [],
      });
    }

    if (
      (this.state.activeShape === shapeName.TRANSFORM || this.state.activeShape === shapeName.SELECT) &&
      !this.state.dragStart
    ) {
      this.selectShapes();
    } else {
      this.setState({
        startingPoint: {
          x: null,
          y: null,
        },
        endingPoint: {
          x: null,
          y: null,
        },
        endPoint: {
          x: 0,
          y: 0,
        },
      });
    }

    if (this.state.activeShape === shapeNameConst.SQUARE || this.state.activeShape === shapeName.TRANSFORM) {
      document.getElementById('curveField').style.display = 'block';
    } else {
      // document.getElementById('curveField').style.display = 'none';
    }
  };

  getStartAndEndCords = points => {
    var startX = 0;
    var startY = 0;
    var endX = 0;
    var endY = 0;

    var oddArray = [];
    var evenArray = [];

    for (var i = 0; i < points.length; i++) {
      if (i % 2 === 0) {
        oddArray.push(points[i]);
      } else {
        evenArray.push(points[i]);
      }
    }

    var sortedOddArray = oddArray.sort((a, b) => b - a);
    var sortedEvenArray = evenArray.sort((a, b) => b - a);

    startX = sortedOddArray[sortedOddArray.length - 1];
    startY = sortedEvenArray[sortedEvenArray.length - 1];

    endX = sortedOddArray[0];
    endY = sortedEvenArray[0];

    return [startX, startY, endX, endY];
  };

  selectShapes = () => {
    let startPoint = this.state.startingPoint;
    let endPoint = this.state.endingPoint;
    let selectedId = [];

    console.log('abcc selectShapes ');

    if (startPoint.x > endPoint.x && startPoint.y > endPoint.y) {
      startPoint = this.state.endingPoint;
      endPoint = this.state.startingPoint;
    } else if (startPoint.x < endPoint.x && startPoint.y > endPoint.y) {
      startPoint = {
        x: this.state.startingPoint.x,
        y: this.state.endingPoint.y,
      };
      endPoint = {
        x: this.state.endingPoint.x,
        y: this.state.startingPoint.y,
      };
    } else if (startPoint.x > endPoint.x && startPoint.y < endPoint.y) {
      startPoint = {
        x: this.state.endingPoint.x,
        y: this.state.startingPoint.y,
      };
      endPoint = {
        x: this.state.startingPoint.x,
        y: this.state.endingPoint.y,
      };
    }

    var startX = 0;
    var startY = 0;

    var endX = 0;
    var endY = 0;

    this.state.shapeCords.map(data => {
      startX = data.x;
      startY = data.y;
      endX = data.x + data.width;
      endY = data.y + data.height;

      if ((data.dragedX !== undefined || data.dragedY !== undefined) && (data.dragedX !== 0 || data.dragedY !== 0)) {
        if (data.shape === shapeName.SECTOR) {
          startX = data.dragedX;
          startY = data.dragedY;
          endX = data.dragedX + data.width;
          endY = data.dragedY + data.height;
        } else {
          startX = data.dragedX + startX;
          startY = data.dragedY + startY;
          endX = data.dragedX + (startX + data.width);
          endY = data.dragedY + (startY + data.height);
        }
      }

      if (data.scaleX !== undefined && data.scaleY !== undefined) {
        endX = data.x + data.width * data.scaleX;
        endY = data.y + data.height * data.scaleY;
      }

      console.log('abcc', startX, startY, endX, endY);

      var dStartX = 0;
      var dStartY = 0;

      if (startX > endX && startY > endY) {
        dStartX = startX;
        dStartY = startY;
        startX = endX;
        startY = endY;
        endX = dStartX;
        endY = dStartY;
      } else if (startX < endX && startY > endY) {
        dStartY = startY;
        startY = endY;
        endY = dStartY;
      } else if (startX > endX && startY < endY) {
        dStartX = startX;
        startX = endX;
        endX = startX;
      }

      for (var x = startX; x <= endX; x++) {
        for (var y = startY; y <= endY; y++) {
          if (x === startX || x === endX || y === startY || y === endY) {
            if (
              x >= startPoint.x &&
              y >= startPoint.y &&
              x >= startPoint.x &&
              y <= endPoint.y &&
              x <= endPoint.x &&
              y >= startPoint.y &&
              x <= endPoint.x &&
              y <= endPoint.y
            ) {
              if (!selectedId.includes(data.id)) {
                if (data.groupID !== undefined) {
                  let groupID = data.groupID;
                  let groupCordsArr = [];
                  this.state.shapeCords.filter(shape => shape.groupID === groupID && selectedId.push(shape.id));
                  this.state.shapeCords.filter(shape => {
                    switch (shape.shape) {
                      case shapeNameConst.SQUARE:
                      case shapeNameConst.CIRCLE:
                      case shapeNameConst.LINE:
                      case shapeNameConst.ARC:
                        shape.groupID === groupID &&
                          groupCordsArr.push(shape.x, shape.y, shape.x + shape.width, shape.y + shape.height);
                        break;
                      case shapeNameConst.POLYGON:
                      case shapeNameConst.FREE_HAND:
                      case shapeNameConst.SNAP:
                        shape.groupID === groupID &&
                          groupCordsArr.push(
                            shape.x + shape.dragedX,
                            shape.y + shape.dragedY,
                            shape.x + shape.dragedX + shape.width,
                            shape.y + shape.dragedY + shape.height,
                          );
                        break;
                      case shapeNameConst.SECTOR:
                        shape.groupID === groupID && groupCordsArr.push(shape.x, shape.y, shape.endX, shape.endY);
                        break;
                      default:
                        break;
                    }
                  });
                  this.setState({ groupCords: this.getStartAndEndCords(groupCordsArr) });
                }
                selectedId.push(data.id);
                return null;
              }
            }
          }
        }
      }

      if (
        startPoint.x >= startX &&
        startPoint.y >= startY &&
        startPoint.x >= startX &&
        startPoint.y <= endY &&
        startPoint.x <= endX &&
        startPoint.y >= startY &&
        startPoint.x <= endX &&
        startPoint.y <= endY
      ) {
        if (!selectedId.includes(data.id)) {
          if (data.groupID !== undefined) {
            let groupID = data.groupID;
            let groupCordsArr = [];
            this.state.shapeCords.filter(shape => shape.groupID === groupID && selectedId.push(shape.id));
            this.state.shapeCords.filter(shape => {
              switch (shape.shape) {
                case shapeNameConst.SQUARE:
                case shapeNameConst.CIRCLE:
                case shapeNameConst.LINE:
                case shapeNameConst.ARC:
                  shape.groupID === groupID &&
                    groupCordsArr.push(shape.x, shape.y, shape.x + shape.width, shape.y + shape.height);
                  break;
                case shapeNameConst.POLYGON:
                case shapeNameConst.FREE_HAND:
                case shapeNameConst.SNAP:
                  shape.groupID === groupID &&
                    groupCordsArr.push(
                      shape.x + shape.dragedX,
                      shape.y + shape.dragedY,
                      shape.x + shape.dragedX + shape.width,
                      shape.y + shape.dragedY + shape.height,
                    );
                  break;
                case shapeNameConst.SECTOR:
                  shape.groupID === groupID && groupCordsArr.push(shape.x, shape.y, shape.endX, shape.endY);
                  break;
                default:
                  break;
              }
            });
            this.setState({ groupCords: this.getStartAndEndCords(groupCordsArr) });
          }
          selectedId.push(data.id);
          return null;
        }
      }
    });

    if (this.state.endingPoint.x > 0 && this.state.endingPoint.y > 0) {
      this.handleUnselectShapes();

      if (selectedId.length > 0) {
        let cords = this.state.shapeCords;
        cords
          .filter(list => selectedId.includes(list.id))
          .map(shape => {
            if (this.state.activeShape === shapeName.SELECT) {
              switch (shape.shape) {
                case shapeName.SQUARE:
                  document.getElementById('curveField').style.display = 'block';
                  document.getElementById('curveInput').value =
                    shape.cornerRadius !== undefined ? shape.cornerRadius[0] : 0;
                  break;

                case shapeName.CIRCLE:
                case shapeName.POLYGON:
                case shapeName.SECTOR:
                case shapeName.LINE:
                case shapeName.ARC:
                  document.getElementById('curveField').style.display = 'none';

                  break;
                default:
                  break;
              }

              shape.transformEnabled = false;
            } else if (this.state.activeShape === shapeName.TRANSFORM) {
              switch (shape.shape) {
                case shapeName.SQUARE:
                  document.getElementById('curveInput').value =
                    shape.cornerRadius !== undefined ? shape.cornerRadius[0] : 0;
                  shape.transformEnabled = true;
                  break;
                case shapeName.CIRCLE:
                case shapeName.POLYGON:
                case shapeName.SECTOR:
                case shapeName.LINE:
                case shapeName.ARC:
                  document.getElementById('curveField').style.display = 'none';
                  break;
                default:
                  break;
              }
            }
          });
      }
      this.setState(
        {
          selectedId: selectedId,
        },
        () => this.handleSelectShapes(this.state.selectedId),
      );
      this.setState({
        startingPoint: {
          x: null,
          y: null,
        },
        endingPoint: {
          x: null,
          y: null,
        },
      });
    }
  };

  applyStylesForText = () => {
    let id = this.state.selectedId;
    console.log('shp applyStylesForText', id);
    let cords = this.state.shapeCords;
    let textOperations = this.state.textOperations;
    console.log('shp', textOperations);
    if (textOperations !== undefined && id !== null) {
      for (let [style, value] of Object.entries(textOperations)) {
        if (value.value !== null || value.value !== undefined) {
          switch (style) {
            case 'FONTFAMILY':
              if (value.fontFamily !== undefined) {
                cords.map(shape => {
                  if (id.includes(shape.id)) {
                    shape.fontFamily = value.fontFamily;
                  }
                });
              }
              break;

            case 'FONTSIZE':
              if (value.fontSize !== undefined) {
                cords.map(shape => {
                  if (id.includes(shape.id)) {
                    shape.fontSize = value.fontSize;
                  }
                });
              }
              break;

            case 'FORECOLOR':
              if (value.foreColor !== undefined) {
                cords.map(shape => {
                  if (id.includes(shape.id)) {
                    shape.fill = value.foreColor;
                  }
                });
              }
              break;

            case 'BOLD':
              if (value !== '') {
                console.log('shp', value === undefined);
                cords.map(shape => {
                  if (id.includes(shape.id)) {
                    shape.fontStyle = 'bold';
                  }
                });
                // textOperations.BOLD = 'false';
              }
              break;

            case 'ITALIC':
              if (value !== '') {
                console.log('shp', value === undefined);
                cords.map(shape => {
                  if (id.includes(shape.id)) {
                    shape.fontStyle = 'italic';
                  }
                });
                // textOperations.ITALIC = 'false';
              }
              break;

            case 'UNDERLINE':
              if (value !== '') {
                console.log('shp', value === undefined);
                cords.map(shape => {
                  if (id.includes(shape.id)) {
                    shape.textDecoration = 'underline';
                  }
                });
                // textOperations.UNDERLINE = 'false';
              }
              break;

            default:
              break;
          }
        }
      }
      console.log('shp', textOperations);
      textOperations = {
        FONTFAMILY: '',
        FORECOLOR: '',
        FONTSIZE: '',
        BOLD: '',
        ITALIC: '',
        UNDERLINE: '',
      };

      this.setState(
        {
          shapeCords: cords,
          // textOperations;
        },
        () => this.props.doEmptyTextOperations(textOperations),
      );
    }
  };

  handleClick = e => {
    if (
      e !== null &&
      (this.state.activeShape === shapeName.SELECT || this.state.activeShape === shapeName.TRANSFORM) &&
      this.state.startingPoint.x !== null &&
      this.state.startingPoint.y !== null
    ) {
      let id = e.target.attrs.id;
      let shape = e.target.attrs.shape;
      let groupID = e.target.attrs.groupID;

      let selectedId = this.state.selectedId;
      selectedId = [];
      if (id) {
        if (shape === 'Text') {
          // this.handleTextChanges(id);
        }
        this.handleUnselectShapes();

        this.state.shapeCords.map(data => {
          if (!selectedId.includes(id)) {
            if (groupID !== undefined) {
              // let groupID = data.groupID;
              let groupCordsArr = [];
              this.state.shapeCords.filter(shape => shape.groupID === groupID && selectedId.push(shape.id));
              this.state.shapeCords.filter(shape => {
                switch (shape.shape) {
                  case shapeNameConst.SQUARE:
                  case shapeNameConst.CIRCLE:
                  case shapeNameConst.LINE:
                  case shapeNameConst.ARC:
                    shape.groupID === groupID &&
                      groupCordsArr.push(shape.x, shape.y, shape.x + shape.width, shape.y + shape.height);
                    break;
                  case shapeNameConst.POLYGON:
                  case shapeNameConst.FREE_HAND:
                  case shapeNameConst.SNAP:
                    shape.groupID === groupID &&
                      groupCordsArr.push(
                        shape.x + shape.dragedX,
                        shape.y + shape.dragedY,
                        shape.x + shape.dragedX + shape.width,
                        shape.y + shape.dragedY + shape.height,
                      );
                    break;
                  case shapeNameConst.SECTOR:
                    shape.groupID === groupID && groupCordsArr.push(shape.x, shape.y, shape.endX, shape.endY);
                    break;
                  default:
                    break;
                }
              });
              this.setState({ groupCords: this.getStartAndEndCords(groupCordsArr) });
            }
            return null;
          }
        });
        selectedId.push(id);

        console.log('ssss', selectedId);
        this.setState(
          {
            selectedId: selectedId,
          },
          () => this.handleSelectShapes(),
        );
      } else if (id === undefined) {
        console.log('abcc handleClick else');
        this.handleUnselectShapes();
        this.setState(
          {
            selectedId: [],
          },
          () => this.handleSelectShapes(),
        );
      }
    } else {
      console.log('abcc handleClick else else');
      if (!this.state.startingPoint && !this.state.endingPoint) {
        this.handleUnselectShapes();

        this.setState(
          {
            selectedId: [],
          },
          () => this.handleSelectShapes(),
        );
      }
    }

    if (this.state.activeShape === shapeName.POLYGON) {
      let cords = this.state.shapeCords;
      let finalShapeCords = [];
      let mousePosition = this.getMousePosition(e.target.getStage());
      if (this.state.polygonStart === false) {
        let data = {
          points: [
            {
              x: mousePosition[0],
              y: mousePosition[1],
            },
          ],
          stroke: this.state.lineColor,
          strokeWidth: Number(this.state.stroke),
          shape: this.state.activeShape,
          id: this.state.activeShape + '_' + this.state.shapeCords.length,
        };
        if (this.state.fillColour) {
          data.fillLinearGradientColorStops = [0, this.state.fillColour, 1, this.state.fillColour];
        }
        if (this.state.gradientFillColour) {
          data.fillLinearGradientColorStops = [0, this.state.fillColour, 1, this.state.gradientFillColour];
        }
        cords.map(dataList => {
          finalShapeCords.push(dataList);
        });
        finalShapeCords.push(data);
        this.setState({
          shapeCords: finalShapeCords,
          polygonStart: true,
          polygonStartPoint: {
            x: mousePosition[0],
            y: mousePosition[1],
          },
        });
      } else if (this.state.polygonStart === true) {
        const data = cords[this.state.shapeCords.length - 1];
        let updatedPoints = [];
        let finalShapeCords = [];
        data.points.map(pointList => {
          updatedPoints.push(pointList);
        });
        updatedPoints.push({
          x: mousePosition[0],
          y: mousePosition[1],
        });
        const updatedData = {
          points: updatedPoints,
          stroke: data.stroke,
          strokeWidth: data.strokeWidth,
          id: data.id,
          dragedX: 0,
          dragedY: 0,
          shape: data.shape,
          fillLinearGradientColorStops: data.fillLinearGradientColorStops,
        };
        this.state.shapeCords.map((datas, i) => {
          if (data.id === datas.id) {
            finalShapeCords.push(updatedData);
          } else {
            finalShapeCords.push(datas);
          }
        });

        this.setState({ shapeCords: finalShapeCords, lastShapeId: data.id });
        if (
          mousePosition[0] - 5 <= this.state.polygonStartPoint.x &&
          mousePosition[0] + 5 >= this.state.polygonStartPoint.x &&
          mousePosition[1] - 5 <= this.state.polygonStartPoint.y &&
          mousePosition[1] + 5 >= this.state.polygonStartPoint.y
        ) {
          let arr = [];
          data.points.map(data => {
            arr.push(data.x, data.y);
          });
          let value = this.getStartAndEndCords(arr);
          data.isClosed = true;
          data.isSelected = true;
          data.x = value[0];
          data.y = value[1];
          data.dragedX = 0;
          data.dragedY = 0;
          data.endX = value[2];
          data.endY = value[3];
          data.height = value[3] - value[1];
          data.width = value[2] - value[0];
          this.setState({ polygonStart: false, polygonStartPoint: {}, shapeCords: cords, selectedId: [data.id] }, () =>
            this.handleHistory(),
          );
        }
      }
    }
  };

  handleDblClick = e => {
    if (this.state.activeShape === shapeName.POLYGON) {
      const cords = this.state.shapeCords;
      const data = cords[cords.length - 1];
      if (data.points.length > 1) {
        let arr = [];
        data.points.map(data => {
          arr.push(data.x, data.y);
        });
        let value = this.getStartAndEndCords(arr);
        data.isClosed = true;
        data.isSelected = true;
        data.x = value[0];
        data.y = value[1];
        data.endX = value[2];
        data.endY = value[3];
        data.height = value[3] - value[1];
        data.width = value[2] - value[0];
        this.setState({ polygonStart: false, polygonStartPoint: {}, mousePosition: null, selectedId: [data.id] }, () =>
          this.handleHistory(),
        );
      }
    }
  };

  updateFreeHand = e => {
    if (!this.state.mouseMove) {
      let cords = this.state.shapeCords;
      let data = {
        points: [this.state.startPoint.x, this.state.startPoint.y],
        shape: this.state.activeShape,
        dragedX: 0,
        dragedY: 0,
        height: 0,
        width: 0,
        stroke: this.state.lineColor,
        strokeWidth: Number(this.state.stroke),
        id: `${this.state.activeShape}_${this.state.shapeCords.length}`,
      };
      cords.push(data);
      this.setState({
        mouseMove: true,
        shapeCords: cords,
      });
    } else {
      const mousePosition = this.getMousePosition(e.target.getStage());
      let cords = this.state.shapeCords;
      let lastIndex = cords.length - 1;
      let data = cords[lastIndex];
      let point = data.points;
      let values = this.getStartAndEndCords(point);
      let height = values[3] - values[1];
      let width = values[2] - values[0];
      data.height = height;
      data.width = width;
      point.push(...mousePosition);
      this.setState({ shapeCords: cords, lastShapeId: data.id }, () => this.freeHandTransform(lastIndex));
    }
  };

  freeHandTransform = i => {
    let cords = this.state.shapeCords;
    let data = cords[i];
    let oddArray = [];
    let evenArray = [];
    let point = data.points;
    point.map((value, i) => {
      if (i % 2 === 0) {
        oddArray.push(value);
      } else {
        evenArray.push(value);
      }
    });
    let minY = Math.min(...evenArray);
    let minX = Math.min(...oddArray);
    let maxY = Math.max(...evenArray);
    let maxX = Math.max(...oddArray);
    data.x = minX;
    data.y = minY;
    data.endX = maxX;
    data.endY = maxY;
    this.setState({ shapeCords: cords });
  };

  handleUpdatedDrag = (e, i, type, status) => {
    let cords = this.state.shapeCords;
    let shape = cords[i];
    const gridSize = 10;

    this.setState({
      startingPoint: { x: null, y: null },
      endingPoint: { x: null, y: null },
    });

    let alignToGrid = false;
    let gridX = 0;
    let gridY = 0;
    if (this.state.AlignGridActiveShapeName !== null) {
      alignToGrid = true;
      gridX = Math.round(e.x / gridSize) * gridSize;
      gridY = Math.round(e.y / gridSize) * gridSize;
    }

    switch (type) {
      case 'drag':
        let dragCords = [];
        let dragList = {};
        let multiDrag = [];
        let calcX, calcY;
        if (shape?.shape === shapeName.FREE_HAND || shape?.shape === shapeName.SNAP) {
          calcX = shape?.x + e.x - (shape?.x + shape?.dragedX);
          calcY = shape?.y + e.y - (shape?.y + shape?.dragedY);
        } else if (shape?.shape === shapeName.CIRCLE) {
          calcX = e.x - e.radiusX - shape.x;
          calcY = e.y - e.radiusY - shape.y;
        } else if (
          shape?.shape === shapeName.SECTOR ||
          shape?.shape === shapeName.SQUARE ||
          shape?.shape === shapeName.POLYGON
        ) {
          calcX = e.x - shape?.x;
          calcY = e.y - shape?.y;
        } else if (shape?.shape === shapeName.LINE || shape?.shape === shapeName.ARC) {
          calcX = shape.oldX ? e.x - shape.oldX : e.x;
          calcY = shape.oldY ? e.y - shape.oldY : e.y;
        }
        this.state.shapeCords.map(data => {
          if (this.state.selectedId.includes(data.id)) {
            dragList = {
              x: data.x,
              y: data.y,
              endX: data.endX,
              endY: data.endY,
              scaleX: data.scaleX,
              scaleY: data.scaleY,
              height: data.height,
              width: data.width,
              stroke: data.stroke,
              id: data.id,
              strokeWidth: data.strokeWidth,
              shape: data.shape,
              transformEnabled: data.transformEnabled,
              cornerRadius: data.cornerRadius,
              fillLinearGradientColorStops: data.fillLinearGradientColorStops,
              isSelected: data.isSelected,
              draggable: data.draggable,
            };
            if (dragList.shape === shapeName.POLYGON) {
              dragList.points = data.points;
              dragList.isClosed = data.isClosed;
            } else if (dragList.shape === shapeName.ARC) {
              dragList.dragedCenterX = data.dragedCenterX;
              dragList.centerX = data.centerX;
              dragList.centerY = data.centerY;
              dragList.dragedCenterY = data.dragedCenterY;
            }
            // if (data.id === shape.id) {
            switch (dragList.shape) {
              case shapeName.CIRCLE:
                if (dragList.shape === shapeName.CIRCLE && shape.id === data.id) {
                  dragList.x = e.x - e.radiusX;
                  dragList.y = e.y - e.radiusY;
                  dragList.endX = e.x + e.radiusX;
                  dragList.endY = e.y + e.radiusY;
                } else {
                  dragList.x = dragList.x + calcX;
                  dragList.y = dragList.y + calcY;
                  dragList.endX = dragList.endX + calcX;
                  dragList.endY = dragList.endY + calcY;
                }
                break;

              case shapeName.SQUARE:
                dragList.x = dragList.x + calcX;
                dragList.y = dragList.y + calcY;
                dragList.endX = dragList.endX + calcX;
                dragList.endY = dragList.endY + calcY;
                break;

              case shapeName.SECTOR:
                dragList.x = dragList.x + calcX;
                dragList.y = dragList.y + calcY;
                dragList.endX = dragList.endX + calcX;
                dragList.endY = dragList.endY + calcY;
                break;

              case shapeName.FREE_HAND:
                if (dragList.shape === shapeName.FREE_HAND && shape.id === data.id) {
                  dragList.dragedX = dragList.dragedX + calcX;
                  dragList.dragedY = dragList.dragedY + calcY;
                } else {
                  dragList.dragedX = dragList.dragedX + calcX;
                  dragList.dragedY = dragList.dragedY + calcY;
                }
                break;

              case shapeName.POLYGON:
                if (dragList.shape === shapeName.POLYGON && shape.id === data.id) {
                  dragList.x = dragList.x + calcX;
                  dragList.y = dragList.y + calcY;
                } else {
                  dragList.x = dragList.x + calcX;
                  dragList.y = dragList.y + calcY;
                }
                break;

              case shapeName.SNAP:
                if (dragList.shape === shapeName.SNAP && shape.id === data.id) {
                  dragList.dragedX = dragList.dragedX + calcX;
                  dragList.dragedY = dragList.dragedY + calcY;
                } else {
                  dragList.dragedX = dragList.dragedX + calcX;
                  dragList.dragedY = dragList.dragedY + calcY;
                }
                break;

              case shapeName.LINE:
                if (dragList?.shape === shapeName.LINE && shape.id === data.id) {
                  dragList.x = dragList.x + calcX;
                  dragList.y = dragList.y + calcY;
                  dragList.endX = dragList.endX + calcX;
                  dragList.endY = dragList.endY + calcY;
                  dragList.oldX = e.x;
                  dragList.oldY = e.y;
                } else {
                  dragList.x = dragList.x + calcX;
                  dragList.y = dragList.y + calcY;
                  dragList.endX = dragList.endX + calcX;
                  dragList.endY = dragList.endY + calcY;
                }
                break;

              case shapeName.ARC:
                if (dragList?.shape === shapeName.ARC && shape.id === data.id) {
                  dragList.x = dragList.x + calcX;
                  dragList.y = dragList.y + calcY;
                  dragList.dragedCenterX = dragList.dragedCenterX + calcX;
                  dragList.dragedCenterY = dragList.dragedCenterY + calcY;
                  dragList.centerX = dragList.dragedCenterX + calcX;
                  dragList.centerY = dragList.dragedCenterY + calcY;
                  dragList.endX = dragList.endX + calcX;
                  dragList.endY = dragList.endY + calcY;
                  dragList.oldX = e.x;
                  dragList.oldY = e.y;
                } else {
                  dragList.x = dragList.x + calcX;
                  dragList.y = dragList.y + calcY;
                  dragList.dragedCenterX = dragList.dragedCenterX + calcX;
                  dragList.dragedCenterY = dragList.dragedCenterY + calcY;
                  dragList.centerX = dragList.dragedCenterX + calcX;
                  dragList.centerY = dragList.dragedCenterY + calcY;
                  dragList.endX = dragList.endX + calcX;
                  dragList.endY = dragList.endY + calcY;
                }
                // data.dragedX = (data.dragedX ? data.dragedX : data.x) + calcX;
                // data.dragedY = (data.dragedY ? data.dragedY : data.y) + calcY;
                // data.dragedCenterX =
                //   (data.dragedCenterX ? data.dragedCenterX : data.x + (data.endX - data.x) / 2) + calcX;
                // data.dragedCenterY =
                //   (data.dragedCenterY ? data.dragedCenterY : data.y + (data.endY - data.y) / 2) + calcY;
                // data.dragedEndX = (data.dragedEndX ? data.dragedEndX : data.endX) + calcX;
                // data.dragedEndY = (data.dragedEndY ? data.dragedEndY : data.endY) + calcY;
                break;
              default:
                break;
            }
            dragCords.push(dragList);
          } else {
            dragList = {
              x: data.x,
              y: data.y,
              endX: data.endX,
              endY: data.endY,
              scaleX: data.scaleX,
              scaleY: data.scaleY,
              height: data.height,
              width: data.width,
              stroke: data.stroke,
              id: data.id,
              strokeWidth: data.strokeWidth,
              shape: data.shape,
              transformEnabled: data.transformEnabled,
              cornerRadius: data.cornerRadius,
              fillLinearGradientColorStops: data.fillLinearGradientColorStops,
              isSelected: data.isSelected,
              draggable: data.draggable,
            };
            if (dragList.shape === shapeName.POLYGON) {
              dragList.points = data.points;
              dragList.isClosed = data.isClosed;
            } else if (dragList.shape === shapeName.ARC) {
              dragList.dragedCenterX = data.dragedCenterX;
              dragList.centerX = data.centerX;
              dragList.centerY = data.centerY;
              dragList.dragedCenterY = data.dragedCenterY;
            }
            dragCords.push(dragList);
          }
        });
        this.setState({ shapeCords: dragCords, historyUpdateMouseUp: true });
        break;

      case 'drop':
        if (this.state.shapeCords.length > 1) {
          this.state.shapeCords.filter(cords =>
            cords.isSelected === true && cords.grouped === true
              ? ((cords['isSelected'] = false), (cords['draggable'] = false))
              : cords,
          );

          this.setState({
            groupCords: [],
            dragStart: status,
          });
        }
        break;
      case 'transform':
        let transformCords = [];
        let list = {};
        this.state.shapeCords.map(data => {
          if (data.id === shape.id) {
            list = {
              x: data.x,
              y: data.y,
              endX: data.endX,
              endY: data.endY,
              scaleX: data.scaleX,
              scaleY: data.scaleY,
              height: data.height,
              width: data.width,
              stroke: data.stroke,
              id: data.id,
              strokeWidth: data.strokeWidth,
              shape: data.shape,
              transformEnabled: data.transformEnabled,
              cornerRadius: data.cornerRadius,
              fillLinearGradientColorStops: data.fillLinearGradientColorStops,
              isSelected: data.isSelected,
              draggable: data.draggable,
            };
            if (list.shape === shapeName.POLYGON) {
              list.points = data.points;
              list.isClosed = data.isClosed;
            } else if (list.shape === shapeName.ARC) {
              list.dragedCenterX = data.dragedCenterX;
              list.centerX = data.centerX;
              list.centerY = data.centerY;
              list.dragedCenterY = data.dragedCenterY;
            }
            switch (list.shape) {
              case shapeName.CIRCLE:
                list.x = e.x - e.radiusX;
                list.y = e.y - e.radiusY;
                list.endX = e.x + e.radiusX;
                list.endY = e.y + e.radiusY;
                list.scaleX = e.scaleX;
                list.scaleY = e.scaleY;
                break;

              case shapeName.SQUARE:
                list.x = Math.round(e.x);
                list.y = Math.round(e.y);
                list.scaleX = e.scaleX;
                list.scaleY = e.scaleY;
                break;

              case shapeName.SECTOR:
                let sectorCalcX = list.x - e.x;
                let sectorCalcY = list.y - e.y;
                list.x = e.x;
                list.y = e.y;
                list.endX = list.endX - sectorCalcX;
                list.endY = list.endY - sectorCalcY;
                list.scaleY = e.scaleY;
                list.scaleX = e.scaleX;
                break;

              case shapeName.FREE_HAND:
                list.scaleX = e.scaleX;
                list.scaleY = e.scaleY;
                list.dragedX = Math.round(e.x);
                list.dragedY = Math.round(e.y);
                break;

              case shapeName.SNAP:
                list.scaleX = e.scaleX;
                list.scaleY = e.scaleY;
                list.dragedX = Math.round(e.x);
                list.dragedY = Math.round(e.y);
                break;

              case shapeName.POLYGON:
                list.x = Math.round(e.x);
                list.y = Math.round(e.y);
                list.scaleX = e.scaleX;
                list.scaleY = e.scaleY;
                break;

              default:
                break;
            }
          } else {
            list = {
              x: data.x,
              y: data.y,
              endX: data.endX,
              endY: data.endY,
              scaleX: data.scaleX,
              scaleY: data.scaleY,
              height: data.height,
              width: data.width,
              stroke: data.stroke,
              id: data.id,
              strokeWidth: data.strokeWidth,
              shape: data.shape,
              transformEnabled: data.transformEnabled,
              cornerRadius: data.cornerRadius,
              fillLinearGradientColorStops: data.fillLinearGradientColorStops,
              isSelected: data.isSelected,
              draggable: data.draggable,
            };
            if (list.shape === shapeName.POLYGON) {
              list.points = data.points;
              list.isClosed = data.isClosed;
            } else if (list.shape === shapeName.ARC) {
              list.dragedCenterX = data.dragedCenterX;
              list.centerX = data.centerX;
              list.centerY = data.centerY;
              list.dragedCenterY = data.dragedCenterY;
            }
          }
          transformCords.push(list);
        });
        this.setState(
          {
            shapeCords: transformCords,
          },
          () => this.handleHistory(),
        );
        break;

      default:
        break;
    }

    let cord = cords.filter(cords => (cords.shape === 'Group' ? null : cords));

    this.setState({
      // shapeCords: cord,
      dragStart: status,
    });
  };

  updateArcEndPoint = (x, y, index, type, status) => {
    let cords = this.state.shapeCords;
    let findIndex = cords[index];
    let transformCords = [];
    let list = {};
    this.state.shapeCords.map(data => {
      if (data.id === findIndex.id) {
        list = {
          x: data.x,
          y: data.y,
          endX: data.endX,
          endY: data.endY,
          scaleX: data.scaleX,
          scaleY: data.scaleY,
          height: data.height,
          width: data.width,
          stroke: data.stroke,
          id: data.id,
          strokeWidth: data.strokeWidth,
          shape: data.shape,
          transformEnabled: data.transformEnabled,
          cornerRadius: data.cornerRadius,
          fillLinearGradientColorStops: data.fillLinearGradientColorStops,
          isSelected: data.isSelected,
          draggable: data.draggable,
        };
        if (list.shape === shapeName.POLYGON) {
          list.points = data.points;
          list.isClosed = data.isClosed;
        }
        switch (type) {
          case 'start':
            list.x = x;
            list.y = y;
            break;

          case 'center':
            list.centerX = x;
            list.dragedCenterX = x;
            list.centerY = y;
            list.dragedCenterY = y;
            break;

          case 'end':
            list.endX = x;
            list.endY = y;
            list.endType = status;
            break;

          case 'line':
            // findIndex.dragedX = findIndex.x + x;
            // findIndex.dragedY = findIndex.y + y;
            // findIndex.dragedCenterX = findIndex.centerX
            //   ? findIndex.centerX + x
            //   : findIndex.x + (findIndex.endX - findIndex.x) / 2 + x;
            // findIndex.dragedCenterY = findIndex.centerY
            //   ? findIndex.centerY + y
            //   : findIndex.y + (findIndex.endY - findIndex.y) / 2 + y;
            // findIndex.dragedEndX = findIndex.finalEndX ? findIndex.finalEndX + x : findIndex.endX + x;
            // findIndex.dragedEndY = findIndex.finalEndY ? findIndex.finalEndY + y : findIndex.endY + y;
            break;

          default:
            break;
        }
      } else {
        list = {
          x: data.x,
          y: data.y,
          endX: data.endX,
          endY: data.endY,
          scaleX: data.scaleX,
          scaleY: data.scaleY,
          height: data.height,
          width: data.width,
          stroke: data.stroke,
          id: data.id,
          strokeWidth: data.strokeWidth,
          shape: data.shape,
          transformEnabled: data.transformEnabled,
          cornerRadius: data.cornerRadius,
          fillLinearGradientColorStops: data.fillLinearGradientColorStops,
          isSelected: data.isSelected,
          draggable: data.draggable,
        };
        if (list.shape === shapeName.POLYGON) {
          list.points = data.points;
          list.isClosed = data.isClosed;
        }
      }
      transformCords.push(list);
    });
    this.setState({
      shapeCords: transformCords,
      historyUpdateMouseUp: true,
    });
  };

  handleSelectShapes = shape => {
    let cords = this.state.shapeCords;
    let selectedShape = this.state.selectedId;
    console.log('abcc handleSelectShapes ', selectedShape);

    // curveField Hide and Show
    if (selectedShape.length > 0) {
      let cords = this.state.shapeCords;
      cords
        .filter(list => selectedShape.includes(list.id))
        .map(shape => {
          if (this.state.activeShape === shapeName.SELECT) {
            switch (shape.shape) {
              case shapeName.SQUARE:
                document.getElementById('curveField').style.display = 'block';
                document.getElementById('curveInput').value =
                  shape.cornerRadius !== undefined ? shape.cornerRadius[0] : 0;
                break;

              case shapeName.CIRCLE:
              case shapeName.POLYGON:
              case shapeName.SECTOR:
              case shapeName.LINE:
              case shapeName.ARC:
                document.getElementById('curveField').style.display = 'none';

                break;
              default:
                break;
            }

            shape.transformEnabled = false;
          } else if (this.state.activeShape === shapeName.TRANSFORM) {
            switch (shape.shape) {
              case shapeName.SQUARE:
                document.getElementById('curveInput').value =
                  shape.cornerRadius !== undefined ? shape.cornerRadius[0] : 0;
                shape.transformEnabled = true;
                break;
              case shapeName.CIRCLE:
              case shapeName.POLYGON:
              case shapeName.SECTOR:
              case shapeName.LINE:
              case shapeName.ARC:
                document.getElementById('curveField').style.display = 'none';
                break;
              default:
                break;
            }
          }
        });
    } else {
      document.getElementById('curveField').style.display = 'none';
      if (this.state.groupCords !== undefined) {
        this.setState({
          groupCords: this.state.groupCords.length > 0 ? [] : this.state.groupCords,
        });
      }
    }

    cords
      .filter(list => selectedShape.includes(list.id))
      .map(shape => {
        shape.isSelected = true;
        shape.draggable = true;
        if (this.state.activeShape === shapeName.SELECT) {
          document.getElementById('strokeInput').value = shape.strokeWidth;
          shape.transformEnabled = false;
        } else if (this.state.activeShape === shapeName.TRANSFORM) {
          document.getElementById('strokeInput').value = shape.strokeWidth;
          shape.transformEnabled = true;
        }
      });
    let cord = cords.filter(cords => (cords.shape === 'Group' ? null : cords));

    this.setState({ shapeCords: cord });
  };

  handleShapeColours = props => {
    console.log(props.stroke, props.curveInput);
    if (this.state.activeShape) {
      if (
        props.lineColor !== this.state.lineColor ||
        props.fillColour !== this.state.fillColour ||
        props.gradientFillColour !== this.state.gradientFillColour ||
        props.stroke !== this.state.stroke ||
        props.curveInput !== this.state.curveInput
      ) {
        console.log(this.state.curveInput);
        this.handleSelectProperty(
          this.state.curveInput !== undefined ? 'curve' : null,
          this.props.colorType,
          props.lineColor
            ? this.state.lineColor
            : props.fillColour
            ? this.state.fillColour
            : props.gradientFillColour
            ? this.state.gradientFillColour
            : '#ffffff',
        );
      }
    }
  };

  handleSelectProperty = (curve, type, value) => {
    const colourCords = [];
    const selectedShape = this.state.selectedId;
    this.state.shapeCords.map(data => {
      if (selectedShape.includes(data.id)) {
        let list = {
          x: data.x,
          y: data.y,
          height: data.height,
          width: data.width,
          stroke: this.state.lineColor,
          id: data.id,
          strokeWidth: Number(this.state.stroke) > 0 ? Number(this.state.stroke) : 1,
          shape: data.shape,
          transformEnabled: data.transformEnabled,
          endX: data.endX,
          endY: data.endY,
          fillLinearGradientColorStops: data.fillLinearGradientColorStops,
          isSelected: data.isSelected,
          scaleX: data.scaleX,
          scaleY: data.scaleY,
          draggable: data.draggable,
        };
        if (data.shape === shapeName.POLYGON) {
          list.points = data.points;
          list.isClosed = data.isClosed;
        } else if (list.shape === shapeName.ARC) {
          list.dragedCenterX = data.dragedCenterX;
          list.centerX = data.centerX;
          list.centerY = data.centerY;
          list.dragedCenterY = data.dragedCenterY;
        }
        if (this.state.fillColour) {
          list.fillLinearGradientColorStops = [0, this.state.fillColour, 1, this.state.fillColour];
        } else if (this.state.fillColour === null) {
          list.fillLinearGradientColorStops = [0, 'transparent', 1, 'transparent'];
        }
        if (this.state.gradientFillColour) {
          list.fillLinearGradientColorStops = [0, this.state.fillColour, 1, this.state.gradientFillColour];
        }

        console.log(curve, Number(this.state.curveInput), 'props', this.props.curveInput);

        if (curve === 'curve' && Number(this.state.curveInput) > 1) {
          list.cornerRadius = [
            this.state.curveInput,
            this.state.curveInput,
            this.state.curveInput,
            this.state.curveInput,
          ];
        }
        colourCords.push(list);
      } else {
        colourCords.push(data);
      }
    });

    this.setState({ shapeCords: colourCords, initialSelect: false }, () => this.handleHistory());
  };

  handleUnselectShapes = () => {
    let cords = this.state.shapeCords;
    let selectedId = this.state.selectedId;

    if (selectedId.length > 0) {
      cords.map(data => {
        data.draggable = false;
        data.isSelected = false;
        data.transformEnabled = false;
      });
    }

    this.setState({
      shapeCords: cords,
    });
    console.log('abcc handleUnselectShapes ', selectedId);
  };

  alignShapes = () => {
    // let alignShape = this.state.shapeAlignMent;
    let selectedId = this.state.selectedId;
    let cords = this.state.shapeCords;

    let selectedShape = [];
    cords.filter(list => selectedId.includes(list.id)).map(shape => selectedShape.push(shape));
    let xCords = [];
    let yCords = [];
    let widthOfShapes = [];
    let heightOfShapes = [];
    let x = null;
    let y = null;
    let WidthToChange = 0;
    let heightToChange = 0;
    let spacing = 0;
    let numberOfShapes = 0;
    let lastShapeEnd = 0;
    switch (this.didFormattingToolabarTrue()) {
      case 'SIZETOFIT':
        WidthToChange = 0;
        lastShapeEnd = 0;
        selectedShape.map(shape => {
          if (
            shape.shape === shapeName.LINE ||
            shape.shape === shapeName.ARC ||
            shape.shape === shapeName.SQUARE ||
            shape.shape === shapeName.CIRCLE ||
            shape.shape === shapeName.POLYGON ||
            shape.shape === shapeName.SECTOR ||
            shape.shape === shapeName.FREE_HAND ||
            shape.shape === shapeName.SNAP
          ) {
            if (shape.dragedX !== undefined && shape.dragedX !== 0) {
              xCords.push(shape.X + shape.dragedY);
              xCords.push(shape.X + shape.width);
            } else if (shape.scaleX !== undefined && shape.scaleX !== 0) {
              xCords.push(shape.x);
              xCords.push(shape.x + shape.scaleX * shape.width);
            } else {
              xCords.push(shape.x);
              xCords.push(shape.x + shape.width);
            }
            numberOfShapes++;
          }
        });
        let xMin = Math.min.apply(null, xCords);
        let xMax = Math.max.apply(null, xCords);
        console.log('gow', xMin, xMax, numberOfShapes);
        WidthToChange = (xMax - xMin) / numberOfShapes;

        selectedShape.sort((a, b) => a.x - b.x);

        if (!isNaN(WidthToChange) && WidthToChange > 0) {
          selectedShape.map(shape => {
            if (selectedId.includes(shape.id)) {
              if (lastShapeEnd === 0) {
                switch (shape.shape) {
                  case shapeName.SQUARE:
                  case shapeName.CIRCLE:
                  case shapeName.LINE:
                  case shapeName.ARC:
                  case shapeName.SECTOR:
                    shape.width = WidthToChange;
                    shape.endX = shape.x + shape.width;
                    lastShapeEnd = shape.x + WidthToChange;
                    break;

                  case shapeName.POLYGON:
                  case shapeName.FREE_HAND:
                  case shapeName.SNAP:
                    lastShapeEnd = shape.x + WidthToChange;
                    break;

                  default:
                    break;
                }
              } else {
                switch (shape.shape) {
                  case shapeName.SQUARE:
                  case shapeName.CIRCLE:
                  case shapeName.LINE:
                  case shapeName.ARC:
                  case shapeName.SECTOR:
                    shape.x = lastShapeEnd;
                    shape.width = WidthToChange;
                    shape.endX = shape.x + shape.width;
                    lastShapeEnd = lastShapeEnd + shape.width;
                    break;

                  case shapeName.POLYGON:
                  case shapeName.FREE_HAND:
                  case shapeName.SNAP:
                    shape.dragedX = lastShapeEnd - shape.x;
                    lastShapeEnd = lastShapeEnd + WidthToChange;
                    break;

                  default:
                    break;
                }
              }
            }
          });
        }

        break;

      case 'ALIGNLEFT':
        cords = this.state.shapeCords;
        selectedShape.map(shape => {
          if (shape.dragedX !== undefined) {
            xCords.push(shape.x + shape.dragedX);
          } else {
            xCords.push(shape.x);
          }
        });
        xCords.sort((a, b) => a - b);
        let leftX = xCords[0];
        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            x = null;
            switch (shape.shape) {
              case shapeName.CIRCLE:
                shape.x = leftX;
                shape.endX = leftX + shape.width;
                break;

              case shapeName.LINE:
              case shapeName.ARC:
                shape.x = leftX;
                shape.endX = leftX + shape.width;
                break;

              case shapeName.SQUARE:
                shape.x = leftX;
                shape.endX = leftX + shape.width;
                break;

              case shapeName.SECTOR:
                x = shape.x;
                shape.dragedX = leftX - x;
                break;

              case shapeName.FREE_HAND:
                x = shape.x;
                shape.dragedX = leftX - x;
                break;

              case shapeName.SNAP:
              case shapeName.POLYGON:
                x = shape.x;
                shape.dragedX = leftX - x;
                break;

              default:
                break;
            }
          }
        });
        break;

      case 'ALIGNRIGHT':
        cords = this.state.shapeCords;
        selectedShape.map(shape => {
          if (shape.dragedX !== undefined) {
            xCords.push(shape.endX + shape.dragedX);
          } else {
            xCords.push(shape.endX);
          }
        });

        xCords.sort((a, b) => a - b);

        let rightX = xCords[xCords.length - 1];

        x = null;

        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            switch (shape.shape) {
              case shapeName.CIRCLE:
                shape.x = rightX - shape.width;
                shape.endX = rightX;
                break;

              case shapeName.SQUARE:
                shape.x = rightX - shape.width;
                shape.endX = rightX;
                break;

              case shapeName.LINE:
              case shapeName.ARC:
                if (shape.width < 0) {
                  shape.x = rightX;
                  shape.endX = rightX - Math.abs(shape.width);
                } else {
                  shape.x = rightX - shape.width;
                  shape.endX = rightX;
                }

                break;

              case shapeName.SECTOR:
                x = shape.x + shape.width;
                shape.dragedX = rightX - x;
                shape.endX = shape.x + shape.width;
                break;

              case shapeName.FREE_HAND:
              case shapeName.SNAP:
              case shapeName.POLYGON:
                x = shape.endX;
                shape.dragedX = rightX - x;
                shape.endX = shape.x + shape.width;
                break;

              default:
                break;
            }
          }
        });
        break;

      case 'ALIGNTOP':
        cords = this.state.shapeCords;

        selectedShape.map(shape => {
          if (shape.dragedY !== undefined && shape.dragedY !== 0) {
            yCords.push(shape.y + shape.dragedY);
          } else {
            yCords.push(shape.y);
          }
        });

        yCords.sort((a, b) => a - b);
        let topY = yCords[0];
        y = null;

        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            switch (shape.shape) {
              case shapeName.SQUARE:
                shape.y = topY;
                shape.endY = topY + shape.height;
                break;

              case shapeName.CIRCLE:
                shape.y = topY;
                shape.endY = topY + shape.height;
                break;

              case shapeName.LINE:
              case shapeName.ARC:
                shape.y = topY;
                shape.endY = topY + shape.height;
                break;

              case shapeName.SECTOR:
                y = shape.y;
                shape.dragedY = topY - y;
                break;

              case shapeName.FREE_HAND:
                y = shape.y;
                shape.dragedY = topY - y;
                break;

              case shapeName.SNAP:
              case shapeName.POLYGON:
                y = shape.y;
                shape.dragedY = topY - y;
                break;

              default:
                break;
            }
          }
        });

        break;

      case 'ALIGNBOTTOM':
        cords = this.state.shapeCords;
        selectedShape.map(shape => {
          if (shape.dragedY !== undefined && shape.dragedY !== 0) {
            yCords.push(shape.y + shape.height + shape.dragedY);
          } else if (shape.scaleX !== undefined && shape.scaleX !== 0) {
            yCords.push(shape.y + shape.scaleY * shape.height);
          } else {
            yCords.push(shape.y + shape.height);
          }
        });

        yCords.sort((a, b) => b - a);
        let bottomY = yCords[0];

        y = null;

        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            switch (shape.shape) {
              case shapeName.CIRCLE:
                shape.y = bottomY - shape.height;
                shape.endY = bottomY;
                break;

              case shapeName.SQUARE:
                shape.y = bottomY - shape.height;
                shape.endY = bottomY;
                break;

              case shapeName.LINE:
              case shapeName.ARC:
                shape.endY = bottomY;
                shape.y = bottomY - shape.height;
                break;

              case shapeName.SECTOR:
              case shapeName.FREE_HAND:
              case shapeName.SNAP:
              case shapeName.POLYGON:
                y = shape.endY;
                shape.dragedY = bottomY - y;
                break;

              default:
                break;
            }
          }
        });

        break;

      case 'HORIZONTALSPACING':
        this.props.horizontalSpacingClicked();
        spacing = this.state.horizontalSpacing;

        cords.sort((a, b) => a.x + a.dragedX - (b.x + b.dragedX));
        lastShapeEnd = 0;
        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            if (lastShapeEnd === 0) {
              lastShapeEnd = shape.x + shape.width;
            } else {
              switch (shape.shape) {
                case shapeName.SQUARE:
                case shapeName.CIRCLE:
                case shapeName.LINE:
                case shapeName.ARC:
                case shapeName.SECTOR:
                  shape.x = lastShapeEnd + spacing;
                  shape.endX = shape.x + shape.width;
                  lastShapeEnd = shape.endX;
                  break;

                case shapeName.FREE_HAND:
                case shapeName.SNAP:
                case shapeName.POLYGON:
                  let oldX = shape.x;
                  shape.x = lastShapeEnd + spacing;
                  shape.dragedX = lastShapeEnd + spacing - oldX;
                  lastShapeEnd = shape.endX + shape.dragedX;
                  break;

                default:
                  break;
              }
            }
          }
        });
        break;

      case 'VERTICALSPACING':
        this.props.verticalSpacingClicked();
        spacing = this.state.verticalSpacing;

        cords.sort((a, b) => a.y + a.dragedY - (b.y + b.dragedY));
        lastShapeEnd = 0;
        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            if (lastShapeEnd === 0) {
              lastShapeEnd = shape.y + shape.height;
            } else {
              switch (shape.shape) {
                case shapeName.SQUARE:
                case shapeName.CIRCLE:
                case shapeName.LINE:
                case shapeName.ARC:
                case shapeName.SECTOR:
                  shape.y = lastShapeEnd + spacing;
                  shape.endY = shape.y + shape.height;
                  lastShapeEnd = shape.endY;
                  break;

                case shapeName.FREE_HAND:
                case shapeName.SNAP:
                case shapeName.POLYGON:
                  let oldY = shape.y;
                  shape.y = lastShapeEnd + spacing;
                  shape.dragedY = lastShapeEnd + spacing - oldY;
                  lastShapeEnd = shape.endY + shape.dragedY;
                  break;

                default:
                  break;
              }
            }
          }
        });

        break;

      case 'HORIZONTALALIGNCENTER':
        selectedShape.sort((a, b) => a.x + a.dragedX - (b.x + b.dragedX));
        let xMiddle = 0;
        if (selectedShape[0] !== undefined) {
          xMiddle = (selectedShape[0].endY + selectedShape[0].y) / 2;
          cords.map(shape => {
            if (selectedId.includes(shape.id)) {
              switch (shape.shape) {
                case shapeName.SQUARE:
                  shape.y = xMiddle - shape.height / 2;
                  shape.endY = xMiddle + shape.height / 2;
                  break;

                case shapeName.CIRCLE:
                case shapeName.LINE:
                case shapeName.ARC:
                case shapeName.SECTOR:
                  shape.y = xMiddle - shape.height / 2;
                  shape.endY = xMiddle + shape.height / 2;
                  break;

                case shapeName.POLYGON:
                case shapeName.FREE_HAND:
                case shapeName.SNAP:
                  y = shape.y;
                  shape.dragedY = xMiddle - y - shape.height / 2;
                  break;

                default:
                  break;
              }
            }
          });
        }
        break;

      case 'VERTICALALIGNMIDDLE':
        selectedShape.sort((a, b) => a.y + a.dragedY - (b.y + b.dragedY));
        let yMiddle = 0;
        if (selectedShape[0] !== undefined) {
          yMiddle = (selectedShape[0].endX + selectedShape[0].x) / 2;

          cords.map(shape => {
            if (selectedId.includes(shape.id)) {
              switch (shape.shape) {
                case shapeName.SQUARE:
                case shapeName.CIRCLE:
                case shapeName.LINE:
                case shapeName.ARC:
                case shapeName.SECTOR:
                  shape.x = yMiddle - shape.width / 2;
                  shape.endX = yMiddle + shape.width / 2;
                  break;

                case shapeName.POLYGON:
                case shapeName.FREE_HAND:
                case shapeName.SNAP:
                  if (yMiddle - x - shape.width / 2 !== 0) {
                    x = shape.x;
                    shape.dragedX = yMiddle - x - shape.width / 2;
                  }
                  break;

                default:
                  break;
              }
            }
          });
        }
        break;

      case 'SIZETHIN':
        cords = this.state.shapeCords;
        selectedShape.map(shape => {
          if (shape.shape === shapeName.LINE || shape.shape === shapeName.SQUARE || shape.shape === shapeName.CIRCLE) {
            widthOfShapes.push(shape.width);
          }
        });

        widthOfShapes.sort((a, b) => a - b);
        WidthToChange = widthOfShapes[0];

        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            switch (shape.shape) {
              case shapeName.SQUARE:
                shape.width = WidthToChange;
                break;

              case shapeName.CIRCLE:
              case shapeName.LINE:
              case shapeName.ARC:
              case shapeName.SECTOR:
                shape.endX = shape.x + WidthToChange;
                break;

              default:
                break;
            }
          }
        });
        break;

      case 'SIZEWIDE':
        cords = this.state.shapeCords;
        selectedShape.map(shape => {
          if (shape.shape === shapeName.LINE || shape.shape === shapeName.SQUARE || shape.shape === shapeName.CIRCLE) {
            widthOfShapes.push(shape.width);
          }
        });

        widthOfShapes.sort((a, b) => b - a);
        WidthToChange = widthOfShapes[0];

        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            switch (shape.shape) {
              case shapeName.SQUARE:
                shape.width = WidthToChange;
                break;

              case shapeName.CIRCLE:
              case shapeName.LINE:
              case shapeName.SECTOR:
              case shapeName.ARC:
                shape.endX = shape.x + WidthToChange;
                break;

              default:
                break;
            }
          }
        });
        break;

      case 'SIZESHORT':
        cords = this.state.shapeCords;
        selectedShape.map(shape => {
          if (shape.shape === shapeName.LINE || shape.shape === shapeName.SQUARE || shape.shape === shapeName.CIRCLE) {
            heightOfShapes.push(shape.height);
          }
        });

        heightOfShapes.sort((a, b) => a - b);
        heightToChange = heightOfShapes[0];

        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            switch (shape.shape) {
              case shapeName.SQUARE:
                shape.height = heightToChange;
                break;

              case shapeName.CIRCLE:
              case shapeName.LINE:
              case shapeName.ARC:
              case shapeName.SECTOR:
                shape.endY = shape.y + heightToChange;
                break;

              default:
                break;
            }
          }
        });

        break;

      case 'SIZETALL':
        cords = this.state.shapeCords;
        selectedShape.map(shape => {
          if (shape.shape === shapeName.LINE || shape.shape === shapeName.SQUARE || shape.shape === shapeName.CIRCLE) {
            heightOfShapes.push(shape.height);
          }
        });

        heightOfShapes.sort((a, b) => b - a);
        heightToChange = heightOfShapes[0];

        cords.map(shape => {
          if (selectedId.includes(shape.id)) {
            switch (shape.shape) {
              case shapeName.SQUARE:
                shape.height = heightToChange;
                break;

              case shapeName.CIRCLE:
              case shapeName.LINE:
              case shapeName.ARC:
              case shapeName.SECTOR:
                shape.endY = shape.y + heightToChange;
                break;

              default:
                break;
            }
          }
        });

        break;
      case 'TEXTFONT':
        break;
      case 'FONTSIZE':
        break;
      case 'TEXTCOLOR':
        break;
      case 'BOLD':
        break;
      case 'ITALIC':
        break;
      case 'UNDERLINE':
        break;
      default:
        break;
    }

    this.props.doEmptyShapeAlignmentOperations();
    this.setState({
      shapeCords: cords,
    });
  };

  handleRenderGroupedShapes = () => {
    console.log('object');
    let groupCords = [];
    let selectedShapes = this.state.shapeCords.filter(t => (t.isSelected === true ? t : null));
    // groupCords.push(selectedShapes.filter(t => t.x));

    selectedShapes.filter(t => {
      groupCords.push(t.x, t.y, t.endX, t.endY);
    });

    if (this.state.groupCords === undefined) {
      this.setState({ groupCords: this.getStartAndEndCords(groupCords) }, () => {
        console.log('inn', this.state.groupCords);
      });
      this.setState({
        groupCount: Number(this.state.groupCount + Number(1)),
        groupedNo: Number(this.state.groupCount + Number(1)),
      });
    } else {
      let cordsData = this.state.groupCords.filter(function(element) {
        return element !== undefined;
      });
      if (cordsData.length === 0) {
        this.setState(
          {
            groupCords: this.getStartAndEndCords(groupCords),
            groupCount: Number(this.state.groupCount + Number(1)),
            groupedNo: Number(this.state.groupCount + Number(1)),
          },
          () => {
            console.log('corda', this.state.groupCords);
          },
        );
      }
    }
    this.state.shapeCords.filter(shape =>
      shape.isSelected === true
        ? ((shape['grouped'] = true),
          (shape['groupID'] =
            shape.groupID === undefined
              ? [`Group${Number(this.state.groupCount)}`]
              : [shape.groupID, `Group${Number(this.state.groupCount)}`]),
          (shape['group'] = this.getStartAndEndCords(groupCords)))
        : null,
    );
    this.props.handleClickedShape(shapeNameConst.GROUP);
    let group = [];
    this.state.groupCords = group;
  };

  didStandardToolabarTrue = () => {
    let shapeOps = this.state.shapeOperations;
    for (let key in shapeOps) {
      if (shapeOps[key]) {
        return key;
      }
    }
  };

  didFormattingToolabarTrue = () => {
    let shapeAlignMent = this.state.shapeAlignMent;
    for (let key in shapeAlignMent) {
      if (shapeAlignMent[key]) {
        return key;
      }
    }
  };

  didGroupShapeTrue = () => {
    let isGrouped = false;
    let groupShape = this.state.shapeCords;
    let grouped = groupShape.filter(shape => (shape.grouped === true ? true : false));
    return grouped.length > 0 ? (isGrouped = true) : isGrouped;
  };
  didShapeAlignTrue = () => {
    let alignShape = this.state.shapeAlignMent;
    let isAlign = false;
    for (let key in alignShape) {
      if (alignShape[key]) {
        isAlign = true;
      }
    }
    return isAlign;
  };

  didTextHavingStyles = () => {
    let textOperations = this.state.textOperations;
    let applyStyles = false;

    if (textOperations !== null) {
      console.log('shp didTextHavingStyles');
      for (let [style, value] of Object.entries(textOperations)) {
        if (value.length > 0 || typeof value === 'object') {
          applyStyles = true;
        }
      }
    }
    return applyStyles;
  };

  renderGroup = () => {
    console.log('obj', this.state.groupCords.length);
    return (
      <>
        <Rect
          // draggable={true}
          x={this.state?.groupCords[0]}
          y={this.state?.groupCords[1]}
          width={this.state?.groupCords[2] - this.state?.groupCords[0]}
          height={this.state?.groupCords[3] - this.state?.groupCords[1]}
          stroke={'grey'}
          strokeWidth={0.5}
        />
        {/* <Transformer node={this.state.shapeCords.map(shape => shape.grouped === true && shape)}></Transformer> */}
      </>
    );
  };

  handleTextEdit = () => {
    this.refs.editText.style.width = 'auto';
    this.refs.editText.style.height = 'auto';
  };

  handleTextBlur = (e, id) => {
    let cords = this.state.shapeCords;
    let textCords = [];
    if (id) {
      document.getElementById(id).remove();
    } else {
      if (this.refs.editText.innerHTML !== null || this.refs.editText.innerHTML !== '') {
        cords.push({
          id: this.state.activeShape + '_' + (cords.length + 1),
          x: this.state.textXPosition,
          y: this.state.textYPosition,
          isSelected: false,
          draggable: false,
          transformEnabled: false,
          endX: this.state.textXPosition + this.refs.editText.offsetWidth,
          endY: this.state.textYPosition + this.refs.editText.offsetHeight,
          height: this.refs.editText.offsetHeight,
          width: this.refs.editText.offsetWidth,
          textValue: this.refs.editText.innerText,
          textXPosition: this.state.textXPosition,
          textYPosition: this.state.textYPosition,
          shape: this.state.activeShape,
          fontSize: this.state.fontSize,
          fontFamily: this.state.fontFamily,
          fontStyle: this.state.fontStyle,
          fontVariant: this.state.fontVariant,
          textDecoration: this.state.textDecoration,
        });
        this.setState({
          shapeCords: cords,
          textEditVisible: false,
          textXPosition: 0,
          textYPosition: 0,
          startPoint: {},
        });
      }
      this.refs.editText.innerHTML = '';
      this.refs.editText.style.width = '100px';
      this.refs.editText.style.height = '50px';
    }
  };

  renderText = shape => {
    console.log('text', shape);
    var elem = this.refs.text;
    if (elem.innerHTML !== null) {
      elem.innerHTML = '';
    }
    elem.innerHTML = shape.textValue;
    elem.setAttribute('style', 'position:absolute');
    elem.setAttribute('height', shape.height);
    elem.setAttribute('width', shape.width);
    console.log('text', this.refs.text);
    html2canvas(this.refs.text).then(canvas => {
      var c = this.state.baseCanvas;
      var ctx = c.getContext('2d');
      ctx.drawImage(canvas, shape.textXPosition, shape.textYPosition, shape.width, shape.height);
    });
    elem.innerHTML = '';
  };

  handleTextChanges = id => {
    let selectedShape = null;

    this.state.shapeCords.map(shape => {
      if (shape.id === id) {
        selectedShape = shape;
      }
    });
    console.log('shp', selectedShape);
    var konvaStage = document.getElementsByClassName('konvajs-content');
    var div = document.createElement('div');
    konvaStage[0].appendChild(div);
    div.contentEditable = true;
    div.style.position = 'absolute';
    div.style.backgroundColor = 'white';
    div.style.width = selectedShape.width + 'px';
    div.style.height = selectedShape.height + 'px';
    div.id = id;
    div.style.left = selectedShape.textXPosition + 'px';
    div.style.top = selectedShape.textYPosition + 'px';
    div.style.color = selectedShape.fill;
    div.style.fontFamily = selectedShape.fontFamily;
    div.style.fontSize = selectedShape.fontSize;
    div.style.fontStyle = selectedShape.fontStyle;
    div.innerText = selectedShape.textValue;
    div.addEventListener('blur', e => this.handleTextBlur(e, id));
    div.addEventListener('keydown', e => this.handleTextEditKeydown(e, id));
    div.focus();
    console.log('aaa', div);
  };

  handleTextEditKeydown = (e, id) => {
    let cords = this.state.shapeCords;
    cords.map(shape => {
      if (shape.id === id) {
        var elem = document.getElementById(id);
        console.log('aaa', elem.offsetWidth, elem.offsetHeight);
        shape.textValue = elem.innerText;
        shape.height = elem.offsetHeight;
        shape.width = elem.offsetWidth;
      }
    });
    this.setState({
      shapeCords: cords,
    });
  };

  renderTextByFillText = shape => {
    console.log('renderTextByFillText');
    var canvas = this.state.baseCanvas;
    var context = canvas.getContext('2d');
    console.log(context);
    context.font = 'bold 16px Arial';
    context.fillText(shape.textValue, shape.textXPosition, shape.textYPosition);
  };

  renderKonvaText = shape => {
    return (
      <Text
        text={shape.textValue}
        x={shape.textXPosition}
        y={shape.textYPosition}
        width={shape.width}
        height={shape.height}
        fontSize={shape.fontSize}
        fontFamily={shape.fontFamily}
      />
    );
  };

  handleDropLine = () => {
    if (this.state.shapeCords.length > 1) {
      let group = this.state.shapeCords.filter(cords =>
        cords.isSelected === true && cords.grouped === true ? (cords['isSelected'] = false) : cords,
      );

      this.setState({
        // shapeCords: group,
        // selectedId: [],
        groupCords: [],
      });
    }
  };

  dragStartFalse = value => {
    // if (this.state.dragStart) {
    this.setState({
      dragStart: value,
    });
    // }
  };

  drawRoundedRect = () => {
    if (this.state.roundedRect === true) {
      // this.state.roundedRect = false;
    }
  };
  drawingAreaResponsive = () => {
    if (this.state.formatting_toolbar === false && this.state.standard_toolbar === false) {
      return 550;
    } else if (this.state.formatting_toolbar === false) {
      return 530;
    } else if (this.state.standard_toolbar === false) {
      return 520;
    } else {
      return 490;
    }
  };

  render() {
    console.log(this.props.handleRoundedRectClicked);
    // lets think you want to make all your objects visible in
    // 700x700 scene
    const CANVAS_VIRTUAL_WIDTH = 100;
    const CANVAS_VIRTUAL_HEIGHT = 500;

    // now you may want to make it visible even on small screens
    // we can just scale it
    // const scale = Math.min(window.innerWidth / CANVAS_VIRTUAL_WIDTH, window.innerHeight / CANVAS_VIRTUAL_HEIGHT);

    return (
      <div>
        {/* <div ref="text"></div> */}
        <Stage
          className="stageClass"
          width={window.innerWidth}
          height={window.innerHeight}
          // height={this.drawingAreaResponsive()}
          // width={this.props.showTreeExplorer === false ? 1110 : this.props.drawing_toolbar === false ? 990 : 915}
          onMouseDown={this.handleMouseDown}
          onMouseMove={this.handleMouseMove}
          onMouseUp={this.handleMouseUp}
          onClick={e => this.handleClick(e)}
          onDblClick={this.handleDblClick}
        >
          <Layer>
            {(this.state.activeShape === shapeName.SELECT || this.state.activeShape === shapeName.TRANSFORM) && (
              <Rect
                x={this.state.endingPoint.x && this.state.startingPoint.x}
                y={this.state.endingPoint.y && this.state.startingPoint.y}
                height={this.state.isSelectFinished ? 0 : this.state.endingPoint.y - this.state.startingPoint.y}
                width={this.state.isSelectFinished ? 0 : this.state.endingPoint.x - this.state.startingPoint.x}
                stroke="black"
                strokeWidth={0.5}
                dash={[5, 5]}
              />
            )}
            {this.state.groupCords !== undefined && this.state.groupCords.length > 0 && this.state.shapeCords.length > 0
              ? this.renderGroup()
              : null}

            {this.state.defaultActiveShapeName != null && this.state.displayGridComponent}

            {/* {this.props.roundedRectangle === true && this.drawRoundedRect()} */}

            {this.state.roundedRect && this.drawRoundedRect()}

            {this.didShapeAlignTrue() && this.alignShapes()}
            {this.didTextHavingStyles() && this.applyStylesForText()}
            {this.state.standardToolbarClickedShape === true && this.handleRenderGroupedShapes()}

            {this.state.shapeCords.length > 0 &&
              this.state.shapeCords?.map((shape, i) => {
                switch (shape.shape) {
                  case shapeName.SQUARE:
                    // this.props.showCurveInputField();
                    return (
                      <DrawRectangle
                        key={i}
                        {...shape}
                        index={i}
                        handleUpdatedDrag={this.handleUpdatedDrag}
                        dragStartFalse={this.dragStartFalse}
                      />
                    );

                  case shapeName.CIRCLE:
                    return (
                      <DrawEllipse
                        key={i}
                        {...shape}
                        index={i}
                        handleUpdatedDrag={this.handleUpdatedDrag}
                        dragStartFalse={this.dragStartFalse}
                      />
                    );

                  case shapeName.SECTOR:
                    return (
                      <DrawSector
                        key={i}
                        {...shape}
                        index={i}
                        handleUpdatedDrag={this.handleUpdatedDrag}
                        dragStartFalse={this.dragStartFalse}
                      />
                    );

                  case shapeName.POLYGON:
                    return (
                      <DrawPolygon
                        key={i}
                        index={i}
                        {...shape}
                        points={!shape?.isClosed ? shape.points.concat(this.state.mousePosition) : shape.points}
                        handleUpdatedDrag={this.handleUpdatedDrag}
                        dragStartFalse={this.dragStartFalse}
                      />
                    );

                  case shapeName.ARC:
                    return (
                      <FinalArc
                        key={i}
                        {...shape}
                        index={i}
                        handleDropLine={this.handleDropLine}
                        updateArcEndPoint={this.updateArcEndPoint}
                        handleUpdatedDrag={this.handleUpdatedDrag}
                        dragStartFalse={this.dragStartFalse}
                      />
                    );

                  case shapeName.LINE:
                    return (
                      <FinalArc
                        key={i}
                        {...shape}
                        index={i}
                        handleDropLine={this.handleDropLine}
                        updateArcEndPoint={this.updateArcEndPoint}
                        shapeType={shapeName.LINE}
                        handleUpdatedDrag={this.handleUpdatedDrag}
                        dragStartFalse={this.dragStartFalse}
                      />
                    );

                  case shapeName.FREE_HAND:
                    return (
                      <Pencil
                        key={i}
                        {...shape}
                        updateFreeHand={this.updateFreeHand}
                        index={i}
                        handleUpdatedDrag={this.handleUpdatedDrag}
                        dragStartFalse={this.dragStartFalse}
                      />
                    );

                  case shapeName.SNAP:
                    return (
                      <DrawSnap
                        key={i}
                        index={i}
                        {...shape}
                        points={shape.points}
                        handleUpdatedDrag={this.handleUpdatedDrag}
                        dragStartFalse={this.dragStartFalse}
                      />
                    );

                  case shapeName.TEXT:
                    return (
                      <GetText
                        key={i}
                        {...shape}
                        text={shape.textValue}
                        x={shape.x}
                        y={shape.y}
                        width={shape.width}
                        height={shape.height}
                        fontSize={shape.fontSize}
                        fontFamily={shape.fontFamily}
                        fontStyle={shape.fontStyle}
                        fontVariant={shape.fontVariant}
                        fill={shape.fill}
                        textDecoration={shape.textDecoration}
                        align={shape.align}
                        wrap={shape.wrap}
                        onKeyDown={this.handleTextEdit}
                        handleUpdatedDrag={this.handleUpdatedDrag}
                        onDblClick={this.handleTextChanges}
                      />
                    );

                  case shapeName.IMAGE:
                    // console.log('image----', shape);
                    return <Image key={i} index={i} image={shape.imageSource} draggable={true} {...shape} />;
                  default:
                    break;
                }
              })}
          </Layer>
        </Stage>
        <div
          contentEditable={true}
          id="editableDiv"
          ref="editText"
          style={{
            display: this.state.textEditVisible ? 'block' : 'none',
            position: 'absolute',
            left: this.state.textXPosition,
            top: this.state.textYPosition,
            border: '1px dashed black',
            height: '50px',
            width: '100px',
          }}
          onKeyDown={this.handleTextEdit}
          onBlur={this.handleTextBlur}
        ></div>
      </div>
    );
  }
}
export default DrawingEditor;
