import React from 'react';
import styled from '@emotion/styled';
import Element from '../../utils/element';
// import { variant } from 'styled-system';
import css from '@styled-system/css';
// import designerLayout from '../../../tokens/components/gpDesignerLayout';
import { layout as designerLayout } from '../../../tokens/components/';
const StyledLayout = styled(Element)(props => css(designerLayout(props)));

const Layout = props => (
  <StyledLayout {...props}>
    {props.children}
    {/* <div className="wrapper">jdsadsadsa</div> */}
  </StyledLayout>
);

export default Layout;
