import React from 'react';
import GpLayout from './layout';
import './index.css';
// import Menu from './menu';
const Index = props => {
  return (
    <GpLayout>
      <ul>
        <li>Home</li>
        <li>
          Front End Design
          <ul>
            <li>HTML</li>
            <li>
              CSS
              <ul>
                <li>Resets</li>
                <li>Grids</li>
                <li>Frameworks</li>
              </ul>
            </li>
          </ul>
          <ul>
            <li>Ajax</li>
            <li>jQuery</li>
          </ul>
        </li>

        <li>
          WordPress Development
          <ul>
            <li>Themes</li>
            <li>Plugins</li>
            <li>
              Custom Post Types
              <ul>
                <li>Portfolios</li>
                <li>Testimonials</li>
              </ul>
            </li>
            <li>Options</li>
          </ul>
        </li>
      </ul>
    </GpLayout>
  );
};
export default Index;
