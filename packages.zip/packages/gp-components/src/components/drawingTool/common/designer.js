import React, { Component } from 'react';
import { Container, Col, Row } from 'react-bootstrap';
import styled from '@emotion/styled';
import Element from '../../utils/element';
import css from '@styled-system/css';
import { layout as designerLayout } from '../../../tokens/components';
import DrawingToolbar from './drawingToolbar';
import Menu from './menu';

import DrawingArea from './drawingArea';
import StandardToolbar from './standardToolbar';
import FormattingToolbar from './formattingToolbar';

// import { Tooltip } from '@gp/components';
// import DatePicker from 'react-datepicker';

import 'react-datepicker/dist/react-datepicker.css';
class DesignerLayout extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeShape: null,
    };
  }
  renderLayout = () => <Col md={12}></Col>;

  handleActiveShape = shape => {
    this.setState({
      activeShape: shape,
    });
  };
  toggle = () => {
    this.component.setOpen(this.focus);
    this.focus = !this.focus;
  };
  render() {
    const StyledDesingerLayout = styled(Element)(props => css(designerLayout(props)));

    return (
      <Container fluid={true}>
        <Row>
          <Col md={9}>
            <Menu></Menu>
          </Col>
          {/* <Col md={3}>
            <Row>
              <div className="input-group">
                <div class="input-group-prepend">
                  <div class="input-group-text">#</div>
                </div>
                <div class="react-datepicker-wrapper">
                  <div class="react-datepicker__input-container">
                    <DatePicker />
                  </div>
                </div>
              </div>
            </Row>
          </Col> */}
          <Col md={9}>
            <StandardToolbar handleActiveShape={this.handleActiveShape}></StandardToolbar>
          </Col>
          <Col md={9}>
            <FormattingToolbar ></FormattingToolbar>
          </Col>
          {/* <Col md={2}>
            <Tooltip tooltipHeader="test" tooltipText="dsaasd"></Tooltip>
            <DrawingToolbar handleActiveShape={this.handleActiveShape}></DrawingToolbar>
          </Col> */}
          <Col md={12}>
            <Row>
              <Col md={1}>
                <DrawingToolbar handleActiveShape={this.handleActiveShape} ></DrawingToolbar>
              </Col>
              <Col md={8}>
                {/* <Tooltip tooltipHeader="test" tooltipText="dsaasd"></Tooltip> */}
                <DrawingArea activeShape={this.state.activeShape}></DrawingArea>
              </Col>
            </Row>
          </Col>
        </Row>
      </Container>
    );
  }
}
export default DesignerLayout;
