import React, { Component } from 'react';
import styled from '@emotion/styled';
import { StyledElement } from '../../utils/element';
// import { variant } from 'styled-system';
import css from '@styled-system/css';
// import designerLayout from '../../../tokens/components/gpDesignerLayout';
// import { Tabs, Tab } from 'react-bootstrap';
// import Tabs from './tabs';
import 'bootstrap/dist/css/bootstrap.min.css';
import Icon from '../../icons/Icon';
import { layout as designerLayout } from '../../../tokens/components/';
// import './tabs.css';
import DrawingEditor from './drawingEditor';
import { Col, Nav, Tab, Row, OverlayTrigger, Tooltip } from 'react-bootstrap';
// import Tooltip from '../../Tooltip/tooltip';
import { GpModal, SampleMessage } from './../../../index';

import { tooltipStyle } from '../../../tokens/components/';

const ToolTipElement = StyledElement('div')(tooltipStyle);

const StyledDrawingArea = StyledElement('nav')(designerLayout);
class DrawingArea extends Component {
  constructor(props) {
    super(props);

    this.state = {
      DrawingEditorComponent: null,
      tabs: [
        {
          id: 1,
          title: 'BayType',
          component: <DrawingEditor {...this.props} />,
          src: 'treeIcon.DESIGNER_BAY_TYPE',
          active: true,
        },
        {
          id: 2,
          title: 'Layout',
          component: '',
          src: 'drawingToolIcons.flight',
          active: false,
        },
        {
          id: 3,
          title: 'Galley',
          component: '',
          src: 'treeIcon.DESIGNER_GALLEY',
          active: false,
        },
      ],
      defaultActiveTab: null,
    };
  }
  // componentDidUpdate = () => {
  //   console.log('object', this.state);
  // };
  handleClick = e => {
    this.setState({ selectedId: e });
  };
  deleteTabs = data => {
    console.log('called', data);
    const deleteTab = this.state.tabs.filter(item => item.id !== data.id);
    console.log(deleteTab);
    this.setState(
      {
        tabs: deleteTab,
      },
      () => {
        this.handleCloseAllTabs();
        // this.handleActiveTabs(deleteTab);
        if (deleteTab.length > 0) {
          console.log(document.getElementsByClassName('nav-link')[0].click());
        }
      },
    );
  };
  handleCloseAllTabs = () => {
    if (this.state.tabs.length === 0) {
      this.props.handleCloseTabs();
    } else {
      this.setState(
        {
          defaultActiveTab: this.state.tabs[0],
        },
        () => {
          console.log('test', this.state.defaultActiveTab);
        },
      );
    }
  };
  handleActiveTabs = key => {
    let filteredTabs = this.state.tabs.filter(t => (t.title === key ? (t['active'] = true) : t));

    this.setState(
      {
        defaultActiveTab: filteredTabs,
      },
      () => {
        // alert('sec');
      },
    );
  };

  refreshClicked = () => {
    this.props.refreshClicked();
  };
  // zoomFunClicked = () => {
  //   this.props.zoomFunClicked();
  // };

  renderDrawingArea = data => {
    let filteredTabs = this.state.tabs.filter(t => (t.id !== data.id ? t : null));
    console.log(data);
    return (
      <Tab.Pane eventKey={data.title}>
        <DrawingEditor fileName={data.title} {...this.props} />
      </Tab.Pane>
    );
  };

  TooltipTopNavItem = ({ title, tooltipMessage, eventKey }) => {
    const styles = {
      background: 'blue',
    };
    return (
      <OverlayTrigger
        // flip={true}
        key={`${eventKey}-top`}
        placement={'top'}
        overlay={
          <Tooltip
            style={{ marginTop: '-30px', fontSize: '12px', lineHeight: '0.8', zIndex: '1' }}
            placement={'top'}
            className="my_tooltip"
            id={`tooltip-top`}
          >
            {tooltipMessage}
          </Tooltip>
        }
      >
        <Nav.Item>
          <Nav.Link eventKey={eventKey}>
            <Icon
              style={{ position: 'absolute', marginLeft: '-45px', marginTop: '-5px', width: '14px', height: '14px' }}
              icon={title.src}
            />
            {tooltipMessage}
            <Icon
              style={{ marginTop: '-4px', position: 'absolute', marginLeft: '33px' }}
              icon="drawingToolIcons.greyCloseButton"
              width="13"
              height="13"
              onClick={e => {
                this.deleteTabs(title);
              }}
            />
          </Nav.Link>
        </Nav.Item>
      </OverlayTrigger>
    );
  };
  render() {
    // let defaultActiveTab = ;
    return (
      <>
        <StyledDrawingArea
          {...this.props}
          style={{
            zIndex: '0',
            position: 'absolute',
            width: 'auto',

            // height: this.props.standard_toolbar === false || this.props.formatting_toolbar === false ? '90vh' : '85vh',
            marginLeft: this.props.drawing_toolbar === false ? '-12px' : '-16px',
            marginTop: '4px',
            // background: '#C0C0C0',
            // overflow: 'scroll',
          }}
          className="drawingArea"
        >
          {/* <Tabs>
          {tabs.map((item, index) => (
            <div key={index} label={item.title}>
              {item.component}
            </div>
          ))}
        </Tabs> */}
          {this.state.tabs.length > 0 ? (
            <Tab.Container
              id="left-tabs-example"
              defaultActiveKey={
                this.state.defaultActiveTab === null ? this.state.tabs[0].title : this.state.defaultActiveTab.title
              }
              // activeKey={
              //   this.state.defaultActiveTab === null ? this.state.tabs[0].title : this.state.defaultActiveTab.title
              // }
              onSelect={k => this.handleActiveTabs(k)}
            >
              <>
                <Nav
                  variant="tabs"
                  className="nav nav-tabs"
                  // style={{ margin: this.props.drawing_toolbar === false ? '0px' : '0px 76px' }}
                >
                  {this.state.tabs.map((data, index) => (
                    <this.TooltipTopNavItem
                      title={data}
                      tooltipMessage={data.title}
                      deleteTab={this.deleteTabs}
                      eventKey={data.title}
                    />
                    // <Nav.Item>
                    //   <Nav.Link key="" eventKey={data.title}>
                    //     <Tooltip
                    //       eventKey={data.title}
                    //       tooltipHeader={data.title}
                    //       deleteTabs={this.deleteTabs}
                    //       tooltip={data}
                    //     ></Tooltip>
                    //   </Nav.Link>
                    // </Nav.Item>
                  ))}
                </Nav>
                <Tab.Content>
                  {this.state.tabs.map((data, index) => (data.active === true ? this.renderDrawingArea(data) : null))}
                </Tab.Content>
              </>
            </Tab.Container>
          ) : (
            <React.Fragment></React.Fragment>
          )}
        </StyledDrawingArea>
      </>
    );
  }
}

export default DrawingArea;
