import React from 'react';
import Icon from '../../icons/Icon';
import Tooltip from '../../Tooltip/tooltip';
const gpTab = props => {
  console.log(props);
  //   console.log(props);
  //   static propTypes = {
  //     activeTab: PropTypes.string.isRequired,
  //     label: PropTypes.string.isRequired,
  //     onClick: PropTypes.func.isRequired,
  //   };
  const onClick = e => {
    // console.log(document.getElementById(e).remove());
    const { label, onClick } = props;
    onClick(label);
  };
  const deleteTabs = title => {
    document.getElementById(title).remove();
    onClick();
  };
  let className = 'tab-list-item';

  if (props.activeTab === props.label) {
    className += ' tab-list-active';
  }
  return (
    <p
      id={props.id}
      //   title={props.label}
      className={className}
      onClick={() => {
        onClick(props.label);
      }}
    >
      <Icon
        style={{ margin: '5px', float: 'right' }}
        icon="greyCloseButton"
        onClick={() => {
          deleteTabs(props.label);
        }}
      />
      <Tooltip tooltipHeader={props.label} tooltipText={props.label}></Tooltip>
      {/* {props.label} */}
    </p>
  );
  //   ) : (
  //     <p title={props.label} className={className} onClick={onClick}>
  //       {props.label}
  //     </p>
  //   );
};

export default gpTab;
