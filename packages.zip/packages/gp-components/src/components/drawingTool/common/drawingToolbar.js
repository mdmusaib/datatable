import React, { Component } from 'react';
import styled from '@emotion/styled';
import Element from '../../utils/element';
import Icon from '../../icons/Icon';
import css from '@styled-system/css';
import shapeName from './shapeNameConst';

import { layout as designerLayout } from '../../../tokens/components/';
import { Form, Row, Col } from 'react-bootstrap';
const StyledDrawingToolbar = styled(Element)(props => css(designerLayout(props)));

class DrawingToolbar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      toolClicked: false,
      data: [
        {
          shapeName: shapeName.SELECT,
          title: shapeName.SELECT,
          src: 'shapeSelect',
          icon: 'square',
          type: 'svg',
          className: 'first',
        },
        {
          shapeName: shapeName.TRANSFORM,
          title: shapeName.TRANSFORM,
          src: 'shapeTransform',
          type: 'svg',
          icon: 'rect',
          className: 'second',
        },
        {
          shapeName: shapeName.LINE,
          title: shapeName.LINE,
          src: 'shapeLine',
          type: 'svg',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: shapeName.ARC,
          title: shapeName.ARC,
          src: 'shapeCurve',
          type: 'svg',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: shapeName.SQUARE,
          title: shapeName.SQUARE,
          src: 'shapeRectangle',
          type: 'svg',
          icon: 'shapes',
          className: 'third',
        },
        {
          title: shapeName.CIRCLE,
          src: 'shapeEllipse',
          type: 'svg',
          icon: 'shapes',
          className: 'third',
          shapeName: shapeName.CIRCLE,
        },
        {
          title: shapeName.POLYGON,
          shapeName: shapeName.POLYGON,
          type: 'svg',
          src: 'shapePolygon',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: shapeName.SECTOR,
          title: shapeName.SECTOR,
          type: 'svg',
          src: 'shapeSector',
          icon: 'shapes',
          className: 'third',
        },
        // {
        //   title: shapeName.FREE_HAND,
        //   shapeName: shapeName.FREE_HAND,
        //   src: 'drawingToolIcons.pencil_rollout',
        //   icon: 'shapes',
        //   className: 'third',
        // },
        // {
        //   shapeName: shapeName.SNAP,
        //   title: shapeName.SNAP,
        //   src: 'drawingToolIcons.snapTool_rollout',
        //   icon: 'shapes',
        //   className: 'third',
        // },
        {
          shapeName: shapeName.TEXT,
          title: shapeName.TEXT,
          src: 'shapeText',
          type: 'svg',
          icon: 'shapes',
          className: 'third',
        },
      ],
      data1: [
        {
          // shapeName: 'lineColor',
          title: 'Line color',
          src: 'drawingToolIcons.lineColor',
          icon: 'shape3s',
          className: 't321hird',
          action: 'back',
        },
        {
          shapeName: 'lineColor',
          title: 'Line colour',
          src: 'drawingToolIcons.lineColor',
          icon: 'shape321s',
          className: 'thi321rd',
        },

        {
          title: 'displayNone',
          src: 'drawingToolIcons.',
          icon: 'shape43s',
          className: 'th42ird',
        },
        {
          // shapeName: 'fillColor1',
          title: 'Fill color',
          src: 'drawingToolIcons.fillColor',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: 'fillColour',
          title: 'Fill colour',
          src: 'drawingToolIcons.fill',
          icon: 'shapes',
          className: 'third',
        },
        {
          title: 'Fill',
          src: 'drawingToolIcons.gradient',
          icon: 'shapes43',
          className: 'thir434d',
        },
        {
          // shapeName: 'gradient',
          title: 'Gradient fill color',
          src: 'drawingToolIcons.gradient',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: 'gradientFillColour',
          title: 'Gradient fill color',
          src: 'drawingToolIcons.gradient-fill-color',
          icon: 'shapes',
          className: 'third',
        },
        {
          shapeName: 'gradientFill',
          title: 'Gradient fill',
          data: 'gradientFill',
          src: 'drawingToolIcons.gradient',
          icon: 'shapes',
          className: 'third',
        },
      ],
      activeShape: this.props.activeShape,
      inputColor: null,
      roundedRectangle: props?.roundedRectangle,
    };
  }

  componentWillReceiveProps(props) {
    this.setState(
      {
        activeShape: props.activeShape,
        emptyId: props.emptySelected,
      },
      () => {
        this.openColorPicker();
        this.handleEmpty();
      },
    );
  }

  openColorPicker = () => {
    switch (this.props.activeShape) {
      case 'lineColour':
        this.refs.lineColor.click();

        break;
      case 'fillColour':
        this.refs.fillColour.click();
        this.refs.Fill.setAttribute('checked', true);
        break;
      case 'gradientFillColour':
        this.refs.gradientFillColour.click();
        this.refs.gradientFill.setAttribute('checked', true);
        break;
      default:
        return null;
    }
  };

  handleClick = (event, shape) => {
    this.setState(
      {
        activeShape: shape,
        emptyId: !this.props.emptySelected,
      },
      () => {
        this.props.handleActiveShape(this.state.activeShape);
        this.handleEmpty();
      },
    );
  };

  // componentDidUpdate() {

  // }

  handleCheckboxChange = (e, type) => {
    console.log(e, type);
    console.log('type', type);
    switch (type) {
      case 'Fill':
        if (this.refs.Fill.checked === true) {
          console.log(this.refs.fillColour.value, this.refs.fillColour.name);
          this.props.handleProps(this.refs.fillColour.value, this.refs.fillColour.name);
        } else if (this.refs.Fill.checked === false && this.refs.gradientFill.checked === true) {
          console.log('fill', this.refs.Fill.checked);
          this.refs.gradientFill.checked = false;
          this.props.handleProps(null, this.refs.fillColour.name);
          this.props.handleProps(null, this.refs.gradientFillColour.name);
        } else {
          this.props.handleProps(null, this.refs.fillColour.name);
        }
        break;
      // return this.refs.Fill.checked === true
      //   ? this.props.handleProps(this.refs.fillColour.value, this.refs.fillColour.name)
      //   : this.props.handleProps(null, this.refs.fillColour.name);

      case 'Gradient fill':
        if (this.refs.gradientFill.checked === true && this.refs.Fill.checked === false) {
          this.refs.Fill.checked = true;
          this.props.handleProps(this.refs.fillColour.value, this.refs.fillColour.name);
          this.props.handleProps(this.refs.gradientFillColour.value, this.refs.gradientFillColour.name);
        } else if (this.refs.gradientFill.checked == true && this.refs.Fill.checked === true) {
          this.props.handleProps(this.refs.gradientFillColour.value, this.refs.gradientFillColour.name);
        } else {
          this.props.handleProps(null, this.refs.gradientFillColour.name);
        }
        break;

      default:
        break;
    }
    // console.log(e.target.checked, type === 'Fill' ? this.refs.fillColour.value : this.refs.gradientFillColour.value);
  };
  handleChange = (e, type) => {
    console.log(e.target.value, type);
    switch (type) {
      case 'stroke':
        if (e.target.value > 99) {
        } else {
          return this.props.handleProps(e.target.value, type);
        }
        break;
      case 'curve':
        return this.props.handleProps(e.target.value, type);

      case 'lineColor':
        return this.props.handleProps(e.target.value, type);

      case 'fillColour':
        return this.refs.Fill.checked === true ? this.props.handleProps(e.target.value, type) : null;

      case 'gradientFillColour':
        return this.refs.gradientFill.checked === true ? this.props.handleProps(e.target.value, type) : null;

      default:
        break;
    }
  };

  drawRoundedRect = (e, type) => {
    return this.props.handleRoundedRect();
  };

  handleEmpty = () => {
    if (this.state.emptyId) {
      console.log(this.state.emptyId);
      this.props.handleSelectedId(true);
    } else {
      this.props.handleSelectedId(false);
    }
  };

  handleKeyPress = e => {
    var value = Number(e.target.value);

    if (value > 99) {
      return false;
    } else {
    }
  };

  render() {
    return (
      <StyledDrawingToolbar {...this.props}>
        <Row>
          <div className="drawingToolbarStyle" style={{}}>
            {/* <div className="drawingBox"> */}
            {/* <Icon icon="drawingToolIcons.blueHeader" width="100" height="30" /> */}
            <div className="drawingToolbar">
              {this.state.data.map(data =>
                data.shapeName === shapeName.ROUNDED ? (
                  <span
                    title={data.title}
                    className={this.state.activeShape === data.shapeName ? 'currentShape' : data.className}
                    onClick={e => this.handleClick(e, data.shapeName)}
                  >
                    {alert(data.shapeName)}
                    <Icon
                      type={data.type}
                      svgIconColor={this.state.activeShape === data.shapeName ? 'svgIconColorLight' : 'grey'}
                      width={15}
                      height={15}
                      icon={data.src}
                    />
                  </span>
                ) : (
                  <span
                    title={data.title}
                    className={this.state.activeShape === data.shapeName ? 'currentShape' : data.className}
                    onClick={e => this.handleClick(e, data.shapeName)}
                  >
                    <Icon
                      type={data.type}
                      svgIconColor={this.state.activeShape === data.shapeName ? 'svgIconColorLight' : 'grey'}
                      width={15}
                      height={15}
                      icon={data.src}
                    />
                  </span>
                ),
              )}
            </div>
            <hr></hr>
            <div className="colorShapes">
              {this.state.data1.map(data => (
                <span title={data.title} className={data.className}>
                  {data.shapeName === 'lineColor' ||
                  data.shapeName === 'fillColour' ||
                  data.shapeName === 'gradientFillColour' ? (
                    <>
                      <input
                        type="color"
                        list={data.title}
                        id={data.shapeName}
                        ref={data.shapeName}
                        name={data.shapeName}
                        value={this.state.inputColor}
                        onChange={e => this.handleChange(e, data.shapeName)}
                      />
                      <datalist id={data.title}>
                        <option>red</option>
                        <option>blue</option>
                        <option>green</option>
                        <option>yellow</option>
                        <option>orange</option>
                        <option>white</option>
                        <option>black</option>
                      </datalist>
                    </>
                  ) : data.title === 'Fill' || data.shapeName === 'gradientFill' ? (
                    <input
                      style={{ marginTop: '8px' }}
                      type="checkbox"
                      id={data.title === 'Gradient fill' ? data.data : data.title}
                      ref={data.title === 'Gradient fill' ? data.data : data.title}
                      onClick={e => this.handleCheckboxChange(e, data.title)}
                    />
                  ) : (
                    <Icon
                      style={{ display: data.title === 'displayNone' ? 'none' : 'block' }}
                      icon={data.src}
                      className={this.state.activeShape === data.shapeName ? 'currentShape' : ''}
                      // onClick={e => this.handleClick(e, data.shapeName)}
                    />
                  )}
                </span>
              ))}
            </div>
            <hr></hr>
            <div className="strokeInputs">
              <Form.Group controlId="formStrokes">
                <Form.Label>Stroke</Form.Label>
                <Form.Control
                  title="Stroke width"
                  style={{ width: '53px', height: '25px', fontFamily: 'workSans' }}
                  type="number"
                  id="strokeInput"
                  defaultValue={1}
                  onChange={e => this.handleChange(e, 'stroke')}
                  min="1"
                  max="50"
                />
              </Form.Group>
              {this.props.activeShape === shapeName.CIRCLE ||
              this.props.activeShape === shapeName.POLYGON ||
              this.state.activeShape === shapeName.LINE ||
              this.state.activeShape === shapeName.ARC ||
              this.state.activeShape === shapeName.SECTOR ||
              this.state.activeShape === shapeName.TEXT ||
              // this.state.activeShape === shapeName.TRANSFORM ||
              this.props.roundedRectangle === shapeName.ROUNDED ||
              this.state.activeShape === null ? (
                // <div style={{ height: '100px' }}></div>
                <></>
              ) : (
                <Form.Group id="curveField">
                  <Form.Label>Curve</Form.Label>
                  <Form.Control
                    title="Curve"
                    style={{ width: '53px', height: '25px', display: 'block', fontFamily: 'workSans' }}
                    type="number"
                    id="curveInput"
                    onKeyPress={e => this.handleKeyPress(e)}
                    ref="curveInput"
                    defaultValue={0}
                    onChange={e => this.handleChange(e, 'curve')}
                    min="0"
                    max="99"
                  />
                  {this.props.activeShape !== shapeName.SQUARE && <div style={{ height: '100px' }}></div>}
                </Form.Group>
              )}

              {/* rounded rectangle */}
              {this.props.roundedRectangle === shapeName.ROUNDED ? (
                <Form.Group id="curveField">
                  <Form.Label>Curve</Form.Label>
                  <Form.Control
                    title="Curve"
                    style={{ width: '63px', height: '25px', display: 'block' }}
                    type="number"
                    id="curveInput"
                    ref="curveInput"
                    defaultValue={30}
                    onChange={e => this.handleChange(e, 'curve')}
                    min="0"
                    max="100"
                  />
                  {this.drawRoundedRect(30, 'curve')}
                  {this.props.activeShape !== shapeName.SQUARE && <div style={{ height: '100px' }}></div>}
                </Form.Group>
              ) : (
                <div style={{ height: '100px' }}></div>
              )}
            </div>
          </div>
          {/* </div> */}
        </Row>
      </StyledDrawingToolbar>
    );
  }
}

export default DrawingToolbar;
