import React, { Component } from 'react';
import { StyledElement } from '../../utils/element';
import { menu as designerMenu } from '../../../tokens/components/';
import Icon from '../../icons/Icon';
import shapeName from './shapeNameConst';
import shapeNameConst from './shapeNameConst';
// import './menu.css';
const StyledMenu = StyledElement('div')(designerMenu);
class Menu extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dropdownEnable: false,
      // activeShape: false,
      toolbar: false,
      clickedShape: false,
    };
  }

  // handleclickMenu = (e, shape) => {
  //   // console.log(shape);
  //   this.setState(
  //     {
  //       activeShape: shape,
  //     },
  //     () => this.props.handleActiveShape(this.state.activeShape),
  //   );
  // };

  handleclickMenu = (e, shape) => {
    if (shape === shapeNameConst.ROUNDED) {
      this.setState(
        {
          clickedShape: true,
        },
        () => {
          if (this.props.activeShape === shapeName.SQUARE) {
          } else {
            // this.props.handleProps(30, 'curve');
            this.props.handleActiveShape(shapeNameConst.SQUARE);
          }

          this.props.handleRoundedRectClicked(this.state.clickedShape);
        },
      );
    }

    if (shape === shapeNameConst.SQUARE) {
      this.setState(
        {
          sqaureFromMenu: true,
        },
        () => {
          // this.props.handleProps(0, 'curve');
          this.props.handleActiveShape(shape);
          this.props.handleSquareFromMenu(this.state.sqaureFromMenu);
        },
      );
    }

    // if (e.target.innerText !== '') {
    //   if (e.target.getAttribute('title') === shapeName.ROUNDED) {
    //     // this.props.drawRoundedRectangle();
    //     console.log('shapes', shapeName.ROUNDED);
    //     this.setState(
    //       {
    //         clickedShape: true,
    //       },
    //       () => {
    //         if (this.props.activeShape === shapeName.SQUARE) {
    //         } else {
    //           this.props.handleActiveShape(shape);
    //         }

    //         this.props.handleRoundedRectClicked(this.state.clickedShape);
    //       },
    //     );
    //     // this.props.handleProps(30, 'curve');
    //   }
    // } else {
    //   if (e.target.getAttribute('title') === shape) {
    //     // this.props.handleProps(30, 'curve');
    //     this.setState(
    //       {
    //         clickedShape: true,
    //       },
    //       () => {
    //         this.props.handleActiveShape(shape);
    //         this.props.handleRoundedRectClicked(this.state.clickedShape);
    //       },
    //     );
    //   }
    // }

    // apply  transparent  color for selected shape

    if (shape === 'Transparent') {
      this.props.handleProps('transparent', 'fillColour');
      document.getElementById('Fill').checked = false;
      document.getElementById('gradientFill').checked = false;
    }

    if (shape === shapeNameConst.DISPLAYGRID) {
      this.props.defaultActiveShape(shape);
    } else if (shape === shapeNameConst.ALIGNGRID) {
      this.props.alignGridActiveShape(shape);
    } else {
      console.log(shape);
      this.props.handleClickedShape(shape);
    }

    if (shape === 'formatting_toolbar' || shape === 'drawing_toolbar' || shape === 'standard_toolbar') {
      this.setState(
        {
          toolbar: true,
        },
        () => {
          this.props.handleToolbarClickedShape(shape, this.state.toolbar);
        },
      );
    }

    if (shape === shapeNameConst.GROUP) {
      this.setState(
        {
          standardToolbarClickedShape: !this.props.standardToolbarClickedShape,
        },
        () => {
          this.props.handleClickedShape(this.state.standardToolbarClickedShape);
        },
      );
    } else {
      console.log('shape', shape);
      this.props.handleClickedShape(shape);
    }
    if (shape === shapeNameConst.INSERTIMAGE) {
      // console.log('called!!!!');
      let fileElem = document.createElement('input');
      fileElem.style.display = 'none';
      fileElem.setAttribute('type', 'file');
      fileElem.addEventListener('change', e => {
        this.handleInsertImageClick(e, shape);
      });
      document.body.appendChild(fileElem);
      console.log(fileElem.click());
      // fileElem.change();
      // console.log(this.refs.upload.click());
    }

    if (
      shape === shapeNameConst.CIRCLE ||
      shape === shapeNameConst.POLYGON ||
      shape === shapeNameConst.ARC ||
      shape === shapeNameConst.SECTOR ||
      shape === shapeNameConst.FREE_HAND ||
      shape === shapeNameConst.SNAP ||
      shape === shapeNameConst.LINE
    ) {
      this.props.handleActiveShape(shape);
    }

    if (shape === 'fillColour') {
      document.getElementById('fillColour').click();
      // document.getElementById('Fill').checked = true;
    } else if (shape === 'gradientFillColour') {
      document.getElementById('gradientFillColour').click();
      // document.getElementById('gradientFill').checked = true;
    } else if (shape === 'lineColour') {
      document.getElementById('lineColor').click();
    }
  };

  handleInsertImageClick = (event, shape) => {
    console.log(shape, event);
    event.stopPropagation();
    event.preventDefault();
    let imageSource = null;
    let file = event.target.files;
    [...file].map(file => {
      imageSource = URL.createObjectURL(file);
    });
    console.log('images', imageSource);
    this.props.handleInsertImageClick(shape, imageSource);

    // this.setState({
    //     imageSource
    // })

    //console.log('--------', this.state.imageSource);
    console.log('--------', imageSource);
    // this.props.handleInsertImageClick(shape, imageSource);
    //this.props.handleActiveShape(shape);
  };
  render() {
    const data = [
      {
        id: '1',
        menuTitle: 'File',
        menuIcon: '',
        menuConfig: '',

        subMenu: [
          {
            id: '2',
            shapeName: shapeNameConst.SAVE,
            menuTitle: 'Save',
            type: 'svg',
            menuIcon: 'floppyDisk',

            menuConfig: '',
            subMenu: false,
          },
          {
            id: '4',
            shapeName: shapeNameConst.SAVEASIMAGE,
            menuTitle: 'Save as Image File',
            menuIcon: 'saveImageAS',
            type: 'svg',
            menuConfig: '',

            subMenu: false,
          },
          {
            id: '5',
            shapeName: shapeNameConst.INSERTIMAGE,
            menuTitle: 'Insert Image',
            menuIcon: 'insertImage',
            event: true,
            type: 'svg',
            menuClassName: 'vl',
            subMenu: false,
          },
          {
            id: '6',
            shapeName: shapeNameConst.PRINT,
            menuTitle: 'Print',
            menuIcon: 'printer',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
        ],
      },
      {
        id: '2',
        menuTitle: 'Edit',
        menuIcon: '',

        menuConfig: '',
        subMenu: [
          {
            id: '2',
            shapeName: shapeNameConst.UNDO,
            menuTitle: 'Undo',
            menuIcon: 'undo',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.REDO,
            menuTitle: 'Redo',
            menuIcon: 'redo',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.REFRESH,
            menuTitle: 'Refresh',
            menuIcon: 'multimedia',
            type: 'svg',
            menuConfig: '',
            menuClassName: 'vl',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.CUT,
            menuTitle: 'Cut',
            menuIcon: 'cut',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.COPY,
            menuTitle: 'Copy',
            menuIcon: 'file1',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.PASTE,
            menuTitle: 'Paste',
            menuIcon: 'paste',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.DUPLICATE,
            menuTitle: 'Duplicate',
            menuIcon: 'duplicate',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
            menuClassName: 'vl',
          },
          {
            id: '2',
            shapeName: shapeNameConst.DELETE,
            menuTitle: 'Delete',
            menuIcon: 'delete',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.CLEARALL,
            menuTitle: 'Clear',
            menuIcon: 'clearAll',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
            menuClassName: 'vl',
          },
          {
            id: '2',
            shapeName: shapeNameConst.GROUP,
            menuTitle: 'Group',
            menuIcon: 'group',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.UNGROUP,
            menuTitle: 'ungroup',
            menuIcon: 'unGroup',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
            menuClassName: 'vl',
          },
          {
            id: '2',
            shapeName: shapeNameConst.BRINGTOFRONT,
            menuTitle: 'Bring to Front',
            menuIcon: 'bringToFront',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.SENDTOBACK,
            menuTitle: 'Send to Back',
            menuIcon: 'sendToBack',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
        ],
      },
      {
        id: '3',
        menuTitle: 'View',
        menuIcon: '',
        menuConfig: '',
        subMenu: [
          {
            id: '2',
            shapeName: shapeNameConst.NORMAL,
            menuTitle: 'Normal',
            menuIcon: 'zoomReset',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.ZOOMIN,
            menuTitle: 'Zoom In',
            menuIcon: 'zoomIn',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.ZOOMOUT,
            menuTitle: 'Zoom Out',
            menuIcon: 'zoomOut',
            type: 'svg',
            menuConfig: '',
            subMenu: false,
            menuClassName: 'vl',
          },
          {
            id: '2',
            menuTitle: 'Standard Toolbar',
            shapeName: 'standard_toolbar',
            menuIcon: '',
            menuClassName: this.props.standard_toolbar,
            menuConfig: '',
            subMenu: false,
            tick: this.props.standard_toolbar ? true : false,
          },
          {
            id: '2',
            menuTitle: 'Drawing Toolbar',
            shapeName: 'drawing_toolbar',
            menuClassName: this.props.drawing_toolbar,
            menuIcon: '',
            menuConfig: '',
            subMenu: false,
            tick: this.props.drawing_toolbar ? true : false,
          },
          {
            id: '2',
            menuTitle: 'Formatting Toolbar',
            shapeName: 'formatting_toolbar',
            menuClassName: this.props.formatting_toolbar,
            menuIcon: '',
            menuConfig: '',
            subMenu: false,
            tick: this.props.formatting_toolbar ? true : false,
          },
        ],
      },
      {
        id: '4',
        menuTitle: 'Drawing',
        menuIcon: '',
        menuConfig: '',
        subMenu: [
          {
            id: '2',
            menuTitle: 'Square/Rectangle',
            shapeName: shapeName.SQUARE,
            menuIcon: 'drawingToolIcons.square',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            menuTitle: 'Rounded Rectangle',
            Rounded: shapeName.ROUNDED,
            menuIcon: 'drawingToolIcons.rectangle',
            shapeName: shapeName.ROUNDED,
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            menuTitle: 'Circle/Ellipse',
            menuIcon: 'drawingToolIcons.circle',
            menuConfig: '',
            shapeName: shapeName.CIRCLE,
            subMenu: false,
          },
          {
            id: '2',
            menuTitle: 'Polygon',
            menuIcon: 'drawingToolIcons.polygonTool',
            menuConfig: '',
            shapeName: shapeName.POLYGON,
            subMenu: false,
          },
          {
            id: '2',
            menuTitle: 'Sector',
            menuIcon: 'drawingToolIcons.sector',
            menuConfig: '',
            shapeName: shapeName.SECTOR,
            subMenu: false,
          },
          {
            id: '2',
            menuTitle: 'Text',
            menuIcon: 'drawingToolIcons.textTool',
            menuConfig: '',
            shapeName: shapeName.TEXT,
            subMenu: false,
            menuClassName: 'vl',
          },
          {
            id: '2',
            menuTitle: 'Line',
            menuIcon: 'drawingToolIcons.line',
            menuConfig: '',
            shapeName: shapeName.LINE,
            subMenu: false,
          },
          // {
          //   id: '2',
          //   menuTitle: 'Freehand Line',
          //   menuIcon: 'drawingToolIcons.freehand',
          //   shapeName: shapeName.FREE_HAND,
          //   menuConfig: '',
          //   subMenu: false,
          // },
          {
            id: '2',
            menuTitle: 'Arc',
            menuIcon: 'drawingToolIcons.arc',
            menuConfig: '',
            shapeName: shapeName.ARC,
            subMenu: false,
          },
          {
            id: '2',
            menuTitle: 'Transparent',
            shapeName: 'Transparent',
            menuIcon: 'drawingToolIcons.transparent',

            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            menuTitle: 'Line Color',
            menuIcon: 'drawingToolIcons.lineColor',
            shapeName: 'lineColour',
            menuConfig: '',
            subMenu: false,
          },
          {
            id: '2',
            menuTitle: 'Fill Color',
            menuIcon: 'drawingToolIcons.fillColor',
            menuConfig: '',
            shapeName: 'fillColour',
            subMenu: false,
          },
          {
            id: '2',
            menuTitle: 'Gradient Fill',
            menuIcon: 'drawingToolIcons.gradient',
            menuConfig: '',
            shapeName: 'gradientFillColour',
            subMenu: false,
          },
        ],
      },
      {
        id: '5',
        menuTitle: 'Formatting',
        menuIcon: '',
        menuConfig: '',
        menuClassName: 'Formatting_menu',
        subMenu: [
          {
            id: '2',
            menuTitle: 'Align',
            menuIcon: 'drawingToolIcons.alignLeft',
            menuClassName: '',
            menuConfig: 'arrow',
            subMenu: [
              {
                id: '2',
                shapeName: shapeNameConst.ALIGNLEFT,
                menuTitle: 'Align Left',
                menuIcon: 'drawingToolIcons.alignLeft',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.ALIGNRIGHT,
                menuTitle: 'Align Right',
                menuIcon: 'drawingToolIcons.alignRight',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.ALIGNTOP,
                menuTitle: 'Align Top',
                menuIcon: 'drawingToolIcons.alignTop',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.ALIGNBOTTOM,
                menuTitle: 'Align Bottom',
                menuIcon: 'drawingToolIcons.alignbottom',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.VERTICALALIGNMIDDLE,
                menuTitle: 'Verticle Align Middle',
                menuIcon: 'drawingToolIcons.verticalAlignMiddle',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.HORIZONTALALIGNCENTER,
                menuTitle: 'Horizontal Align Center',
                menuIcon: 'drawingToolIcons.horizontalAlignCenter',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.VERTICALSPACING,
                menuTitle: 'Vertical Spacing',
                menuIcon: 'drawingToolIcons.verticalSpacing',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.HORIZONTALSPACING,
                menuTitle: 'Horizontal Spacing',
                menuIcon: 'drawingToolIcons.horizontalSpacing',
                menuConfig: '',
                subMenu: false,
              },
            ],
          },
          {
            id: '2',
            menuTitle: 'Size Formatting',
            menuIcon: 'drawingToolIcons.setSize',
            menuClassName: 'vl',
            menuConfig: 'arrow',
            subMenu: [
              {
                id: '2',
                shapeName: shapeNameConst.SIZETOFIT,
                menuTitle: 'Size to fit',
                menuIcon: 'drawingToolIcons.sizeToFit',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.SIZETHIN,
                menuTitle: 'Size Thin',
                menuIcon: 'drawingToolIcons.sizeThin',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.SIZEWIDE,
                menuTitle: 'Size Wide',
                menuIcon: 'drawingToolIcons.sizeWide',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.SIZESHORT,
                menuTitle: 'Size Short',
                menuIcon: 'drawingToolIcons.sizeShort',
                menuConfig: '',
                subMenu: false,
              },
              {
                id: '2',
                shapeName: shapeNameConst.SIZETALL,
                menuTitle: 'Size Tall',
                menuIcon: 'drawingToolIcons.sizeTall',
                menuConfig: '',
                subMenu: false,
              },
            ],
          },
          {
            id: '2',
            shapeName: shapeNameConst.TEXTCOLOR,
            menuTitle: 'Text Color',
            menuIcon: 'drawingToolIcons.setSize',
            menuConfig: 'textColor',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.TEXTFONT,
            menuTitle: 'Text Font',
            menuIcon: 'drawingToolIcons.textFont',
            menuConfig: '',
            subMenu: false,
            menuClassName: 'vl',
          },
          {
            id: '2',
            shapeName: shapeNameConst.ALIGNGRID,
            menuTitle: 'Align Grid',
            menuIcon: 'drawingToolIcons.alignGrid',
            menuConfig: 'textFont',
            subMenu: false,
          },
          {
            id: '2',
            shapeName: shapeNameConst.DISPLAYGRID,
            menuTitle: 'Display Grid',
            menuIcon: 'drawingToolIcons.alignGrid',
            menuConfig: 'textFont',
            subMenu: false,
          },
        ],
      },
    ];

    // const Menu = props =>  {...props}>{props.children}</StyledMenu>;
    return (
      <StyledMenu>
        <ul id="nav">
          {data.map((menu, index) => (
            <>
              <li
                key={index}
                className={menu.menuClassName}
                onClick={() => this.setState({ dropdownEnable: !this.state.dropdownEnable })}
              >
                {menu.menuIcon}
                {menu.menuTitle}

                {this.state.dropdownEnable && menu.subMenu && (
                  <ul>
                    {menu.subMenu.map((subMenuList, index) => (
                      <>
                        <li
                          key={index}
                          className={subMenuList.menuClassName}
                          onClick={e => this.handleclickMenu(e, subMenuList.shapeName)}
                        >
                          {/* insert image */}

                          {/* {subMenuList.event !== undefined && (
                            <input
                              type="file"
                              id="img"
                              ref={'upload'}
                              style={{ display: 'none' }}
                              onChange={e => {
                                this.handleInsertImageClick(e, data.shapeName);
                              }}
                            />
                          )} */}
                          {subMenuList.shapeName === 'standard_toolbar' ||
                          subMenuList.shapeName === 'drawing_toolbar' ||
                          subMenuList.shapeName === 'formatting_toolbar' ? (
                            <span>
                              {subMenuList.tick ? (
                                <>
                                  <Icon icon="drawingToolIcons.tick" />
                                  &nbsp;&nbsp;
                                  {subMenuList.menuTitle}
                                  {subMenuList.menuConfig === 'arrow' ? <i className="right"></i> : ''}
                                </>
                              ) : (
                                <span>
                                  <Icon icon={subMenuList.menuIcon} />
                                  &nbsp;&nbsp;&nbsp;&nbsp;
                                  {subMenuList.menuTitle}
                                </span>
                              )}
                            </span>
                          ) : (
                            <span title={subMenuList?.Rounded}>
                              <Icon title={subMenuList?.Rounded} type={subMenuList.type} icon={subMenuList.menuIcon} />
                              &nbsp;&nbsp;
                              {subMenuList.menuTitle}
                              {subMenuList.menuConfig === 'arrow' ? <i className="right"></i> : ''}
                            </span>
                          )}

                          <>
                            <ul>
                              {subMenuList.subMenu &&
                                subMenuList?.subMenu?.map((nestedMenuList, index) => (
                                  <li
                                    key={index}
                                    onClick={e => this.handleclickMenu(e, nestedMenuList.shapeName)}
                                    className={nestedMenuList.menuClassName}
                                  >
                                    <Icon icon={nestedMenuList.menuIcon} />
                                    &nbsp;&nbsp;{nestedMenuList.menuTitle}
                                  </li>
                                ))}
                            </ul>
                          </>
                        </li>
                      </>
                    ))}
                  </ul>
                )}
              </li>
            </>
          ))}
        </ul>
      </StyledMenu>
    );
  }
}
export default Menu;
