export default {
  textTransform: 'uppercase',
};
