import { themeGet as get } from '@styled-system/theme-get';

/* Colors */
import colors from './colors';

/* Variants */
import colorStyles from './color-styles';

/* Spacing */
const space = [0, 4, 8, 16, 32, 48, 64];
space.overlap = -1;

/* Size */
const sizes = [16, 24, 36, 48, 64, 96, 144];
sizes.clickable = sizes[5];
sizes.button = { small: sizes[1], default: sizes[2], large: sizes[3] };
sizes.avatar = { small: sizes[2], medium: sizes[5], large: sizes[6] };

/* Typography */
const fontSizes = [12, 14, 16, 18, 20, 24, 32, 48, 64, 72, '1rem'];
fontSizes.base = fontSizes[2];
fontSizes.small = fontSizes[1];
fontSizes.icon = fontSizes[5];
fontSizes.baseSize = fontSizes[10];

const fontWeights = {
  normal: 100,
  semibold: 500,
  bold: 800,
};

fontWeights.paxiaLight = 300;

const shadows = {
  small: '0 0 4px rgba(0, 0, 0, .125)',
  medium: '0px 8px 15px rgba(0, 0, 0, 0.1)',
  tileShadow: '0px 8px 15px rgba(0, 0, 0, 0.1)',
};

const fonts = ['Work Sans', 'Roboto'];
fonts.workSans = fonts[0];
fonts.roboto = fonts[1];

/* Misc */
const radii = [0, 2, 5, 10, '50%'];

const tokens = {
  space,
  sizes,
  colors,
  radii,
  fontSizes,
  fontWeights,
  fonts,
  colorStyles,
  shadows,
};

export default tokens;
export { get };
