import common from '../common';
import colors from '../colors';

export default {
  ...common,
  bg: colors.paxia.brand_light_blue,

  toolbarContainer: {
    backgroundColor: colors.paxia.brand_light_blue,
    //width: '100%',
    height: '40px',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    //position: 'relative',
    //left: '5px',
    marginLeft: '5px',
    marginRight: '5px',
    borderBottomLeftRadius: '10px',
    borderBottomRightRadius: '10px',
  },

  toolbarIconStyle: {
    cursor: 'pointer',
    display: 'flex',
    justifyContent: 'space-around',
    width: '28%',
    pl: 2,
  },
};
