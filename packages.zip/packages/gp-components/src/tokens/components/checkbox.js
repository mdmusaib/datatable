import colors from '../colors';

export default props => ({
  padding: '0',
  width: '100%',
  margin: 'auto 0',
  margin: '0px 15px 6px',
  position: 'relative',
  fontFamily: 'Work Sans',
  '& label': {
    fontSize: '11px',
    padding: '0 5px',
    position: 'absolute',
    top: '16px',
    left: '20px',
    color: colors.paxia.grey_31,
    fontWeight: '600',
  },

  '& .CheckBox': {
    position: 'relative',
    visibility: 'hidden',
    position: 'absolute',
    left: '0px',
    top: '16px',
    borderRadius: '50%',
    backgroundColor: '#121212',
  },

  '& .CheckBox::before, .CheckBox': {
    content: "''",
    visibility: 'hidden',
  },

  '& .CheckBox::before, .CheckBox::before': {
    content: "''",
    visibility: 'visible',
    width: '15px',
    height: '15px',
    border: props.component ? `1px solid ${colors.paxia_grid.grey_27}` : `1px solid ${colors.paxia.grey_31}`,
    /* border-radius: 10px', */
    backgroundColor: props.component ? 'white' : 'transparent',
    position: 'absolute',
    top: '0px',
    transition: '.4s',
    cursor: 'pointer',
  },

  '& .CheckBox::after, .CheckBox::after': {
    content: "''",
    visibility: 'hidden',
    display: 'block',
    position: 'absolute',
    top: '3px',
    left: '5px',
    width: '5px',
    height: '8px',
    border: 'solid #eee',
    borderWidth: '0 2px 2px 0',
    transform: 'rotate(45deg)',
    // -webkit-transition: .2s',
    transition: '.2s',
  },

  '& .CheckBox:checked::before': {
    content: "''",
    backgroundColor: '#006098 ',
  },

  '& .CheckBox:checked::after, .CheckBox:checked::before': {
    content: "''",
    backgroundColor: '#006098 ',
  },

  '& .CheckBox:checked::after': {
    content: "''",
    visibility: 'visible',
    border: 'solid white',
    borderWidth: '0 2px 2px 0',
    transform: 'rotate(45deg)',
  },
});
