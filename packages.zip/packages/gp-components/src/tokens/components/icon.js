import colors from '../colors';
export default {
  iconStyle: props => ({
    width: props.width ? props.width + 'px' : '16px',
    height: props.height ? props.height + 'px' : '16px',
  }),
  svgIconStyle: props => ({
    fill: colors.paxia[props.svgIconColor] !== undefined ? colors.paxia[props.svgIconColor] : props.svgIconColor,
    stroke: props.svgStroke ? colors.paxia[props.svgStroke] : null,
    width: props.width ? props.width + 'px' : '20px',
    height: props.height ? props.height + 'px' : '20px',
    transform: 'rotate(' + props.rotate !== undefined ? props.rotate : 0 + ')',
  }),
  svgIconButtonStyle: props => ({
    '&:hover > svg': {
      //fill: colors.paxia.accent_green,
      transform: 'scale(.93)',
      transition: 'all 100ms ease',
    },
  }),
};
