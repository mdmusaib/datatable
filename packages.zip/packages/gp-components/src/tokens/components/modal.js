import common from '../common';
import colors from '../colors'
import {
    bottom
} from 'styled-system';
export default props => ({
    position: 'absolute',
    zIndex: '500',
    backgroundColor: 'white',
    width: props.fullScreenModal ? 'auto' : props.modalWidth,
    // boxShadow: '1px 1px 1px black',
    margin: 'auto',
    top: props.fullScreenModal && props.FormatModal ? '0%' : props.FormatModal ? '12%' : '30%',
    left: props.fullScreenModal ? '3%' : '0',
    right: '0',
    // bottom: '0',
    boxSizing: 'border-box',
    // transition: 'all 0.3s ease-out',
    height: props.fullScreenModal ? 'auto' : props.modalHeight,
    fontFamily: 'Work Sans',
    '& .ModalContainer': {
        padding: '0',
        margin: '0',
        color: colors.white,
        height: '100%'
    },

    '& .ModalHeading': {
        position: 'relative',
        display: 'flex',
        paddingLeft: '15px',
        margin: 'auto',
        backgroundColor: colors.paxia.brand_light_blue,
        height: '25px',
        fontSize: '12px',
        lineHeight: '25px',
        verticalAlign: 'middle',
        fontWeight: '500',
        marginBottom: '6px'
    },

    '& .ModalHeading > p': {
        margin: '0',
        fontSize: '11px'
    },

    '& .ModalIcons': {
        textAlign: 'right'
    },
    '& .ModalBody': {
        height: 'calc(100% - 31px)'
    },
    '& .ModalHeadingIcon': {
        position: 'absolute',
        right: '10px'
    }

})