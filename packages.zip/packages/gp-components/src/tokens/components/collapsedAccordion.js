import colors from './../colors';

export default {
  height: '30px',
  backgroundColor: colors.paxia.brand_light_blue,
  fontSize: '13px',
  width: '100%',
  display: 'flex',
  alignItems: 'center',
  position: 'relative',
  cursor: 'pointer',
  zIndex: '1',
  borderTopLeftRadius: '10px',
  borderTopRightRadius: '10px',

  '& .AccordionTitle': {
    color: 'white',
    fontFamily: 'work Sans',
    paddingLeft: '10px',
  },

  '& .CollapsedIcon': {
    marginLeft: '7px',
    /* margin: 0 auto; */
    transfom: 'rotate(45deg)',
    transform: 'rotate(-90deg)',
  },
};
