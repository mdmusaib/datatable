import colors from './../colors'
export default props => ({
    // display: 'flex',
    width: '40%',
    position: 'relative',
    margin: '0px 15px 6px',
    fontFamily: 'Work Sans',
    '& select': {
        padding: '4px',
        fontSize: '12px',
        width: '100%',
        border: props.inValid ? `1px solid ${colors.reds[0]}` : `1px solid  ${colors.paxia.grey_27}`,
        position: 'absolute',
        right: '0',
        top: '20px',
        borderRadius: '3px'
    },
    '& label': {
        fontSize: '11px',
        padding: '0 5px 0 0',
        color: colors.paxia.grey_31,
        fontWeight: '600',
        width: '20%', ///AFTER REMOVING ROW COL CONTAINER
        textAlign: 'center',
        position: 'absolute',
        top: '0',
        left: '0',
        // color: '#9b9b9b',
        // fontWeight: '600'

    },
    'select option:checked, select option:hover': {
        backgroundColor: '#7FCEFF'
    },
    '::selection': {
        backgroundColor: 'green'
    },
})