import colors from '../colors';
import { flex } from 'styled-system';
import { unstable_batchedUpdates } from 'react-dom';
export default {
  SideBar: props => {
    return Object.assign(
      {
        left: 0,
        paddingTop: '5px',
        position: 'fixed',
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        backgroundColor: colors.paxia.brand_light_blue,
        width: '40px',
        //borderRight: '1px solid',
        // borderColor: colors.paxia.grey_28,
        //width: props.isExpanded ? '200px' : '50px',
        transition: 'width  0.3s ease',
        boxShadow: '3px 0 5px rgba(0, 0, 0, 0.1)',
        zIndex: 10001,
        '&:hover': {
          //width: '200px',
          //boxShadow: '3px 0 5px rgba(0, 0, 0, 0.3)',
        },
        '& >  div > span': {
          display: 'none',
        },
        '&:hover >  div > span': {
          //display: 'block',
        },
      },
      props.isExpanded
        ? {
            '&:hover': {
              width: '205px',
              boxShadow: '3px 0 5px rgba(0, 0, 0, 0.3)',
            },
            '&:hover >  div > span': {
              display: 'block',
            },
          }
        : null,
    );
  },
  SideNavItem: props => {
    return Object.assign(
      {
        cursor: 'pointer',
        //width: '100%',
        //width: '40px',
        //height: '50px',
        height: '30px',
        margin: '2px 5px',
        borderRadius: '20px',
        display: 'flex',
        justifyContent: 'left',
        alignItems: 'center',
        transition: 'all  0.3s ease',
        backgroundColor: props.selected ? colors.paxia.light : '#0475b6',
        // border: '1px solid',
        //borderColor: props.selected ? colors.paxia.accent_eggplant : colors.paxia.grey_28,
        color: props.selected ? colors.paxia.grey : colors.paxia.white,
        '&:hover': {
          bg: colors.paxia.accent_blue,
        },
        '&:hover > svg': {
          fill: colors.paxia.white,
        },
        '& > img ,& > svg': {
          marginLeft: '5px',
          fill: props.selected ? colors.paxia.accent_eggplant : colors.paxia.white,
          minWidth: '20px',
        },
        '& > span': {
          //display: 'none',
          fontFamily: 'roboto',
          marginTop: '0px',
          flexGrow: '1',
          marginLeft: '5px',
          fontSize: '12px',
          fontWeight: '500',
          minWidth: props.tabWidth !== undefined ? props.tabWidth - 60 + 'px' : '100px',
          width: 'auto',
        },
        '&:hover > div': {
          display: 'inline-block',
        },
      },
      !props.isExpanded
        ? {
            width: '30px',
            color: colors.paxia.white,
            '&:hover': {
              bg: colors.paxia.accent_blue,
              //backgroundImage: 'linear-gradient(270deg,#00bed6,#3f3a60)',
              width: props.tabWidth !== undefined ? props.tabWidth + 'px' : '160px',
              boxShadow: '3px 0 5px rgba(0, 0, 0, 0.3)',
            },
            '&:hover > span': {
              display: 'inline-block',
            },
          }
        : null,
    );
  },
  NavItemClose: props => ({
    //display: props.showClose ? 'inline-block' : 'none',
    display: 'none',
    minWidth: '20px',
    height: '20px',
    marginRight: '5px',
    // paddingRight: '10px',
    borderRadius: '50%',
    bg: 'white',
    transition: 'all  0.3s ease',
    '&:hover': {
      bg: colors.paxia.grey,
    },
    //position: 'absolute',
    //right: '5px',
    boxShadow: '0px 1px 3px rgb(0,0,0,0.3)',
    '& > span': {
      color: colors.paxia.grey,
      position: 'relative',
      left: '6px',
      top: '-4px',
    },
    '&:hover  > span': {
      color: colors.paxia.white,
    },
  }),
  Pin: props => ({
    marginTop: 'auto',
  }),
};
