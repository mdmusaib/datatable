import colors from '../colors';
import common from '../common';
export default {
  '.drawingTool': {
    background: '#cfd2d3',
    opacity: '0.5',
    pointerEvents: 'none',
  },

  '.canvasStyle': {
    width: '400px',
  },
};
