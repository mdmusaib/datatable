import common from '../common';

export default {
  ...common,

  printStyle: {
    padding: 1,
  },
};
