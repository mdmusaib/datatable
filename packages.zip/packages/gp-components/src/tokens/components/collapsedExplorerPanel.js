export default props =>
  props.leftCollapse
    ? {
        height: '100vh',
        backgroundColor: '#0976b6e6',
        fontSize: '13px',
        width: '3%',
        display: 'inline-block',
        position: 'relative',
        marginTop: '5px',
        marginLeft: '5px',
        marginRight: '5px',
        borderTopLeftRadius: '10px',
        '& .CollapsedIcon': {
          position: 'absolute',
          /* margin: 0 auto; */
          transfom: 'rotate(270deg)',
          left: '10px',
          top: '5px',
          transform: 'rotate(180deg)',
        },
        '& h3': {
          transform: 'rotate(-90deg)',
          fontSize: '11px',
          color: 'white',
          letterSpacing: '3px',
          position: 'absolute',
          top: '50%',
          transformOrigin: '0 0',
          width: '20vh',
          left: '25%',
        },
      }
    : {
        height: '100vh',
        backgroundColor: '#77A3C5',
        fontSize: '13px',
        width: '3%',
        zIndex: '1',
        display: 'inline-block',
        position: 'relative',
        '& .CollapsedIcon': {
          position: 'absolute',
          /* margin: 0 auto; */
          transfom: 'rotate(270deg)',
          left: '9px',
          transform: 'rotate(180deg)',
        },
        '& h3': {
          transform: 'rotate(-90deg)',
          fontSize: '11px',
          color: 'white',
          letterSpacing: '3px',
          position: 'absolute',
          top: '50%',
          transformOrigin: '0 0',
          width: '20vh',
          left: '25%',
        },
      };
