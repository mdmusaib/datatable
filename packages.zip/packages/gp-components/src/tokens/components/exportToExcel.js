import common from '../common';

export default {
  ...common,

  exportToDefaultStyle: {
    padding: 1,
  },
};
