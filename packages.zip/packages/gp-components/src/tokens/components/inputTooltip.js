export default props => ({
    fontSize: '10px',
    padding: '4px',
    borderRadius: '5px',
    fontWeight: '600',
    opacity: '1'
})