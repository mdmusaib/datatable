import colors from '../colors';
import common from '../common';

export default {
  // '.my_tooltip': {
  //   backgroundColor: 'blue',
  //   marginTop: '-30px',
  //   height: '10px',
  // },
  //   ...common,
  // ' *': {
  //   fontSize: '12px',
  // },
  // '.mytooltip': {
  //   width: '100%',
  //   cursor: 'pointer',
  //   height: 'auto',
  //   marginTop: '-6px',
  // },
  // '.tooltipText': {
  //   margin: '30px',
  // },
  // '.mytooltip .mytext': {
  //   visibility: 'hidden',
  //   color: 'white',
  //   margin: '-10px -87px 20px',
  //   width: '87px!important',
  //   backgroundColor: '#787878',
  //   fontFamily: 'sans-serif',
  //   zIndex: '1',
  //   padding: '5px',
  //   bottom: '80%',
  //   left: 'auto',
  //   backdropFilter: 'blur(6px)',
  //   textAlign: 'center',
  //   position: 'fixed',
  // },
  // '.mytext:after': {
  //   content: '',
  // },
  // '.mytext::before': {
  //   content: '',
  //   position: 'absolute!important',
  //   top: '100%',
  //   left: '50%',
  //   marginLeft: '-10px',
  //   borderWidth: '8px',
  //   borderStyle: 'dashed',
  //   borderColor: '#787878 transparent transparent transparent',
  // },
  // '.mytext::after': {
  //   content: '',
  //   position: 'absolute!important',
  //   top: '100%',
  //   left: '50%',
  //   marginLeft: '-10px',
  //   borderWidth: '8px',
  //   borderStyle: 'dashed',
  //   borderColor: '#787878 transparent transparent transparent',
  // },
  // '.mytooltip:hover .mytext': {
  //   visibility: 'visible',
  //   width: 'auto',
  // },
};
