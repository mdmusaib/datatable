import colors from '../colors';
import common from '../common';

export default {
  ...common,
  basicGrid: {
    width: '100%',
    height: '100%',

    gridStyle: props => ({
      width: '100%',
      height: props.inModalHeight || ' 80vh',
      display: 'flex',
      overflow: 'hidden',

      '& .ag-body-horizontal-scroll-container': {
        width: props.pinnedColumns ? `${2380 + 100}px !important` : '',
      },

      '&.ag-theme-balham .ag-header-row ': {
        fontFamily: 'workSans',
        color: 'white',
      },

      '& .ag-row-selected': {
        backgroundColor: props.rowSelected || !props.selected ? '' : ' #69bdd2',
        '& .ag-cell': {
          color: props.rowSelected || !props.selected ? '' : `${colors.paxia_grid.white} !important`,
        },
      },

      '& .ag-theme-balham .ag-header-cell': {
        paddingLeft: '7px !important',
      },
    }),

    //For saved view--------------------
    savedViewLabelStyle: {
      fontSize: '13px',
      fontStyle: 'lighter',
      fontFamily: 'workSans',
      color: colors.paxia_grid.brand_blue,
      mt: 1,
    },

    savedViewOptionStyle: {
      fontSize: '8pt',
      fontFamily: 'workSans',
      display: 'flex',
      position: 'relative',
      flexDirection: 'column',
      backgroundColor: colors.paxia_grid.white,
      top: '1px',
      maxHeight: '150px',
      minWidth: '112px',
      overflowY: 'scroll',
      overflowX: 'hidden',
      boxShadow: ' 0px 8px 16px 0px rgba(0,0,0,0.2)',
      zIndex: 1,
    },

    selectViewStyle: {
      height: '25px',
      display: 'flex',
      alignItems: 'center',
    },

    savedViewContainer: {
      width: '100%',
      display: 'flex',
      bg: colors.paxia_grid.grey_34,
    },

    savedViewParentStyle: {
      width: '50%',
      display: 'flex',
      alignItems: 'center',
      pl: 2,
    },

    savedViewIconsStyle: {
      display: 'flex',
      textAlign: 'justify',
      alignItems: 'center',
      justifyContent: 'space-around',
      width: '80px',
      paddingTop: 1,
      cursor: 'pointer',
    },

    savedViewSelectStyle: {
      borderRadius: 1,
      width: '137px',
      border: `1px solid ${colors.paxia_grid.grey_27}`,
      marginLeft: 1,
      bg: colors.paxia_grid.white,
      display: 'inline-block',
      fontSize: 6,
      outline: 'none',
      cursor: 'pointer',
      color: colors.paxia_grid.brand_blue,
      height: '25px',

      span: {
        position: 'relative',
        padding: '5px',
        left: '1px',
        display: 'flex',
        fontWeight: 500,
        lineHeight: 0,
      },
    },

    savedViewInputStyle: {
      outline: 'none',
      display: 'flex',
      alignItems: 'center',
      height: '23px',
      justifyContent: 'space-between',
    },

    savedViewContentLayout: {
      display: 'flex',
      flexDirection: 'row',
      position: 'relative',
      left: '2px',
      padding: '4px',
    },

    savedViewContentStyle: {
      width: '120px',
      display: 'flex',
      alignItems: 'center',
      color: colors.paxia_grid.brand_blue,
    },

    savedViewBtnStyle: {
      margin: 1,
      position: 'relative',
      left: 1,
      bottom: '4px',
    },

    dropdownIcon: props => ({
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-start',
      width: 0,
    }),

    savedViewDataStyle: {
      marginBottom: '0px',
      width: '80%',
      overflow: 'hidden',
      pl: 2,
      fontWeight: 400,
      fontSize: 0,
    },
    //end---------------------------------

    /* Button panel styles */
    buttonPanelContainer: {
      display: 'flex',
      alignItems: 'center',
      flexDirection: 'row',
      justifyContent: 'flex-end',
      width: '50%',
      margin: 1,
    },

    buttonPanelIconsStyle: {
      padding: 1,
      ml: 1,
      cursor: 'pointer',
    },

    //end---------------------------------

    //For ag-grid style----------------------
    ' & .ag-row-hover': {
      bg: `#69bdd2 !important`,

      '& .ag-cell': {
        color: `${colors.paxia_grid.white} !important`,
      },
    },

    ' & .ag-row-odd': {
      bg: colors.paxia_grid.grey_85,
    },

    '& .ag-row-even': {
      bg: colors.paxia_grid.white_smoke,
    },

    '&.ag-theme-balham .ag-header': {
      background: colors.paxia_grid.grey_29,
    },

    '& .ag-pinned-left-cols-container ': {
      borderRight: `2px solid ${colors.paxia_grid.grey_80} !important`,
    },

    '&.ag-theme-balham .ag-ltr .ag-cell': {
      borderRight: `2px solid ${colors.paxia_grid.grey_28}`,
      color: colors.paxia_grid.brand_blue,
      fontFamily: 'workSans',
      bottom: '2px !important',
      paddingLeft: '6px',

      '&:focus': {
        borderColor: colors.paxia_grid.grey_85,
      },
    },

    // '& .ag-row-selected': {
    //   backgroundColor: ' #69bdd2',
    //   '& .ag-cell': {
    //     color: `${colors.paxia_grid.white} !important`,
    //   },
    // },

    '&.ag-theme-balham .ag-menu': {
      background: 'white',
      borderRadius: '2px',
      top: '30px !important',
      minWidth: '2px !important',
    },

    '&.ag-set-filter-list': {
      width: '500px !important',
    },

    '&.arrow': {
      display: 'none !important',
      position: 'absolute !important',
      width: '1rem !important',
      height: '0.5rem !important',
      margin: '0px 0.3rem !important',
    },

    //This is for disabling some of the css properties in ag grid after pinning of the headerCheckbox column
    '&.ag-theme-balham .ag-horizontal-left-spacer': {
      bg: `${colors.paxia_grid.grey_80} !important`,
      width: '0px !important',
      minWidth: '0px !important',
    },

    '&.ag-theme-balham .ag-header-cell-resize': {
      bg: `${colors.paxia_grid.grey_85} !important`,
      width: '6px ',
    },

    '&.ag-theme-balham .ag-root ': {
      border: '0px solid white !important',
    },

    // '& .ag-body-horizontal-scroll-viewport': {
    //   width: '2px !important',
    // },

    // '&.ag-theme-balham  .ag-horizontal-left-spacer': {
    //   // overflow: 'scroll !important',
    // },

    //end-----------------------------------

    filterLayout: props => ({
      width: props.width,
      left: props.left,
    }),

    gridContainer: {
      width: '100%',
      borderTopLeftRadius: '10px',
      borderTopRightRadius: '10px',
    },

    gridOuterBox: {
      width: 'auto',
      height: 'auto',
      overflow: 'unset',
      border: `0px solid ${colors.paxia_grid.grey_28}`,
      bg: colors.paxia_grid.grey_34,
      // boxShadow: `0px 2px 2px 2px ${colors.paxia_grid.grey_29}`,
    },

    gridButtonBackground: {
      bg: colors.paxia_grid.grey_34,
      borderTop: `1px solid ${colors.paxia_grid.grey_27}`,
    },

    gridButtonParentStyle: {
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
    },

    gridRowCountStyle: { padding: 1, display: 'flex', alignItems: 'center', color: colors.paxia_grid.brand_blue },

    gridTitle: { fontWeight: 400, fontSize: '13px', fontFamily: 'workSans', color: colors.paxia_grid.brand_blue },

    gridCount: { fontWeight: 400, fontFamily: 'workSans', fontSize: '13px', display: 'flex', alignItems: 'center' },

    columnSearchStyle: {
      width: '186px',
      pl: 1,
      color: 'black',
      border: `1px solid ${colors.paxia_grid.grey_27}`,
      fontSize: 0,
    },

    gridButtonContainer: {
      height: '100%',
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'flex-end',
      margin: 1,
    },

    gridButtonStyle: props => ({
      borderRadius: 1,
      cursor: 'pointer',
      width: props.openDropdown ? '31px' : 'auto',
      border: `2px 2px solid `,
      padding: 1,
      marginLeft: 1,
      position: 'relative',
      display: 'inline-block',
      fontSize: 0,
      outline: 'none',
      fontWeight: 400,
      color: 'black',
      alignItems: 'center',
      height: '28px',

      '&:hover': {
        color: '#000',
      },
      '&:focus': {
        borderColor: 'white',
        color: '#000',
      },
      '&.active': {
        color: '#fff',
        borderColor: '#3f3a60',
      },

      div: {
        display: 'flex',
        alignItems: 'center',
      },

      span: {
        position: 'relative',
        padding: '5px',
        left: '1px',
        display: 'flex',
        lineHeight: 0,
      },
    }),

    showHideDropdownContent: {
      display: 'flex',
      position: 'relative',
      flexDirection: 'column',
      backgroundColor: colors.paxia_grid.light,
      top: '8px',
      right: '175px',
      maxHeight: '150px',
      minWidth: '206px',
      overflowY: 'scroll',
      overflowX: 'hidden',
      boxShadow: ' 0px 8px 16px 0px rgba(0,0,0,0.2)',
      zIndex: 1,
      border: `1px solid ${colors.paxia_grid.grey_28}`,
    },

    showHideDropdownLayout: {
      display: 'flex',
      flexDirection: 'row',
      position: 'relative',
      left: '6px',
      padding: '3px',
      width: '100%',
    },

    showHideDropdownContentStyle: props => ({
      width: 'auto',
      height: '19px',
      fontFamily: 'work Sans',
      span: {
        color: props.disabled ? colors.paxia_grid.grey_29 : 'black',
      },
    }),

    dropdownContainer: {
      display: 'block',
    },

    sortStyle: { padding: '10px', position: 'relative', left: '16px' },

    gridFilterButton: props => ({
      width: '24px',
      position: 'absolute',
      right: '0px',
      left: '3px',
    }),

    gridHeaderStyle: props => ({
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
    }),

    headerStyle: props => ({
      position: 'relative',
      left: '24px',
      right: '0px',
      top: '1px',
      fontSize: '13px',
      color: 'white',
      fontWeight: 'lighter',
      fontFamily: 'workSans',
    }),

    headerContainer: props => ({
      display: 'flex',
      flexDirection: 'row',
      alignItems: 'center',
      width: props.width - 20,
    }),

    iconLayout: {
      width: '13px',
      height: '15px',
    },

    gridHeaderComponent: props => ({
      display: 'flex',
      flex: '1 1 auto',
      alignItems: 'center',
      alignSelf: 'stretch',
      justifyContent: 'space-between',
      bg: colors.paxia_grid.grey_29,
      position: 'relative',
      right: '11px',
      height: '30px',
    }),

    gridInputStyle: props => ({
      padding: props.type === 'Date' ? '2px' : '4px',
      display: 'flex',
      justifyContent: 'flex-start',
    }),

    datepickerStyle: props => ({
      marginTop: '0px !important',
    }),

    gridFilterComponent: props => ({
      borderRadius: '5px',
      width: props.type === 'Date' ? props.width : props.width - 5,
      boxShadow: '2px',
      padding: props.type === 'Date' ? '' : 1,
      margin: 0,
      overflow: 'hidden',
      borderColor: colors.paxia_grid.grey_27,
    }),

    gridTextInput: props => ({
      width: props.width - 14,
      height: '25px',
      borderWidth: '1px',
      borderRadius: '0px',
      borderLeftStyle: 'solid',
      borderColor: colors.paxia_grid.grey_27,
      borderTopColor: colors.paxia_grid.white,

      '&:focus': {
        borderColor: colors.paxia.info,
        borderWidth: '2px',
      },
    }),

    radioInputStyle: {
      display: 'flex',
      alignItems: 'center',
    },

    labelStyle: props => ({
      fontSize: 3,
      fontWeight: 300,
      position: 'relative',
      bottom: props.type === 'Number' ? '0px' : '0px',
      display: 'flex',
      alignItems: 'center',
      color: colors.paxia_grid.brand_blue,
    }),

    numberInputStyle: {
      height: '20px',
      paddingLeft: 2,
    },

    seperator: props => ({
      borderBottom: `2px solid ${colors.paxia_grid.grey_27}`,
      position: 'relative',
      top: props.type === 'Date' ? '0px' : '2px',
      left: props.type === 'Number' ? '1px' : '3px',
      right: props.type === 'Date' ? '38px' : '',
      margin: props.type === 'Date' ? '0px' : '4px',
    }),

    inputStyle: props => ({
      width: props.width - 44,
      height: '25px',
      borderWidth: '1px',
      borderRadius: '0px',
      borderLeftStyle: 'solid',
      borderColor: colors.paxia_grid.grey_27,
      borderTopColor: colors.paxia_grid.white,

      '&:focus': {
        borderColor: colors.paxia.info,
        borderWidth: '2px',
      },
    }),

    quickLookContainerStyle: props => ({
      width: props.hideQuickLook ? '100%' : '50%',
      margin: 1,
      display: 'flex',
      padding: 2,
      alignItem: 'center',
    }),

    quickLookInputStyle: {
      position: 'relative',
      left: '7px',
      border: `1px solid`,
      borderColor: colors.paxia.grey_27,
    },

    quickLookStyle: {
      paddingLeft: 13,
      display: 'flex',
      alignItems: 'center',
    },

    topView: {
      display: 'flex',
    },

    buttonPanel: {
      width: '50%',
    },

    buttonStyle: props => ({
      width: props.showFooterReportButton || props.hideQuickLook ? '100%' : '50%',
      display: 'flex',
      alignItems: 'center',
      position: 'relative',
      right: props.showFooterReportButton ? '12px' : '14px',
      justifyContent: 'flex-end',
    }),
  },
};
