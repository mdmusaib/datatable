export default props => ({
  // border: '1px solid #DCDFE0',
  height: props.showList ? props.height : '1%',

  '& .TreeLayoutCol': {
    padding: '0',
    background: 'linear-gradient(to bottom, rgba(255,255,255,1) 0%, rgba(246,246,246,1) 47%, rgba(237,237,237,1) 100%)',
    display: 'flex',
    height: '4vh',
    cursor: 'default',
    border: '1px solid #9FA2A3',
  },
  // '& .TreeLayoutCol:hover':
  '& .TreeLayoutHeaderContainer': {
    fontSize: '11px',
    fontWeight: 'bold',
    padding: '0 5px',
    height: '4vh',
    width: '70%',
    cursor: 'default',
  },
  '& .TreeLayoutHeader': {
    verticalAlign: 'middle',
    lineHeight: '4vh',
    cursor: 'default',
  },
  '& .TreeLayoutHeaderIconContainer': {
    position: 'absolute',
    right: '0',
    width: '30%',
    cursor: 'default',
    textAlign: 'right',
  },
  '& .TreeLayoutHeaderIcon': {
    padding: '0 5px',
  },
  '& .TreeLayoutSearchContainer': {
    padding: '0',
    display: 'flex',
    // marginTop: '2px'
  },
  '& .TreeLayoutSearchLayout': {
    width: '80%',
  },
  '& .TreeLayoutSearchLayout input': {
    width: '100%',
    boxShadow: 'inset 1px 1px 0px 0px rgba(114,116,117,1)',
    border: '1px solid #9FA2A3',
  },
  '& .TreeLayoutSearchIconLayout': {
    width: '20%',
    position: 'relative',
  },
  '& .TreeLayoutChildrenRow': {
    height: '100%',
    border: '1px solid #727475',
    borderTop: 'none',
    borderBottom: 'none',
  },
  '& .TreeLayoutChildrenCol': {
    padding: '0',
  },
  '& .TreeLayoutSearchIconLayout-search': {
    position: 'absolute',
    backgroundColor: '#1C74BA',
    top: '0',
    padding: '3px 4px',
    left: '0',
  },
  '& .TreeLayoutSearchIconLayout-close': {
    position: 'absolute',
    backgroundColor: '#1C74BA',
    top: '0',
    padding: '3px 4px',
    right: '0',
  },

  '& .TreeLayoutRow': {
    borderBottom: 'none',
  },
});
