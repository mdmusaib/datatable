import colors from './../colors';
export default props => ({
  padding: '0px',
  fontSize: '11px',
  margin: props.containerWidth ? '' : '0px 15px 6px',
  height: props.containerWidth ? '31px' : '40px',
  display: 'flex',
  position: 'relative',
  width: props.containerWidth || '100%',
  fontFamily: 'Work Sans',
  // ' input': {
  //   fontSize: '11px',
  //   marginTop: props.type === 'Date' ? '' : '10px',
  //   margin: '0px 30px 0px 0px',
  //   width: props.elementConfig.width,
  // },
  '.datepicker_input': {
    margin: '0px',
    padding: '0px',
    marginTop: '-15px',
  },
  '& label': {
    // width: '10%',
    textAlign: 'left',
    top: '4px',
    color: '#9b9b9b',
    margin: '0',
  },
  '.react-datepicker__tab-loop': {
    position: 'fixed',
    zIndex: '10000',
  },

  // '.datepicker_input .datepicker_input > div.react-datepicker-wrapper .datepicker_input > div > div.react-datepicker__input-container datepicker_input > div > div.react-datepicker__input-container input': {
  //     width: '10%',
  // },
  '.react-datepicker-popper': {
    zIndex: '1000!important',
  },

  '.react-datepicker__close-icon:focus': {
    outline: '0px!important',
  },
  // '.react-datepicker__triangle': { right: '80%!important' },
  '.react-datepicker__close-icon::after': {
    backgroundColor: '#2c5e8e',
    borderRadius: '0px!important',
    height: '18px!important',
    width: '20px!important',
    fontSize: '14px!important',
    lineHeight: '0!important',
  },
  '.datepickerField': {
    // width: props.elementConfig.width,
    // height: props.elementConfig.height,
    width: props.elementConfig.width || '100%',
    height: props.elementConfig.height || '25px',
    borderRadius: '0 3px 3px 0',
    border: '1px solid #ced4da',
    padding: '0 10px',
    fontSize: '12px',
    fontWeight: '600',
  },

  '& .datepickerField:focus': {
    outline: 'none',
    border: props.inValid ? `1px solid ${colors.reds[0]}` : '1px solid #4fcdf7',
    boxShadow: props.inValid ? '0px 0px 2px 0px rgba(255, 71, 19, 1)' : '0px 0px 2px 0px rgba(25, 185, 238, 1)',
  },

  '.react-datepicker__day:hover': {
    backgroundColor: '#545cd8',
    color: '#fff',
  },
  '.react-datepicker__day--selected': {
    backgroundColor: '#ffa400!important',
    color: '#fff',
  },
  '& .DatepickerGroup': {
    position: 'absolute',
    bottom: '0',
  },
  '& .LabelName': {
    position: 'absolute',
    fontSize: '11px',
    fontWeight: '600',
    transform: props.inFocus ? 'translateY(0vh)' : 'translateY(3vh)',
    transitionTimingFunction: 'ease-out',
    transition: '0.25s',
    margin: props.inFocus ? '2px 0 0 5px' : '2px 0 0 35px',

    pointerEvents: 'none',
    fontFamily: 'Work Sans',
    color: colors.paxia.grey_31,
    top: '0',
  },
  '& .DatepickerIconGroup': {
    padding: '5px',
    cursor: 'pointer',
    height: '25px',
    borderRadius: '3px 0 0 3px',
    width: '15%',
  },

  '& .react-datepicker__close-icon:after': {
    // content: "''",
    backgroundColor: 'transparent',
    borderRadius: '0px!important',
    height: '18px!important',
    width: '20px!important',
    fontSize: '25px!important',
    lineHeight: '0!important',
    color: colors.paxia.grey_31,
  },
  '& .react-datepicker__day-name, .react-datepicker__day, .react-datepicker__time-name': {
    color: '#000',
    display: 'inline-block',
    width: '1.5rem',
    lineHeight: '1.5rem',
    textAlign: 'center',
    margin: '0',
  },
  '& .react-datepicker__header': {
    textAlign: 'center',
    backgroundColor: '#f0f0f0',
    borderBottom: '1px solid #aeaeae',
    borderTopLeftRadius: '0.3rem',
    borderTopRightRadius: '0.3rem',
    paddingTop: '8px',
    position: 'relative',
  },
  '& .react-datepicker__current-month': {
    marginTop: '0',
    color: '#000',
    fontWeight: '500',
    fontSize: '12px',
  },
  '& .react-datepicker-wrapper': {
    width: '85%',
  },
});
