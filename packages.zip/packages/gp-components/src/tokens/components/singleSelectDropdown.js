import colors from './../colors';
export default props => ({
  height: '40px',
  // fontSize: '12px',
  margin: props.isSelectWithInput ? '0px 15px 6px 0px' : '0px 15px 6px',
  // margin: '0px 15px 6px',
  position: 'relative',
  //padding: '0 0 0 14px',
  width: '100%',
  '& select': {
    padding: '1px',
    maxHeight: '25px',
    width: '100%',
    border: props.inValid ? `1px solid ${colors.reds[0]}` : `1px solid  ${colors.paxia.grey_27}`,
    boxShadow: props.inValid ? '0px 0px 2px 0px rgba(255, 71, 19, 1)' : '',
    position: 'absolute',
    bottom: '0px',
    fontSize: props.inFocus ? '12px' : '11px',
    fontWeight: '600',
    borderRadius: '3px',
    color: props.value ? 'black' : '#5b6670',
    // width: '50%' ///added
    fontFamily: 'Work Sans',
    height: '25px',
  },

  '& .SelectContainer': {
    padding: '0',
  },

  '& .LabelCol': {
    paddingRight: '0',
    paddingLeft: '0',
  },
  '& .LabelCol > label': {
    marginBottom: '0',
    color: '#9b9b9b',
  },
  '& .SelectCol': {
    paddingLeft: '0',
  },

  '& .SelectRow': {
    margin: '0',
  },

  '& .SelectCol > label': {
    fontSize: '11px',
    padding: '0 5px 0 0',

    //marginBottom: '0'
  },

  //EXTRA CSS AFTER REMOVING COL ROW CONTAINER
  '& span': {
    // width: '10%',
    // display: props.inFocus ? 'block' : 'none',
    textAlign: 'left',
    position: 'absolute',
    top: '0',
    color: colors.paxia.grey_31,
    fontWeight: '600',
    marginBottom: '0px',
    transform: props.inFocus ? 'translateY(0vh)' : 'translateY(3vh)',
    transitionTimingFunction: 'ease-out',
    transition: '0.25s',
    margin: '2px 5px 0',
    pointerEvents: 'none',
    fontFamily: 'Work Sans',
    fontSize: '11px',
    // margin: '2px 5px 0',

  },
  // '& span': {
  //   color: colors.reds[0],
  //   padding: '0',
  //   backgroundColor: colors.white,
  // },
  // '& select:focus > option:checked': {
  //   backgroundColor: 'red'
  // }
  '& mark': {
    color: colors.reds[0],
    padding: '0',
    backgroundColor: 'transparent',
  },
  '& select:focus': {
    outline: 'none',
    border: props.inValid ? `1px solid ${colors.reds[0]}` : '1px solid #4fcdf7',
    boxShadow: props.inValid ? '0px 0px 2px 0px rgba(255, 71, 19, 1)' : '0px 0px 2px 0px rgba(25, 185, 238, 1)',
  },

});
