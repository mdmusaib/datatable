import colors from '../colors';
import common from '../common';

export default props => ({
  '@media (max-width: 1000px)': {
    overflow: 'scroll',
    margin: '-3px',
    '& .sub-menu': {
      marginLeft: '-97px',
    },
  },

  //borderBottom: '1px solid #ccc',
  height: '30px',
  background: '#f2f2f2',
  borderLeft: '1px solid #fff',
  borderTopLeftRadius: props.isTop ? '10px' : '0px',
  borderTopRightRadius: props.isTop ? '10px' : '0px',
  marginLeft: props.isLeft ? '5px' : '85px',
  marginBottom: '0px',
  width: props.isLeft ? '99.2%' : props.showTreeExplorer === false ? '92.6%' : '91.4%',
  '::-webkit-scrollbar': {
    width: '0px',
    background: 'transparent',
  },
  'input[type=number]::-webkit-inner-spin-button': {
    opacity: '1!important',
    transform: 'scale(1.5)',
    cursor: 'pointer',

    background: 'grey!important',
    width: '0px',
  },

  '& .formattingToolbar': {
    display: 'inline-flex',

    cursor: 'pointer',
    fontSize: '1em',
    margin: '0px 1px',
    marginLeft: '5px',
    flexDirection: 'row',
    justifyItems: 'center',
    alignItems: 'center',

    // background: '#cfd2d3',
  },
  '& .formattingToolbar span': {
    // padding: '0px 5px 0px',
    margin: '1px',
    position: 'relative',
    float: 'left',
  },
  '& .formattingToolbar span img:hover': {
    backgroundColor: 'white',
    boxShadow: '0 0 5px white',
  },
  '.form-group': {
    marginBottom: '5px !important',
  },
  '.form-control': {
    padding: '0px!important',
    fontSize: '13px',
    fontFamily: 'Times New Roman',
  },

  '.strokeInputs': {
    margin: '7px',
    fontSize: '13px',
    height: '198px',
    marginTop: '-14px',
    // marginBottom: props.activeShape === 'SQUARE' ? '67px' : '',
    fontFamily: 'Times New Roman',
  },
  '.strokeInputs label': {
    marginBottom: '0px!important',
  },
  '& .vl': {
    marginTop: '3px',
    borderLeft: '1px solid #B0B0B0',
    height: 'auto',
    opacity: '0.9',
  },

  '& span img': {
    float: 'right',
    margin: '5px',
  },
  '.fontSelect': {
    width: '100px',
    height: '21px',
  },
  '.fontSelectSize': {
    width: '60px',
    height: '21px',
    margin: '3px',
  },
  'input[type="color"]': {
    border: 'none',
    appearance: 'none',
    width: '52px',
    height: '22px',
    margin: '2px',
    position: 'static',
  },
  'input[type="color"]:focus': {
    border: 'none',
    appearance: 'none',
    outlineWidth: '0',
  },
  '.sub-menu': {
    padding: '0',
    background: 'white',
    position: 'absolute',
    left: '25px',
    top: '24px',
    zIndex: '1',
    marginTop: '0px',
    border: '0.7px solid gray',
    maxHeight: '6.5em',
    overflowX: 'hidden',
    overflowY: 'auto',
    width: '100px',
  },

  '.sub-menu li': {
    fontSize: '12px',
    padding: '.10em 0.10em',
    lineHeight: '1em',
    cursor: 'pointer',
    lineBreak: 'wrap',
    fontFamily: 'workSans',
    whiteSpace: 'nowrap',
  },

  '.selectedInput': {
    backgroundColor: '#3298FD',
  },
  '& .unselected:hover': {
    background: 'skyblue',
  },
  '.selectedFont': {
    backgroundColor: '#3298FD',
  },
  '.unselectedFont:hover': {
    background: 'skyblue',
  },

  // '.sub-menu li:hover': {
  //   background: '#3298FD',
  // },

  '.fontSize-menu': {
    padding: '0',
    background: 'white',
    position: 'absolute',
    left: '28px',
    top: '20px',
    zIndex: '1',
    marginTop: '0px',
    border: '0.7px solid gray',
    maxHeight: '6.5em',
    overflowX: 'hidden',
    overflowY: 'auto',
    width: '40px',
  },
  '.fontSize-menu li': {
    fontSize: '12px',
    padding: '.10em 0.10em',
    lineHeight: '1em',
    cursor: 'pointer',
    lineBreak: 'wrap',
    fontFamily: 'workSans',
    whiteSpace: 'nowrap',
  },

  // '.fontSize-menu li:hover': {
  //   background: '#3298FD',
  // },
  '.selectInput': {
    fontFamily: 'workSans',
    fontSize: '12px',
    width: '100px',
    height: '18px',
    marginTop: '0px',
    padding: '0px',
  },
  '.fontSizeInputs': {
    fontFamily: 'workSans',
    fontSize: '12px',
    width: '41px',
    height: '18px',
    marginTop: '0px',
    padding: '0px',
  },

  // '.caret_icon': {
  //   display: 'inline-block',
  //   border: '1px solid black',
  //   borderRadius: '4px',
  //   backgroundColor: '#ffffff',
  //   cursor: 'pointer',
  //   whiteSpace: 'nowrap',
  // },

  // '& .caret_icon::after': {
  //   content: '',
  //   position: 'absolute',
  //   top: '50%',
  //   right: '15px',
  //   transform: 'translateY(-50%)',
  //   width: '0',
  //   height: '0',
  //   borderLeft: '5px solid transparent',
  //   borderRight: '5px solid transparent',
  //   borderTop: '5px solid black',
  // },
});
