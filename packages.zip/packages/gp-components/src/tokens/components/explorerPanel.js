import PanelBackground from './../../assets/images/treeIcons/treeIcons_PanelHolderButt.png';
export default props => ({
  padding: '0',
  height: '100%',
  display: 'block',
  position: 'relative',
  '& .ExplorerRow': {
    margin: '0 0 4px 0px',
    //border: '1px solid #0c0b0b42',
    // background: 'linear-gradient(to bottom, rgba(147,206,222,1) 0%, rgba(117,189,209,1) 16%, rgba(119,163,197,1) 100%)',
    //height: '4%',
    // background: 'treeIcons_tabsPanelHolder',
    // background: 'url("D:\workspace\GP React\packages\gp-components\src\assets\images\treeIcons\treeIcons_tabsPanelHolder") no-repeat fixed center'
  },
  '& .ExplorerCol': {
    padding: '0',
  },
  '& .ExplorerHeadingContainer': {
    color: 'white',
    fontSize: '13px',
    padding: '2px 6px 0px',
  },
  '& .ExplorerToggleIcon': {
    marginRight: '5px',
  },
  '& .ExplorerHeadingIconContainer': {
    display: 'flex',
    justifyContent: 'flex-end',
    paddingTop: '2px',
  },
  '& .ExplorerHeadingIconLayout': {
    padding: '0 4px',
    position: 'relative',
    bottom: '1px',
    // border: '.2px solid white'
  },
  '& .ExplorerHeadingIcon': {
    textAlign: 'center',
  },
  '& .ExplorerChildren': {
    backgroundColor: '#f5f5f5',
    height: '95%',
    margin: '0 4px',
    boxShadow: 'inset 0px 0px 3px rgba(0,0,0,.3)',
  },
});
