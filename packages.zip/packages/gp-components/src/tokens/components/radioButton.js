import colors from '../colors';

export default props => ({
  display: 'block',
  position: 'relative',
  paddingLeft: '54px',
  marginBottom: '0px',
  cursor: 'pointer',
  fontSize: '11px',
  fontWeight: 600,
  color: colors.paxia.grey_31,
  userSelect: 'none',
  '& input': {
    position: 'absolute',
    left: '1px',
    opacity: '1',
    cursor: 'pointer',
    backgroundColor: '#eee',
    borderRadius: '50%',
  },

  /* Create a custom radio button */
  '& .checkmark': {
    position: 'absolute',
    alignItems: 'center',
    display: 'flex',
    top: '0',
    left: '19px',
    height: '12px',
    width: '12px',
  },

  /* When the radio button is checked, add a blue background */
  '& input:checked ~ .checkmark': {
    content: "''",
    backgroundColor: '#006098',
  },

  /* Create the indicator (the dot/circle - hidden when not checked) */
  '& .checkmark:after': {
    content: "''",
    position: 'absolute',
  },

  /* Show the indicator (dot/circle) when checked */
  '&  input:checked ~ .checkmark:after': {
    content: "''",
    display: 'block',
  },

  /* Style the indicator (dot/circle) */
  '& .checkmark:after': {
    content: "''",
    top: '0px',
    left: '0px',
    width: '0px',
    height: '0px',
    borderRadius: '50%',
    background: 'white',
  },
});
