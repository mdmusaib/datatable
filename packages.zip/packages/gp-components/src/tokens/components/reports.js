import common from '../common';

export default {
  ...common,

  reportStyle: {
    padding: 1,
  },
};
