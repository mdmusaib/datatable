import colors from '../colors';
import { keyframes } from '@emotion/core';

const glow = keyframes`
  0%, 100% { opacity: 1; }
  50% { opacity: .4; }
`;

const zoomIn = keyframes`
0% { transform: translate(-50%,-50%) scale(0);  opacity:0 }
100% { transform: translate(-50%,-50%) scale(1); opacity:1 }
`;
export default {
  path: props => ({
    fill: props.primary ? colors.paxia.brand_blue : colors.paxia.brand_light_blue,
    animation: `${glow} .7s ease  infinite`,
    animationDelay: props.primary ? '.3s' : '.1s',
  }),
  svg: props => ({
    width: '40px',
    marginRight: '5px',
  }),
  wrapper: props => ({
    position: 'absolute',
    left: '50%',
    top: '50%',
    transform: 'translate(-50%,-50%)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '120px',
    height: '60px',
    boxShadow: 'small',
    bg: colors.paxia.white,
    //borderRadius: '20px',
    animation: `${zoomIn} .3s ease`,
    '& > span > span': {
      animation: `${glow} .8s ease  infinite`,
    },
    '& > span > span:nth-child(1)': {
      animationDelay: '.3s',
    },
    '& > span > span:nth-child(2)': {
      animationDelay: '.6s',
    },
    '& > span > span:nth-child(3)': {
      animationDelay: '.8s',
    },
  }),
};
