import colors from '../colors'
export default props => ({

    color: '#9b9b9b',
    padding: '0',
    fontSize: '11px',
    fontFamily: 'Work Sans',
    margin: '0px',
    width: '100%',
    margin: '0px 15px 6px',
    position: 'relative',
    height: '90px',
    '& textarea': {
        position: 'absolute',
        marginTop: '11px',
        padding: '0 5px',
        resize: 'none',
        fontSize: '12px',
        borderRadius: '3px',
        border: props.readOnly ? 'none' : props.inValid ? `1px solid ${colors.reds[0]}` : `1px solid  ${colors.paxia.grey_27}`,
        boxShadow: props.inValid ? '0px 0px 2px 0px rgba(255, 71, 19, 1)' : '',
        width: '100%',
        fontWeight: '600',
        bottom: '0',
    },
    '& span': {
        position: 'absolute',
        fontSize: '11px',
        fontWeight: '600',
        transform: props.inFocus ? 'translateY(0vh)' : 'translateY(3vh)',
        transitionTimingFunction: 'ease-out',
        transition: '0.25s',
        margin: '2px 5px 0',
        pointerEvents: 'none',
        fontFamily: 'Work Sans',
        color: colors.paxia.grey_31,
    },
    '& mark': {
        color: colors.reds[0],
        padding: '0',
        backgroundColor: 'transparent',
    },
    '& textarea:focus': {
        outline: 'none',
        border: props.inValid ? `1px solid ${colors.reds[0]}` : '1px solid #4fcdf7',
        boxShadow: props.inValid ? '0px 0px 2px 0px rgba(255, 71, 19, 1)' : '0px 0px 2px 0px rgba(25, 185, 238, 1)',
    },
    '& textarea .tooltip': {
        display: 'none'
    },
})