// import colors from '../colors';
// import common from '../common';

import colors from '../colors';

export default {
  '*': {
    margin: '0',
    padding: '0',
    fontSize: '13px',
    fontFamily: 'workSans',
  },
  '& .currentShape': {
    cursor: 'pointer',
    borderShadow: '2px solid grey',
    border: '1px solid black',
  },
  '.Formatting_menu': {
    left: '16px',
  },
  '.standard_toolbar::before': {
    position: 'absolute',
    left: '0',
    top: '50%',
    height: '50%',
    width: '3px',
    backgroundColor: '#336699',
    content: '',
    transform: 'translateX(10px) rotate(-45deg)',
    transformOrigin: 'left bottom',
  },
  i: {
    border: 'solid black',
    borderWidth: '0 1px 1px 0',
    display: 'inline-block',
    lineHeight: '0',
    float: 'right',
    margin: '5px',
    textAlign: 'center',
    padding: '2.5px',
  },

  '.right': {
    transform: 'rotate(-45deg)',
    // -webkit-transform: rotate(-45deg);
  },

  '#nav': {
    marginLeft: '5px',
    marginRight: '5px',
    marginBottom: '5px',
    borderBottomLeftRadius: '10px',
    borderBottomRightRadius: '10px',
    fontSize: '12px',
    listStyle: 'none',
    height: '24px',
    //width: 'auto',
    //margin: '0px',
    //border: '1px solid #000',
    //borderBottom: '.5px solid #ccc',
    color: 'white',
    background: colors.paxia.brand_light_blue,
  },
  '.vl': {
    // paddingBottom: '15px !important',
    borderBottom: '1px solid #ccc',
  },
  '#nav li': {
    position: 'relative',
    float: 'left',
    width: '70px',
    zIndex: '10000!important',
    // height: '18px',
    marginTop: '3px',
    textAlign: 'center',
    cursor: 'pointer',
  },
  '#nav li:hover': {
    background: '#add8e6',
  },

  ' #nav ul': {
    position: 'absolute',
    left: '-999em',
    top: '2em',
    zIndex: '1000',
    background: 'white',
    border: '1px solid white',
    color: 'black',
    listStyle: 'none',
    boxShadow: ' 0px 2px 3px rgba(0,0,0,.3)',
  },
  ' #nav ul li': {
    borderTop: '0',
    padding: '1px 5px',
    width: '155px',
    textAlign: 'left',
    whiteSpace: 'nowrap',
  },

  '#nav ul li ul li': {
    width: '185px',
    padding: '1px 5px',
    textAlign: 'left',
    whiteSpace: 'nowrap',
  },
  '#nav li:hover ul': {
    top: 'auto',
    left: '-1px',
  },
  /* 2nd Level Drop */
  '#nav li:hover ul ul': {
    left: '-1000em',
  },
  '#nav ul li:hover ul': {
    left: '156px',
    top: '-2px',
  },
};
