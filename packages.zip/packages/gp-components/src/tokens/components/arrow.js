export default props => ({
  display: 'flex',
  fontSize: '12px',
  margin: '3px 0',

  '& .LabelName': {
    margin: '3px 0 0 3px',
    fontSize: '11px',
    fontFamily: 'work Sans',
  },
  '& .NodeContainer': {
    position: 'relative',
    width: '100%',
    display: 'flex',
  },
  '& .LabelIcon': {
    marginLeft: '4px',
  },
  '&:hover': {
    // display: 'block'
    backgroundColor: 'rgba(179, 224, 255)',
  },
  '&:active': {
    backgroundColor: '##7FCEFF',
  },
  '& .Overlay': {
    // position: 'absolute',
    // top: '0',
    // bottom: '0',
    // width: '100%',
    // height: '100%',
    // backgroundColor: 'rgba(179, 224, 255)'
    // backgroundColor: 'rgba(179, 224, 255,0.2)',
    // zIndex: 'auto',
    display: 'none',
    // fontFamily: 'workSans',
  },
});
