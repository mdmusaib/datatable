import colors from './../colors';

export default props => ({
  padding: '0',
  display: 'block',
  position: 'relative',
  width: '100%',
  cursor: 'pointer',
  transition: '0.4s',
  overflow: 'hidden',
  backgroundColor: '#d4d4d4',

  '& .accordianRow': {
    margin: '0px',
    backgroundColor: props.color,
    borderTopLeftRadius: '10px',
    borderTopRightRadius: '10px',
  },

  '& .accordianCol': {
    padding: '0',
  },

  '& .accordianHeadingContainer': {
    color: 'white',
    fontSize: '13px',
    height: '30px',
    display: 'flex',
    alignItems: 'center',
  },

  '& .accordionToggleIcon': {
    marginLeft: '7px',
  },

  '& .accordionTitle': {
    fontFamily: 'work Sans',
    paddingLeft: '10px',
  },

  '& .accordianChildren': {
    backgroundColor: colors.paxia_grid.grey_34,
    width: '100%',
    margin: '0px',
    height: '18vh',
    borderBottom: `1px solid ${colors.paxia_grid.grey_85}`,
  },
});
