import colors from './../colors';

export default props => ({

    height: '40px',
    // fontSize: '12px',
    // margin: '0px 30px 0px 0px',
    position: 'relative',
    margin: props.widthNoMargin ? '0px 15px 6px' : props.isInputWithDropDown ? '0 0px 6px 15px' : '0px 15px 6px',
    width: '100%',
    fontFamily: 'Work Sans',
    '& input': {
        position: 'absolute',
        marginTop: '11px',
        padding: '0 5px',
        resize: 'none',
        fontSize: '12px',
        borderRadius: '3px',
        border: props.readOnly ? 'none' : props.inValid ? `1px solid ${colors.reds[0]}` : `1px solid  ${colors.paxia.grey_27}`,
        boxShadow: props.inValid ? '0px 0px 2px 0px rgba(255, 71, 19, 1)' : '',
        width: '100%',
        height: '25px',
        fontWeight: '600',
        bottom: '0'
        // fontFamily: 'workSans',
    },

    '& span': {
        position: 'absolute',
        fontSize: '11px',
        fontWeight: '600',
        transform: props.inFocus ? 'translateY(0vh)' : 'translateY(3vh)',
        transitionTimingFunction: 'ease-out',
        transition: '0.25s',
        margin: '2px 5px 0',
        pointerEvents: 'none',
        fontFamily: 'Work Sans',
        color: colors.paxia.grey_31,
    },
    '& mark': {
        color: colors.reds[0],
        padding: '0',
        backgroundColor: 'transparent',
    },
    '& input:focus': props.readOnly ?
        {
            outline: 'none',
            border: 'none',
            boxShadow: 'none'
        }
        :
        {
            outline: 'none',
            border: props.inValid ? `1px solid ${colors.reds[0]}` : '1px solid #4fcdf7',
            boxShadow: props.inValid ? '0px 0px 2px 0px rgba(255, 71, 19, 1)' : '0px 0px 2px 0px rgba(25, 185, 238, 1)',
        },

    '& input .tooltip': {
        display: 'none'
    },
    '& input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button': {
        appearance: 'none',
        margin: '0'
    }
})
