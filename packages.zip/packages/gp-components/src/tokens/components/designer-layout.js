import colors from '../colors';
import common from '../common';

export default props => ({
  '.tab-content': {
    // border: '1px solid #a2a9ad!important',
    // bg: 'whitesmoke!important',
    height: 'auto',
    // overflow: 'scroll',
    // width: '70%',
    // height: '79vh',
  },
  // button with no style
  'button, input[type="submit"], input[type="reset"]': {
    background: 'none',
    color: 'inherit',
    border: 'none',
    padding: '0',
    font: 'inherit',
    cursor: 'pointer',
    outline: 'inherit',
  },

  '#rounded': {
    display: 'none',
  },

  '& .overlayDrawingTool': {
    background: 'grey',
    opacity: '0.5',
    pointerEvents: 'none',
  },
  '.hoverDisplayGrid': {
    border: '1px solid #00bed6',
  },
  'input[type=number]::-webkit-inner-spin-button': {
    opacity: '1!important',
    transform: 'scale(1.5)',
    cursor: 'pointer',

    background: 'grey!important',
    width: '0px',
  },
  select: {
    size: '5',
  },
  // 'input[type="number"]::-webkit-inner-spin-button:hover, input[type="number"]::-webkit-inner-spin-button:active': {
  //   boxShadow: '0 0 2px #0CF',
  // },

  // '.konvajs-content': {
  //   overflow: 'scroll',
  // },

  '& .drawingToolbarStyle': {
    // marginTop: '-30px',
    width: '75px',
    position: 'absolute',
    overflowX: 'none',
    overflowY: 'none',
    borderRadius: '10px',
    //borderTopLeftRadius: '10px',
    //borderBottomLeftRadius: '10px',
    height: props.standard_toolbar === false ? '93vh' : '94.5vh',

    '@media (max-width: 1000px)': {
      overflow: 'none',
      overflowY: 'none',
    },

    background: '#f2f2f2',
    borderTop: '1px solid #fff',
    borderLeft: '1px solid #fff',
    borderBottom: '1px solid #fff',
    zIndex: '1000',
    marginLeft: '21px',
    //margin: '0px 15px',
    //borderRight: '1px solid #ccc',
    //display: 'flex',
    // flexDirection: 'column',
    // alignItems: 'center',
  },
  '& .currentShape': {
    cursor: 'pointer',
    //borderShadow: '2px solid grey',
    border: '.5px solid #ccc',
    position: 'relative',
    boxShadow: '0 1px 2px rgba(0, 0, 0, 0.3), 0 0 20px rgba(0, 0, 0, 0.1) inset',
  },

  // '[title]:hover:before': {
  //   content: 'attr(title)',
  //   background: 'yellow',
  // },
  // '& .tab-contents': {},

  '& li': {
    border: '1px solid #ddd',
    marginTop: '-1px',
    width: '50px',
    height: '10px',
    backgroundColor: '#f6f6f6',
    padding: '12px',
    lineHeight: '0',
    textDecoration: 'none',
    color: 'black',
    display: 'block',
    position: 'relative',
  },

  '& ul li:hover': {
    backgroundColor: '#eee',
  },

  '& .close': {
    cursor: 'pointer',
    position: 'absolute',
    top: '50%',
    lineHeight: '0',
    right: '0%',
    padding: '12px 16px',
    transform: 'translate(0%, -50%)',
  },

  '& div.drawingBoard': {
    height: '200px',
    width: '70%',
    backgroundColor: 'whitesmoke',
  },
  '& .drawingBoardClose': {
    width: '5%',
    cursor: 'pointer',
    backgroundColor: 'gray',
  },
  '& .wrapper': {
    height: '100%',
    width: '100%',
    margin: '0',
    padding: '0',
    overflow: 'hidden',
    background: 'red',
    display: 'grid',
    color: 'red',
    gridTemplateRows: '50px 1fr 50px',
  },

  '& .header': {
    border: '1px solid #ddd',
    background: 'lightyellow',
    color: 'red',
  },

  '& .footer': {
    background: 'lightpink',
  },

  '&.content': {
    display: 'grid',
    gridTemplateColumns: '250px 1fr 300px',
    gridGap: '10px',
    overflow: 'hidden',
  },

  '&.fieldTypes': {
    display: 'grid',
    gridTemplateRows: '40px 1fr',
    overflowY: 'auto' /*added*/,
  },

  '&.fieldTypes,&.search': {
    border: '1px solid red',
  },

  '&.fieldTypes, &.fieldsContainer': {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, minmax(70px,1fr))',
    gridAutoRows: '50px',
    gridGap: '10px',
    overflowY: 'scroll' /*added*/,
  },
  '& .parent': {
    display: 'block',
    position: 'relative',
    float: 'left',
    lineHeight: '30px',
    backgroundColor: '#4FA0D8',
    borderRight: '1px solid #CCC',
  },

  '& .parent a': { margin: '10px', color: '#FFFFFF', textDecoration: 'none' },
  '& .parent:hover > ul': { display: 'block', position: 'absolute' },

  '& .child': { display: 'none' },
  '& .child li': {
    backgroundColor: '#E4EFF7',
    lineHeight: '30px',
    borderBottom: '#CCC 1px solid',
    borderRight: '#CCC 1px solid',
    width: '100%',
  },

  '& .child li a': { color: '#000000' },
  '& ul': { listStyle: 'none', margin: '0', padding: '0px', minWidth: '10em' },
  '& ul ul ul': { left: '100%', top: '0', marginLeft: '1px' },
  '& li:hover': { backgroundColor: '#95B4CA' },
  '& .parent li:hover': { backgroundColor: '#F0F0F0' },
  // .expand{font-size:12px;float:right;margin-right:5px;}

  '&.card': {
    padding: '10px',
    background: '#ddd',
  },

  '.drawingToolbar': {
    marginTop: '7px',
    marginLeft: '5px',
    display: 'inline-grid',
    justifyItems: 'center',
    gridTemplateColumns: '30px 30px',
    // height: '400px',
    // width: '100px',
    height: '155px',
    // overflowY: 'scroll',
    // overflowX: 'scroll',
  },
  '.drawingToolbar span': {
    display: 'flex',
    justifyItems: 'center',
    justifyContent: 'center',
    alignContent: 'center',
    alignItems: 'center',
    padding: '0px 0px 0px',
    margin: '0px 0px 0px 0px',
    cursor: 'pointer',
    width: '25px',
    height: '25px',
  },
  '.drawingToolbar span:hover': {
    padding: '0px 0px 0px',
    margin: '0px 0px 0px 0px',
    cursor: 'pointer',
    bg: colors.paxia.grey_28,
  },
  '.drawingToolbar span img:hover': {
    backgroundColor: '#a2a9ad',
    boxShadow: '0 0 5px #a2a9ad',
  },
  '& .colorShapes': {
    display: 'grid',
    gridTemplateColumns: '28px 31px 0px',
    marginTop: '-10px',
    height: '70px',
    alignItems: 'center',
    // overflowY: 'scroll',
    // overflowX: 'scroll',
  },
  'input[type="color"]': {
    border: 'none',
    appearance: 'none',
    width: '52px',
    height: '22px',
    margin: '-6px',
    position: 'static',
    backgroundColor: 'transparent',
  },
  'input[type="color"]:focus': {
    border: 'none',
    appearance: 'none',
    outlineWidth: '0',
  },

  '.colorShapes span': {
    padding: '0px 0px 0px',
    cursor: 'pointer',
  },

  ' .drawingBox': {
    zIndex: '1',
    backgroundColor: 'whitesmoke',
    position: 'absolute',
    display: 'inline-block',

    width: '100px',
    margin: '0px 1px',
    overflowY: 'scroll',
    height: '490',
  },
  '& .standardToolbar': {
    display: 'inline-flex',

    '@media (max-width: 1000px)': {
      overflow: 'scroll',
      margin: '0px 75px',
    },
    '@media (max-height: 5cm)': {
      overflow: 'scroll',
    },
    '::-webkit-scrollbar': {
      width: '0px',
      background: 'transparent',
    },
    marginLeft: '5px',
    marginTop: '-4px',
    // cursor: 'pointer',
    fontSize: '1em',
    //margin: '0px 75px',
    width: '100%',
    // background: '#297fc0',
  },
  '& .standardToolbar span': {
    padding: '1px 4px',
    cursor: 'pointer',
    position: 'relative',
    margin: '0px 3px',
    float: 'left',
  },

  '.standardToolbar span img:hover': {
    backgroundColor: '#add8e6',
    boxShadow: '0 0 5px #add8e6',
  },
  '.standardToolbar span svg:hover': {
    fill: colors.paxia.svgIconColorLight,
  },
  '& .formattingToolbar': {
    display: 'inline-flex',
    overflow: 'inherit',
    cursor: 'pointer',
    fontSize: '1em',
    margin: '0px 1px',
    width: '100%',
    // background: '#cfd2d3',
  },
  '& .formattingToolbar span': {
    // padding: '0px 5px 0px',
    margin: '1px',
    position: 'relative',
    float: 'left',
  },
  '& .formattingToolbar span img:hover': {
    backgroundColor: 'white',
    boxShadow: '0 0 5px white',
  },
  '.form-group': {
    marginBottom: '5px !important',
  },
  '.form-control': {
    padding: '6px!important',
    fontSize: '13px',
    fontFamily: 'workSans',
  },
  '.form-label': {
    fontSize: '12px!important',
    fontFamily: 'workSans!important',
    margin: '0px 5px!important',
  },
  '.strokeInputs': {
    margin: '7px',
    fontSize: '13px',
    height: '225px',
    marginTop: '-14px',
    // marginBottom: props.activeShape === 'SQUARE' ? '67px' : '',
    fontFamily: 'workSans',
  },
  '.strokeInputs label': {
    marginBottom: '0px!important',
  },
  '& .vl': {
    marginTop: '3px',
    borderLeft: '1px solid #B0B0B0',
    height: 'auto',
    opacity: '0.9',
  },

  // tabs styles
  '& .nav': {
    position: 'fixed!important',
    zIndex: '1!important',
    background: 'lightgray',
    width: '100%',
    marginTop: '-4px',
  },

  '& .nav-tabs .nav-link': {
    width: 'auto',
    fontFamily: 'workSans',
    borderBottom: '0.7px solid #A9A9A9',
    border: '0.5px solid #a6a5a8!important',
    borderRadius: '8px 8px 0px 0px',
    height: '20px',
    textAlign: 'center',
    fontSize: '13px',
    fontWeight: '400',
    color: '#000000',
    lineHeight: '0.5!important',
  },
  '.nav-link': {
    padding: '.5rem 3rem',
  },

  '.nav-tabs': {
    borderBottom: '1px solid #cbcace',
    // width: '180% !important',
  },
  '.nav-tabs .nav-link:hover': {
    background: 'whitesmoke',
    opacity: '0.8',
  },
  '& canvas': {
    background: 'white!important',
  },

  '& .tooltip-arrow': {
    display: 'none !important',
  },

  '.nav-item': {
    borderRadius: '8px 8px 0px 0px',
    // marginTop: '5px!important',
  },
  '.nav-item .active': {
    borderBottom: '0.7px solid #a6a5a8!important',
    borderRadius: 'none!important',
    fontSize: '13px!important',
    // fontWeight: 'bold',
    // fontSize: '1em',
  },
  '.nav-item .active:hover': {
    background: 'white',
  },

  '& span img': {
    float: 'right',
    margin: '5px',
  },
  '.fontSelect': {
    width: '100px',
    height: '21px',
    margin: '3px',
  },
  '.fontSelectSize': {
    width: '60px',
    height: '21px',
    margin: '3px',
  },
});
