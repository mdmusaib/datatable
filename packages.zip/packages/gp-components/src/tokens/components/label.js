import colors from '../colors';

export default props => ({
  fontSize: '.7rem',

  '& > span': {
    color: props.isMandatory ? colors.paxia.danger : 'black',
    pr: 1,
  },
});
