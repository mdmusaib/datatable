import common from './../common';

export default props => ({
  paddingLeft: props.isRoot === 'root' ? '5px' : '20px',
  marginBottom: '0',
  cursor: 'default',
  '& .TreeContainer': {
    // overflowY: props.isRoot ? 'scroll' : 'none',
    // maxHeight: '45vh'
  },
  // '&:hover': {
  //     backgroundColor: '#b3e0ff'
  // },
  // '&:active': {
  //     backgroundColor: props.isRoot === "root" ? '##7FCEFF' : 'none'
  // }
});
