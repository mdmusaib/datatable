import colors from './../colors'
import { keyframes } from '@emotion/core';
const slideUp = keyframes`
0% { transform: translateX(10px);  opacity:0 }
100% { transform: translateX(1px); opacity:1 }
`;
const slideDown = keyframes`
0% { transform: translateX(-10px);  opacity:0 }
100% { transform: translateX(1px); opacity:1 }
`;

export default props => ({
    position: 'absolute',
    zIndex: '700',
    backgroundColor: "#3acf44",
    width: '20%',
    top: '40px',
    color: colors.paxia.white,
    right: '15px',
    boxSizing: 'border-box',
    transition: 'all 0.3s ease-out',
    transform: props.show ? 'translateX(0)' : 'translateX(-100vh)',
    opacity: props.show ? '1' : '0',
    height: '10%',
    fontFamily: 'Work Sans',
    borderRadius: '4px',
    animation: `${slideUp} .5s ease`,

    '& .ToastContainer': {
        padding: '10px',
        height: '100%',
        width: '93%',
        display: 'flex',
        justifyContent: 'left',
        fontSize: '15px',
        fontWeight: '500'
    },
    '& .ToastCrossIcon': {
        position: 'absolute',
        top: '2px',
        right: '2px'
    }
})