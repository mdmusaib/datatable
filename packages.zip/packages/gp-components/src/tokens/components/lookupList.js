import colors from './../colors'
export default props => ({
    padding: '0',
    fontSize: '11px',
    fontFamily: 'Work Sans',
    margin: '0',
    width: '100%',
    position: 'relative',
    color: 'black',
    height: '90px',
    margin: '0px 15px 6px',
    '& .LookupListGroup': {
        position: 'absolute',
        top: '17px',
        left: '0',
        width: '100%',
        display: 'flex',
        height: '100%'
    },
    '& .IconGroup': {
        width: '10%',
        padding: '10px 2px'
    },
    '& ul': {
        border: `1px solid  ${colors.paxia.grey_27}`,
        listStyle: 'none',
        width: '90%',
        borderRadius: '3px',
        padding: '8px 2px',
        overflowY: 'auto'
    },
    '& .LookupListLabel': {
        fontSize: '11px',
        color: colors.paxia.grey_31,
        fontWeight: '600',
        margin: '2px 5px 0'
    },
    '& .List': {
        padding: '1px 8px'
    },
    '& .ListSelect': {
        backgroundColor: '#7dbaff',
        padding: '1px 8px'
    },
    '& .List:hover': {
        backgroundColor: '#7dd9ff'
    }
})