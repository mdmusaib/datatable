import React from 'react';
import {
  StyleSheet,
  View,
} from 'react-native';

import { WebView } from 'react-native-webview';


class App extends React.Component {
  render() {
    return (
      <View style={styles.conatiner}>
        <WebView source={{ uri: 'http://portfolio-musaib.herokuapp.com/' }} />
      </View>
    );
  }
};

const styles = StyleSheet.create({
  conatiner: {
    flex: 1
  }
});

export default App;